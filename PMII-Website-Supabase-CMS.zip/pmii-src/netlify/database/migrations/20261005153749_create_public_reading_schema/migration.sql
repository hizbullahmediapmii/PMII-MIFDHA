CREATE TYPE "content_visibility" AS ENUM('DRAFT', 'PRIVATE', 'INTERNAL', 'PUBLIC');--> statement-breakpoint
CREATE TABLE "quran_bookmarks" (
	"device_hash" text,
	"surah" integer,
	"ayah" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "quran_bookmarks_pkey" PRIMARY KEY("device_hash","surah","ayah")
);
--> statement-breakpoint
CREATE TABLE "public_content" (
	"id" text PRIMARY KEY,
	"kind" text NOT NULL,
	"slug" text NOT NULL UNIQUE,
	"title" text NOT NULL,
	"category" text NOT NULL,
	"visibility" "content_visibility" DEFAULT 'DRAFT'::"content_visibility" NOT NULL,
	"public_fields" jsonb NOT NULL,
	"published_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "reading_states" (
	"device_hash" text PRIMARY KEY,
	"surah" integer NOT NULL,
	"ayah" integer NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
