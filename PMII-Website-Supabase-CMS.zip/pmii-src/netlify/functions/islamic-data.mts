import type { Config } from '@netlify/functions'

async function fetchSource(url: string) {
  const response = await fetch(url, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(12000) })
  if (!response.ok) throw new Error('Source unavailable')
  return response.json()
}

export default async (request: Request) => {
  if (request.method !== 'GET') return Response.json({ message: 'Metode tidak didukung.' }, { status: 405 })
  const params = new URL(request.url).searchParams
  const resource = params.get('resource')
  try {
    let data: unknown
    if (resource === 'surah') {
      const number = Number(params.get('number'))
      if (!Number.isInteger(number) || number < 1 || number > 114) return Response.json({ message: 'Nomor surah tidak valid.' }, { status: 400 })
      data = await fetchSource(`https://equran.id/api/v2/surat/${number}`)
    } else if (resource === 'doa') {
      data = await fetchSource('https://equran.id/api/doa')
    } else if (resource === 'prayer') {
      const latitude = Number(params.get('lat'))
      const longitude = Number(params.get('lng'))
      const date = params.get('date') ?? ''
      if (!params.has('lat') || !params.has('lng') || !Number.isFinite(latitude) || latitude <= -90 || latitude >= 90 || !Number.isFinite(longitude) || longitude < -180 || longitude > 180 || !/^\d{2}-\d{2}-\d{4}$/.test(date)) return Response.json({ message: 'Lokasi atau tanggal tidak valid.' }, { status: 400 })
      const [day, month, year] = date.split('-').map(Number)
      const original = new Date(Date.UTC(year, month - 1, day))
      if (original.getUTCDate() !== day || original.getUTCMonth() !== month - 1 || year < 2020 || year > 2100) return Response.json({ message: 'Tanggal tidak valid.' }, { status: 400 })
      const tomorrow = new Date(Date.UTC(year, month - 1, day + 1))
      const nextDate = `${String(tomorrow.getUTCDate()).padStart(2, '0')}-${String(tomorrow.getUTCMonth() + 1).padStart(2, '0')}-${tomorrow.getUTCFullYear()}`
      const query = new URLSearchParams({ latitude: String(latitude), longitude: String(longitude), method: '20', school: '0' })
      const [todayResponse, tomorrowResponse] = await Promise.all([fetchSource(`https://api.aladhan.com/v1/timings/${date}?${query}`), fetchSource(`https://api.aladhan.com/v1/timings/${nextDate}?${query}`)])
      data = { today: todayResponse, tomorrow: tomorrowResponse }
    } else return Response.json({ message: 'Sumber tidak ditemukan.' }, { status: 400 })
    return Response.json(data, { headers: { 'Cache-Control': resource === 'prayer' ? 'public, max-age=300, s-maxage=900' : 'public, max-age=3600, s-maxage=86400', 'X-Content-Type-Options': 'nosniff' } })
  } catch {
    return Response.json({ message: 'Sumber bacaan sedang tidak tersedia. Silakan coba kembali.' }, { status: 502, headers: { 'Cache-Control': 'no-store' } })
  }
}

export const config: Config = { path: '/api/islamic-data' }
