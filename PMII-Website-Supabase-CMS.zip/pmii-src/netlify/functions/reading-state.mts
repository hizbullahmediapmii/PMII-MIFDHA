import { createHash, randomUUID } from 'node:crypto'
import { and, eq } from 'drizzle-orm'
import type { Config } from '@netlify/functions'
import { getDb } from '../../db/index'
import { bookmarks, readingStates } from '../../db/schema'
import { surahIndex } from '../../src/data/surah-index'

export default async (request: Request) => {
  const headers = new Headers({ 'Cache-Control': 'private, no-store', 'Content-Type': 'application/json' })
  const cookie = request.headers.get('cookie')?.split(';').map(part => part.trim()).find(part => part.startsWith('pmii_reader='))?.slice(12)
  const validCookie = Boolean(cookie && /^[a-f0-9-]{36}$/.test(cookie))
  const token = cookie && /^[a-f0-9-]{36}$/.test(cookie) ? cookie : randomUUID()
  const secure = new URL(request.url).protocol === 'https:' ? '; Secure' : ''
  if (!validCookie) headers.append('Set-Cookie', `pmii_reader=${token}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Strict${secure}`)
  const deviceHash = createHash('sha256').update(token).digest('hex')
  const respond = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers })
  try {
    if (request.method !== 'GET') {
      const origin = request.headers.get('origin')
      if (!origin || origin !== new URL(request.url).origin) return respond({ message: 'Permintaan lintas situs ditolak.' }, 403)
    }
    const database = getDb()
    if (request.method === 'GET') {
      const [lastRead] = await database.select({ surah: readingStates.surah, ayah: readingStates.ayah }).from(readingStates).where(eq(readingStates.deviceHash, deviceHash))
      const saved = await database.select({ surah: bookmarks.surah, ayah: bookmarks.ayah }).from(bookmarks).where(eq(bookmarks.deviceHash, deviceHash))
      return respond({ lastRead: lastRead ?? null, bookmarks: saved })
    }
    if (request.method === 'DELETE') {
      await database.delete(bookmarks).where(eq(bookmarks.deviceHash, deviceHash))
      await database.delete(readingStates).where(eq(readingStates.deviceHash, deviceHash))
      headers.append('Set-Cookie', `pmii_reader=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict${secure}`)
      return respond({ deleted: true })
    }
    if (request.method !== 'POST') return respond({ message: 'Metode tidak didukung.' }, 405)
    if (Number(request.headers.get('content-length') ?? 0) > 1024) return respond({ message: 'Permintaan terlalu besar.' }, 413)
    const body = await request.json().catch(() => null)
    if (!body || !Number.isInteger(body.surah) || body.surah < 1 || body.surah > 114 || !Number.isInteger(body.ayah) || body.ayah < 1 || body.ayah > 286 || !['last-read', 'bookmark', 'remove'].includes(body.action)) return respond({ message: 'Data bacaan tidak valid.' }, 400)
    if (body.ayah > surahIndex[body.surah - 1].jumlahAyat) return respond({ message: 'Nomor ayat tidak tersedia dalam surah ini.' }, 400)
    const values = { deviceHash, surah: body.surah as number, ayah: body.ayah as number }
    if (body.action === 'last-read') await database.insert(readingStates).values(values).onConflictDoUpdate({ target: readingStates.deviceHash, set: { surah: values.surah, ayah: values.ayah, updatedAt: new Date() } })
    if (body.action === 'bookmark') {
      const current = await database.select({ surah: bookmarks.surah }).from(bookmarks).where(eq(bookmarks.deviceHash, deviceHash))
      if (current.length >= 200) return respond({ message: 'Maksimal 200 penanda per perangkat.' }, 400)
      await database.insert(bookmarks).values(values).onConflictDoNothing()
    }
    if (body.action === 'remove') await database.delete(bookmarks).where(and(eq(bookmarks.deviceHash, deviceHash), eq(bookmarks.surah, values.surah), eq(bookmarks.ayah, values.ayah)))
    return respond({ saved: true })
  } catch {
    return respond({ message: 'Penyimpanan bacaan belum tersedia. Bacaan tetap dapat dibuka; silakan coba lagi nanti.' }, 503)
  }
}

export const config: Config = { path: '/api/reading-state' }
