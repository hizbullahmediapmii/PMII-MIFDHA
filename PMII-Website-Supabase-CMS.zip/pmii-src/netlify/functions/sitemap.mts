import type { Config } from '@netlify/functions'
import { contentService } from '../../src/services/content'
import { siteUrl } from '../../src/utils/format'

export default async () => {
  const paths = ['', '/berita', '/materi', '/kegiatan', '/karya', '/agenda', '/angkatan', '/tentang', '/al-quran', '/dzikir', '/doa', '/jadwal-salat', '/arah-kiblat', '/kebijakan-publikasi', ...contentService.list().filter(item => !item.isDemo).map(item => `/${item.kind}/${item.slug}`), ...Array.from({ length: 114 }, (_, index) => `/al-quran/${index + 1}`)]
  const escape = (value: string) => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;')
  const xml = `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${paths.map(path => `<url><loc>${escape(`${siteUrl}${path}`)}</loc></url>`).join('')}</urlset>`
  return new Response(xml, { headers: { 'Content-Type': 'application/xml; charset=utf-8', 'Cache-Control': 'public, max-age=3600' } })
}

export const config: Config = { path: '/sitemap.xml' }
