import { lt } from 'drizzle-orm'
import type { Config } from '@netlify/functions'
import { getDb } from '../../db/index'
import { bookmarks, readingStates } from '../../db/schema'

export default async () => {
  const database = getDb()
  const cutoff = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000)
  await database.delete(readingStates).where(lt(readingStates.updatedAt, cutoff))
  await database.delete(bookmarks).where(lt(bookmarks.createdAt, cutoff))
}

export const config: Config = { schedule: '0 3 * * *' }
