# Project Guide

## Purpose and boundaries

This is the standalone public website for PMII Institut Miftahul Huda. It is an editorial/institutional publication, not a membership portal, dashboard, or SaaS application. Public routes are available without login. Never connect another application's database, import private member data, or add an appearance-only admin interface.

Only approved PUBLIC information belongs on this website. Do not invent institutional history, names of officers, event reports, achievements, contacts, or partner relationships. Keep examples visibly labeled until approved replacements are supplied.

## Architecture

- TanStack Start, React 19, TypeScript, Vite, and the Netlify Start adapter.
- `src/routes`: file-based routes. The home route is explicit; `$section.index.tsx` resolves sections and `$section.$slug.tsx` resolves public details and numbered Quran surahs. Invalid sections/slugs use real not-found handling.
- `src/components`: header/footer, mobile navigation, native dialogs, editorial primitives, Islamic circle navigation, and location picker.
- `src/pages`: home, collections, article/detail views, search, institutional pages, and five Islamic utilities. Utility pages are lazy-loaded.
- `src/data`: public DTOs, future repository contracts, read-only editorial fixtures, approved institutional fields, source-backed snapshots, and city coordinates.
- `src/services`: content adapter, validated Quran/doa services, reading preferences, and prayer schedule adapter.
- `src/utils`: date/time formatting, canonical origin, Image CDN URLs, opt-in geolocation, and Qibla calculation.
- `src/styles.css`: design tokens, editorial layouts, dark theme, mobile/tablet states, reading typography, focus, and reduced motion.
- `public/img`: unchanged official logo and disclosed illustrative photos.
- `db`: server-only Drizzle schema and lazy Netlify Database initialization.
- `netlify/functions`: modern .mts handlers for source proxying, anonymous reading preferences, retention cleanup, and sitemap.
- `netlify/database/migrations`: generated migrations applied by the platform.

## Data and persistence

Editorial fixtures are static demo content, not writable storage. No client-bundled fixture may contain PRIVATE, INTERNAL, or DRAFT records. The content adapter filters PUBLIC items for lists, search, and details; future data must be filtered and projected on the server before reaching the browser.

Future entities include articles, materials, works, activities, agendas, cohorts, categories, authors, and public profiles. Public DTOs deliberately exclude private phones, email, certificates, finances, credentials, and internal biodata. Preserve the visibility enum and explicit public-field projection when replacing fixtures.

Use Netlify Database and its Drizzle adapter for persistent records. Do not introduce local JSON writes, in-memory persistence, external databases, or copied connection strings. The database only writes anonymous Quran bookmarks and last-read positions. The prepared public-content table stays empty in this version.

Reading data is associated with a hashed random device cookie, not a user profile. Mutations validate Origin and verse bounds; reads are private/no-store. Keep device deletion and 365-day cleanup working. Theme preference is a non-sensitive browser cookie. The dzikir counter is deliberately session-only.

Schema changes require a new generated migration in the configured Netlify directory. Do not edit applied migrations. Read the Netlify Database skill before changing the mandated Drizzle beta adapter.

## Religious sources and location

Never generate or manually fabricate scripture, translations, hadith, ritual repetition counts, or religious rulings. Use EQuran.id for Quran text/translation and doa, preserving attribution. The 114-surah index and selected excerpts were retrieved on October 5, 2026. The source-unavailable fallback is explicitly partial, not a complete local Quran.

Morning/evening excerpts use EQuran text/translation and Hisnul Muslim chapter 27 placement references. They are not a complete sequence. Preserve explanatory distinctions, including the available after-witr excerpt. Hadith references follow the provider without independent authenticity claims.

Aladhan schedules use method 20 and both today and tomorrow. Validate dates, time formats, and timezones. Do not show guessed times when a source fails. The initial city is a manual Jakarta choice, not a claim about institute location.

Location and orientation permission requests must remain behind explicit user actions. Provide manual city/coordinate inputs. Qibla without a sensor is a true-north bearing diagram, not a live compass. Accept absolute sensor readings only, preserve calibration caveats, and clean up listeners.

## Design and conventions

Maintain midnight navy, warm white, restrained gold, subtle green, Lora headings, DM Sans UI, Noto Naskh Arabic, large photography, and connected circle navigation. Avoid dashboards, generic feature cards, oversized gradients, glassmorphism, excessive rounding, emoji icons, and fake statistics/testimonials.

Use semantic headings, readable width, descriptive alt text, visible keyboard focus, native dialog focus trapping, adequate touch targets, reduced motion, and the five-link mobile bottom navigation. Tablet is an independent breakpoint. Dark mode uses designed tokens, not inversion.

Use PascalCase components, camelCase functions, descriptive identifiers, strict TypeScript, and type-only imports. Keep UI, services, DTOs, and server database code separate. Avoid unnecessary dependencies and inline implementation comments. Write natural Indonesian prose.

Photos use Netlify Image CDN and responsive widths; most are lazy-loaded. Do not replace the PMII logo with an approximation, filter it, crop it, or change its proportions. The image was copied unmodified from the PMII website because an owner-supplied asset was not attached.

## SEO and deployment

Titles and descriptions identify the institution. The canonical origin is in `src/utils/format.ts`; update robots alongside it when adopting a verified custom domain. Do not add og:image: the platform supplies it. Demo details are noindex and excluded from sitemap. Article structured data is emitted only for non-demo content.

Use the existing Vite/Netlify adapter and functions configuration. Route-tree files are generated by the framework; do not maintain them manually. Follow environment restrictions on build, dev-server, and test commands. This implementation used static review, not browser or build validation.

The README contains local instructions, source attribution, release limitations, and the device/accessibility checklist. Never claim a check passed without running it in an environment that permits it.
