import { integer, jsonb, pgEnum, pgTable, primaryKey, text, timestamp } from 'drizzle-orm/pg-core'

export const visibility = pgEnum('content_visibility', ['DRAFT', 'PRIVATE', 'INTERNAL', 'PUBLIC'])

export const readingStates = pgTable('reading_states', {
  deviceHash: text('device_hash').primaryKey(),
  surah: integer('surah').notNull(),
  ayah: integer('ayah').notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
})

export const bookmarks = pgTable('quran_bookmarks', {
  deviceHash: text('device_hash').notNull(),
  surah: integer('surah').notNull(),
  ayah: integer('ayah').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, table => [primaryKey({ columns: [table.deviceHash, table.surah, table.ayah] })])

export const publicContent = pgTable('public_content', {
  id: text('id').primaryKey(),
  kind: text('kind').notNull(),
  slug: text('slug').notNull().unique(),
  title: text('title').notNull(),
  category: text('category').notNull(),
  visibility: visibility('visibility').default('DRAFT').notNull(),
  publicFields: jsonb('public_fields').notNull().$type<Record<string, unknown>>(),
  publishedAt: timestamp('published_at', { withTimezone: true }),
})
