# PMII Institut Miftahul Huda

Website publik organisasi dengan pendekatan editorial: ruang keislaman, perpustakaan materi, berita, kegiatan, karya sahabat, agenda, angkatan, dan informasi institusional. Seluruh halaman dapat diakses tanpa login. Proyek ini berdiri sendiri dan tidak mengakses sistem keanggotaan atau database aplikasi lain.

## Teknologi

- TanStack Start dan TanStack Router untuk halaman server-rendered dan rute bersih.
- React 19 dan TypeScript untuk komponen serta kontrak data.
- Vite dan integrasi resmi Netlify untuk deployment.
- CSS dengan token tema, breakpoint desktop/tablet/ponsel, dan Tailwind preflight.
- Lucide untuk ikon SVG; Lora, DM Sans, dan Noto Naskh Arabic untuk tipografi.
- Netlify Functions untuk proxy sumber bacaan, jadwal salat, penyimpanan bacaan, dan sitemap.
- Netlify Database dengan adapter Drizzle untuk penanda Al-Qur’an anonim pada proyek ini.
- Netlify Image CDN untuk WebP dan ukuran gambar responsif.

## Menjalankan secara lokal

```bash
pnpm install
netlify dev --port 8889
```

Gunakan Netlify Dev agar rute `/api/islamic-data`, `/api/reading-state`, sitemap, dan transformasi gambar tersedia. Situs perlu terhubung ke proyek Netlify ini untuk layanan platform. Tidak diperlukan kunci API untuk EQuran.id atau Aladhan. Jangan memasukkan kredensial layanan lain.

Pipeline Netlify menjalankan perintah build yang telah ditetapkan di `netlify.toml`. Build, dev server, dan pengujian browser tidak dijalankan dalam sesi implementasi ini; peninjauan dilakukan secara statis.

## Halaman

| Rute | Fungsi |
| --- | --- |
| `/` | Beranda editorial dan akses melingkar Ruang Keislaman |
| `/berita` | Berita, filter kategori, pilihan bacaan, dan keadaan tanpa data popularitas |
| `/materi` | Perpustakaan sepuluh kategori materi PMII |
| `/kegiatan` | Arsip dan dokumentasi kegiatan |
| `/karya` | Tujuh kategori karya sahabat |
| `/agenda` | Agenda, filter mendatang, detail, dan unduhan kalender ICS |
| `/angkatan` | Profil angkatan yang hanya memuat informasi publik |
| `/{berita,materi,kegiatan,karya,agenda,angkatan}/:slug` | Halaman detail, informasi publikasi, berbagi, dan bacaan terkait |
| `/tentang` | Institusi, sejarah, nilai, visi/misi, struktur, dan kontak yang disetujui |
| `/al-quran` | Indeks asli 114 surah, pencarian, bacaan terakhir, dan penanda |
| `/al-quran/:nomor` | Bacaan Arab, transliterasi, terjemahan, pencarian ayat, navigasi, ukuran huruf, salin, dan murattal |
| `/dzikir` | Delapan kategori, bacaan bersumber, dan pencatat sesi pribadi |
| `/doa` | Delapan kategori doa, pencarian, teks Arab, arti, dan rujukan |
| `/jadwal-salat` | Lima waktu, tanggal Hijriah, lokasi manual/perangkat, waktu berikutnya, dan hitung mundur |
| `/arah-kiblat` | Azimut kiblat, koordinat manual/perangkat, sensor berdasarkan izin, dan panduan tanpa sensor |
| `/cari?q=...` | Pencarian lintas publikasi dengan filter jenis dan keadaan kosong |
| `/kebijakan-publikasi` | Penjelasan contoh, privasi, sumber, dan penghapusan data bacaan perangkat |
| `/sitemap.xml` dan `/robots.txt` | Discovery mesin pencari; detail demo tidak masuk sitemap |

Rute yang tidak dikenal atau konten yang tidak PUBLIC mengembalikan halaman tidak ditemukan, bukan halaman kosong. Halaman detail contoh menggunakan `noindex, follow`. Tidak ada dashboard admin, pendaftaran, atau pengumpulan biodata.

## Konten dan informasi institusional

`src/data/content.ts` berisi fixture editorial read-only. Fixture bukan database yang menerima penulisan dari pengguna. Setiap contoh diberi `isDemo: true`; label contoh dan foto ilustrasi terlihat pada daftar serta detail. Jadwal contoh dan berkas ICS bukan undangan resmi. Peringkat populer tidak direkayasa ketika statistik pembaca belum tersedia. Waktu baca dihitung dari panjang naskah.

`src/data/institution.ts` adalah tempat informasi institusional yang disetujui. Logo dan dokumen institusional tidak dilampirkan dalam jawaban pengguna. Karena itu logo PMII diambil dari situs organisasi, sementara sejarah lokal, visi, misi, struktur, alamat, email, dan kanal sosial tetap tidak diisi dengan informasi rekaan. Isi field yang disediakan hanya dengan informasi resmi yang mendapatkan persetujuan publikasi.

Logo asli di `public/img/pmii-official.png` merupakan salinan tidak dimodifikasi dari:

```text
https://pmii.id/assets/frontend/images/apple-touch-icon2.png
```

Gambar ditampilkan dengan `object-fit: contain`, tanpa filter, pemotongan, atau penggambaran ulang. Ketika aset resmi yang disediakan pengelola tersedia, gunakan file tersebut dan pertahankan proporsinya.

## Sumber bacaan

Sumber Al-Qur’an:

```text
https://equran.id/apidev
https://equran.id/api/v2/surat
https://equran.id/api/v2/surat/{nomor}
```

`src/data/surah-index.ts` menyimpan metadata 114 surah yang diambil pada 5 Oktober 2026. Teks lengkap dimuat per surah melalui proxy dengan validasi nomor dan struktur respons. Jika sumber tidak tersedia, hanya Al-Fatihah yang dapat tampil sebagai cuplikan tersimpan dari sumber yang sama; surah lain menampilkan kesalahan dan tombol coba kembali. Tidak ada ayat yang dibuat sendiri, dan fallback bukan salinan lengkap Al-Qur’an.

Sumber doa:

```text
https://equran.id/api/doa
```

`src/data/verified-readings.ts` juga memuat cuplikan doa bersumber yang digunakan saat layanan langsung tidak tersedia. Teks, arti, dan keterangan rujukan mengikuti penyedia, tanpa penilaian mandiri terhadap derajat hadis. Kategori dzikir pagi/petang menggunakan pilihan ayat dengan teks dan terjemahan EQuran.id serta rujukan penempatan bacaan Hisnul Muslim:

```text
https://www.hisnmuslim.com/api/ar/27.json
```

Pilihan ini dinyatakan sebagai cuplikan, bukan rangkaian dzikir lengkap. Kategori setelah salat menjelaskan secara khusus bahwa cuplikan yang tersedia adalah setelah salat witir. Pencatat dzikir hanya menghitung sesi berjalan dan bukan ketentuan jumlah amalan.

Jadwal salat menggunakan Aladhan, metode 20 (Kementerian Agama Republik Indonesia), berdasarkan koordinat yang dipilih:

```text
https://aladhan.com/prayer-times-api
```

Sumber hari berikutnya juga dimuat agar hitung mundur setelah Isya menggunakan Subuh besok, bukan pengulangan waktu hari ini. Zona waktu serta tanggal sumber diperiksa. Jadwal merupakan hasil perhitungan, bukan pengganti pengumuman otoritas setempat. Jakarta adalah pilihan manual awal, bukan klaim lokasi kampus. Izin lokasi dan kompas selalu diminta setelah tindakan pengguna. Tidak ada notifikasi otomatis.

## Penyimpanan dan privasi

`db/schema.ts` mendefinisikan tabel penanda, posisi terakhir, enum `DRAFT | PRIVATE | INTERNAL | PUBLIC`, dan tabel kosong untuk integrasi konten publik mendatang. `db/index.ts` memakai adapter Netlify Database tanpa connection string aplikasi lain. Migrasi sudah dihasilkan di `netlify/database/migrations/` dan diterapkan oleh platform saat deploy.

Preferensi membaca dikaitkan dengan pengenal perangkat acak di cookie HttpOnly, SameSite=Strict, Secure pada HTTPS. Database hanya menerima hash pengenal, nomor surah/ayat yang valid, serta timestamp; tidak ada nama, email, atau profil kader. Respons membaca bersifat private/no-store. Operasi perubahan memeriksa Origin, jumlah penanda dibatasi, dan data perangkat dapat dihapus dari halaman privasi. Fungsi terjadwal membersihkan penanda dan bacaan tidak aktif yang lebih dari 365 hari.

Untuk perubahan skema, hasilkan migrasi baru, jangan mengubah migrasi yang telah diterapkan:

```bash
pnpm exec drizzle-kit generate --name add_public_content_fields
```

Drizzle beta digunakan karena adapter `drizzle-orm/netlify-db` disediakan pada jalur paket tersebut. Ikuti instruksi skill Netlify Database sebelum mengubah versi atau adapter.

## Integrasi konten di masa mendatang

Kontrak berada di `src/data/types.ts` dan `src/data/contracts.ts`; UI mendapatkan data melalui `src/services/content.ts`. Untuk backend nyata, buat repository server-only pada database situs ini dan gunakan loader server. Filter `visibility = PUBLIC` sebelum mengirim respons, lalu proyeksikan field publik secara eksplisit. Jangan mengirim baris internal lengkap ke browser lalu menyaringnya di frontend. Jangan pernah menaruh data privat dalam fixture TypeScript yang ikut terbundel.

Entity yang disiapkan mencakup publikasi berita, materi, karya, kegiatan, agenda, angkatan, kategori, penulis, dan profil publik. Quran dan jadwal memiliki adapter serta validasi masing-masing. Backend publik tidak terhubung pada versi pertama; tabel konten tidak diisi dengan contoh. Hanya preferensi bacaan anonim yang ditulis ke database.

Saat mengganti domain, perbarui `siteUrl` di `src/utils/format.ts` dan URL sitemap di `public/robots.txt`. Open Graph menggunakan nama dan deskripsi produk; gambar share disediakan platform, bukan `og:image` buatan aplikasi.

## Kredit fotografi

Foto ilustrasi lokal berasal dari Unsplash, bukan dokumentasi organisasi atau karya fotografi anggota:

```text
https://images.unsplash.com/photo-1523240795612-9a054b0db644
https://images.unsplash.com/photo-1507842217343-583bb7270b66
https://images.unsplash.com/photo-1455390582262-044cdead277a
https://images.unsplash.com/photo-1519681393784-d120267933ba
```

Field gambar menyimpan sumber, alt, kredit, dan status ilustrasi agar penggantian dengan foto resmi berizin tidak memerlukan perubahan tata letak.

## Pemeriksaan sebelum publikasi resmi

Periksa desktop 1440 px, tablet 820 px, ponsel 390 px, dan layar minimum 320 px dalam kedua tema. Periksa navigasi, menu serta pencarian dengan keyboard, dialog dan Escape, lingkar akses keislaman, filter, unduhan kalender, bacaan Arab, penanda setelah muat ulang, serta penghapusan data. Uji kegagalan sumber API, izin lokasi yang ditolak, dan perangkat tanpa sensor kompas. Pastikan tidak ada overflow halaman, konten privat, atau label contoh yang keliru dihapus sebelum informasi resmi disetujui. Jalankan pemeriksaan browser setelah build/deploy platform selesai; checklist ini bukan klaim pengujian yang telah dilakukan.
