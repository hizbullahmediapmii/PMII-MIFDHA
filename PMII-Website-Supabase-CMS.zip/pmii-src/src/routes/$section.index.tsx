import { createFileRoute, notFound } from '@tanstack/react-router'
import { SectionPage } from '@/pages/SectionPage'
import { sectionInfo } from '@/services/content'
import { pageHead } from '@/utils/format'

export const Route = createFileRoute('/$section/')({
  validateSearch: (search: Record<string, unknown>) => ({ q: typeof search.q === 'string' ? search.q : '', kategori: typeof search.kategori === 'string' ? search.kategori : '', jenis: typeof search.jenis === 'string' ? search.jenis : '', ayat: typeof search.ayat === 'string' || typeof search.ayat === 'number' ? String(search.ayat) : '' }),
  loader: ({ params }) => {
    const info = sectionInfo(params.section)
    if (!info) throw notFound()
    return info
  },
  head: ({ loaderData, params }) => loaderData ? pageHead(loaderData.title, loaderData.description, `/${params.section}`, params.section === 'cari') : {},
  component: Page,
})

function Page() {
  const { section } = Route.useParams()
  const search = Route.useSearch()
  return <SectionPage section={section} search={search} />
}
