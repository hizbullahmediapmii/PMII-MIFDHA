import { createFileRoute, notFound } from '@tanstack/react-router'
import { lazy, Suspense } from 'react'
import { ArticlePage } from '@/pages/ArticlePage'
import { contentService } from '@/services/content'
import { surahIndex } from '@/data/surah-index'
import { pageHead } from '@/utils/format'

const QuranPage = lazy(() => import('@/pages/QuranPage').then(module => ({ default: module.QuranPage })))

export const Route = createFileRoute('/$section/$slug')({
  validateSearch: (search: Record<string, unknown>) => ({ ayat: typeof search.ayat === 'number' || typeof search.ayat === 'string' ? String(search.ayat) : '' }),
  loader: ({ params }) => {
    if (params.section === 'al-quran' && /^\d+$/.test(params.slug) && Number(params.slug) >= 1 && Number(params.slug) <= 114) return { item: null, surah: Number(params.slug) }
    const item = contentService.find(params.section, params.slug)
    if (!item) throw notFound()
    return { item, surah: null }
  },
  head: ({ loaderData, params }) => loaderData?.item ? pageHead(loaderData.item.title, loaderData.item.excerpt, `/${params.section}/${params.slug}`, loaderData.item.isDemo) : pageHead(`Al-Qur’an · ${surahIndex.find(item => item.nomor === Number(params.slug))?.namaLatin ?? 'Surah'}`, 'Bacaan Al-Qur’an dengan teks Arab dan terjemahan bahasa Indonesia dari EQuran.id.', `/${params.section}/${params.slug}`),
  component: Page,
})

function Page() {
  const { item, surah } = Route.useLoaderData()
  const { ayat } = Route.useSearch()
  return item ? <ArticlePage item={item} /> : <Suspense fallback={<div className="container reading-skeleton" role="status"><span /><span /><p>Memuat ruang bacaan…</p></div>}><QuranPage surahNumber={surah ?? 1} initialAyah={ayat} /></Suspense>
}
