import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'
import type { ReactNode } from 'react'
import { MobileBottomNav, SiteFooter, SiteHeader } from '@/components/SiteShell'
import { siteUrl, structuredJson } from '@/utils/format'

import '../styles.css'

const siteName = 'PMII Institut Miftahul Huda | Keislaman, Keilmuan & Pergerakan'
const siteDescription = 'Ruang keislaman, keilmuan, kaderisasi, dan informasi Pergerakan Mahasiswa Islam Indonesia di Institut Miftahul Huda.'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      {
        charSet: 'utf-8',
      },
      {
        name: 'viewport',
        content: 'width=device-width, initial-scale=1',
      },
      {
        title: siteName,
      },
      {
        name: 'description',
        content: siteDescription,
      },
      {
        property: 'og:title',
        content: siteName,
      },
      {
        property: 'og:description',
        content: siteDescription,
      },
      {
        property: 'og:type',
        content: 'website',
      },
      {
        name: 'twitter:card',
        content: 'summary_large_image',
      },
      { property: 'og:site_name', content: 'PMII Institut Miftahul Huda' },
      { property: 'og:locale', content: 'id_ID' },
      { name: 'theme-color', content: '#112d37' },
    ],
    links: [
      { rel: 'icon', type: 'image/png', href: '/img/pmii-official.png' },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
      { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Lora:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Noto+Naskh+Arabic:wght@400;500;600&display=swap' },
    ],
    scripts: [{ children: `try{var themeCookie=document.cookie.split(';').map(function(cookiePart){return cookiePart.trim()}).find(function(cookiePart){return cookiePart.startsWith('pmii_theme=')});var themePreference=themeCookie?themeCookie.split('=')[1]:'';document.documentElement.dataset.theme=themePreference==='dark'||themePreference==='light'?themePreference:(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light')}catch{}` }],
  }),
  notFoundComponent: () => <div className="container error-page"><p className="eyebrow">HALAMAN TIDAK DITEMUKAN · 404</p><h1>Ruang ini belum tersedia.</h1><p>Alamat mungkin berubah atau konten belum disetujui untuk publik.</p><a className="button" href="/">Kembali ke beranda</a></div>,
  errorComponent: ({ reset }) => <div className="container error-page"><h1>Halaman belum dapat dimuat.</h1><p>Silakan coba kembali. Data pribadi tidak ditampilkan pada situs ini.</p><button className="button" onClick={reset}>Coba kembali</button></div>,
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: ReactNode }) {
  return (
    <html lang="id" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <a className="skip-link" href="#main-content">Langsung ke konten</a>
        <SiteHeader />
        <main id="main-content" tabIndex={-1}>{children}</main>
        <SiteFooter />
        <MobileBottomNav />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: structuredJson({ '@context': 'https://schema.org', '@type': 'Organization', name: 'PMII Institut Miftahul Huda', url: siteUrl, logo: `${siteUrl}/img/pmii-official.png` }) }} />
        <Scripts />
      </body>
    </html>
  )
}
