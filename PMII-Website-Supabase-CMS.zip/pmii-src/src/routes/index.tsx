import { createFileRoute } from '@tanstack/react-router'

import { HomePage } from '@/pages/HomePage'
import { siteUrl } from '@/utils/format'

export const Route = createFileRoute('/')({
  component: HomePage,
  head: () => ({ links: [{ rel: 'canonical', href: siteUrl }], meta: [{ property: 'og:url', content: siteUrl }] }),
})
