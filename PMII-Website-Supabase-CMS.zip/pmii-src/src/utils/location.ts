import type { PublicLocation } from '@/data/locations'

export async function requestLocation(): Promise<PublicLocation> {
  if (!navigator.geolocation) throw new Error('Peramban tidak mendukung lokasi. Pilih kota atau masukkan koordinat secara manual.')
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(position => resolve({ name: 'Lokasi perangkat', latitude: position.coords.latitude, longitude: position.coords.longitude, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone }), error => reject(new Error(error.code === 1 ? 'Izin lokasi tidak diberikan. Gunakan pilihan lokasi manual.' : 'Lokasi belum dapat ditemukan. Gunakan pilihan lokasi manual.')), { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 })
  })
}

export function qiblaBearing(latitude: number, longitude: number): number {
  const radians = (degrees: number) => degrees * Math.PI / 180
  const kaabaLatitude = radians(21.422487)
  const longitudeDifference = radians(39.826206 - longitude)
  const fromLatitude = radians(latitude)
  const numerator = Math.sin(longitudeDifference) * Math.cos(kaabaLatitude)
  const denominator = Math.cos(fromLatitude) * Math.sin(kaabaLatitude) - Math.sin(fromLatitude) * Math.cos(kaabaLatitude) * Math.cos(longitudeDifference)
  return (Math.atan2(numerator, denominator) * 180 / Math.PI + 360) % 360
}

export function localClock(date: Date, timezone: string) {
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: timezone, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(date)
  const get = (name: string) => parts.find(part => part.type === name)?.value ?? '00'
  return { date: `${get('day')}-${get('month')}-${get('year')}`, seconds: Number(get('hour')) * 3600 + Number(get('minute')) * 60 + Number(get('second')) }
}
