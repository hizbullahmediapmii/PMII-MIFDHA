export const siteUrl = 'https://comfy-clafoutis-a7c50c.netlify.app'

export function structuredJson(value: unknown) {
  return (JSON.stringify(value) ?? 'null').replace(/</g, '\\u003c')
}

export function formatDate(value: string, options?: Intl.DateTimeFormatOptions) {
  return new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta', ...options }).format(new Date(value))
}

export function formatTime(value: string) {
  return new Intl.DateTimeFormat('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' }).format(new Date(value))
}

export function imageUrl(src: string, width: number) {
  return `/.netlify/images?url=${encodeURIComponent(src)}&w=${width}&fm=webp&q=82`
}

export function pageHead(title: string, description: string, path: string, demo = false) {
  return {
    meta: [
      { title: `${title} | PMII Institut Miftahul Huda` },
      { name: 'description', content: description },
      { property: 'og:title', content: `${title} | PMII Institut Miftahul Huda` },
      { property: 'og:description', content: description },
      { property: 'og:url', content: `${siteUrl}${path}` },
      ...(demo ? [{ name: 'robots', content: 'noindex, follow' }] : []),
    ],
    links: [{ rel: 'canonical', href: `${siteUrl}${path}` }],
  }
}
