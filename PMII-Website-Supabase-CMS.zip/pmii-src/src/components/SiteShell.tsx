import { useEffect, useRef, useState } from 'react'
import { useLocation } from '@tanstack/react-router'
import { ArrowUpRight, BookOpen, GraduationCap, Home, Menu, Moon, Newspaper, Search, Sun, Users, X } from 'lucide-react'
import { contentService } from '@/services/content'

const primaryLinks = [
  { label: 'Beranda', href: '/' },
  { label: 'Berita', href: '/berita' },
  { label: 'Ruang Belajar', href: '/materi' },
  { label: 'Kegiatan', href: '/kegiatan' },
  { label: 'Tentang', href: '/tentang' },
]
const allLinks = [...primaryLinks, { label: 'Karya Sahabat', href: '/karya' }, { label: 'Agenda', href: '/agenda' }, { label: 'Angkatan', href: '/angkatan' }]
const islamicLinks = [{ label: 'Al-Qur’an', href: '/al-quran' }, { label: 'Dzikir', href: '/dzikir' }, { label: 'Doa', href: '/doa' }, { label: 'Jadwal Salat', href: '/jadwal-salat' }, { label: 'Arah Kiblat', href: '/arah-kiblat' }]

export function Brand({ footer = false }: { footer?: boolean }) {
  return <a className={`brand ${footer ? 'footer-brand' : ''}`} href="/" aria-label="PMII Institut Miftahul Huda — Beranda"><img src="/img/pmii-official.png" width={48} height={48} alt="Logo resmi PMII" /><span><strong>PMII</strong><span>INSTITUT MIFTAHUL HUDA</span></span></a>
}

export function SiteHeader() {
  const pathname = useLocation({ select: location => location.pathname })
  const searchRef = useRef<HTMLDialogElement>(null)
  const menuRef = useRef<HTMLDialogElement>(null)
  const [query, setQuery] = useState('')
  const [dark, setDark] = useState(false)
  useEffect(() => { setDark(document.documentElement.dataset.theme === 'dark') }, [])
  const toggleTheme = () => {
    const next = !dark
    document.documentElement.dataset.theme = next ? 'dark' : 'light'
    document.cookie = `pmii_theme=${next ? 'dark' : 'light'}; Path=/; Max-Age=31536000; SameSite=Lax`
    setDark(next)
  }
  const results = query.trim() ? contentService.search(query).slice(0, 5) : []
  return <>
    <div className="utility-bar"><div className="container"><span>PERGERAKAN MAHASISWA ISLAM INDONESIA</span><span>Keislaman <i>·</i> Keilmuan <i>·</i> Keindonesiaan</span></div></div>
    <header className="site-header"><div className="container header-inner"><Brand /><nav className="desktop-nav" aria-label="Navigasi utama">{primaryLinks.map(link => <a key={link.href} href={link.href} className={pathname === link.href || (link.href !== '/' && pathname.startsWith(`${link.href}/`)) ? 'active' : ''} aria-current={pathname === link.href ? 'page' : undefined}>{link.label}</a>)}<details className="nav-more"><summary>Lainnya</summary><div>{allLinks.slice(5).map(link => <a href={link.href} key={link.href}>{link.label}<ArrowUpRight size={14} /></a>)}<a href="/al-quran">Ruang Keislaman<ArrowUpRight size={14} /></a></div></details></nav><div className="header-actions"><button className="icon-button" onClick={() => searchRef.current?.showModal()} aria-label="Buka pencarian"><Search size={20} /></button><span className="action-divider" /><button className="icon-button theme-button" onClick={toggleTheme} aria-label={dark ? 'Gunakan tema terang' : 'Gunakan tema gelap'} aria-pressed={dark}>{dark ? <Sun size={19} /> : <Moon size={19} />}</button><button className="icon-button menu-button" onClick={() => menuRef.current?.showModal()} aria-label="Buka menu navigasi"><Menu size={22} /></button></div></div></header>
    <dialog ref={searchRef} className="search-dialog" aria-labelledby="search-title" onClick={event => { if (event.target === event.currentTarget) searchRef.current?.close() }}><div className="dialog-content"><div className="dialog-top"><p className="eyebrow">TELUSURI RUANG PERGERAKAN</p><button className="icon-button" aria-label="Tutup pencarian" onClick={() => searchRef.current?.close()}><X size={22} /></button></div><h2 id="search-title">Apa yang ingin Anda baca?</h2><form action="/cari" method="get" className="search-form"><Search size={22} aria-hidden="true" /><label className="sr-only" htmlFor="global-search">Kata pencarian</label><input id="global-search" name="q" placeholder="Berita, materi, karya, atau agenda…" value={query} onChange={event => setQuery(event.target.value)} autoComplete="off" autoFocus /><button type="submit" className="button">Cari<ArrowUpRight size={17} /></button></form><div aria-live="polite">{results.map(item => <a className="search-suggestion" href={`/${item.kind}/${item.slug}`} key={item.id}><span><small>{item.category} · Contoh editorial</small><strong>{item.title}</strong></span><ArrowUpRight size={20} /></a>)}{query.trim() && results.length === 0 && <p className="search-empty">Belum ada hasil untuk “{query}”. Coba kata yang lebih singkat.</p>}{!query.trim() && <p className="search-hint">Mulai dari <a href="/materi">bahan belajar</a>, <a href="/berita">berita terbaru</a>, atau <a href="/karya">karya sahabat</a>.</p>}</div></div></dialog>
    <dialog ref={menuRef} className="menu-dialog" aria-labelledby="menu-title"><div className="dialog-top"><h2 id="menu-title">Ruang Pergerakan</h2><button className="icon-button" aria-label="Tutup menu" onClick={() => menuRef.current?.close()}><X size={23} /></button></div><nav aria-label="Navigasi lengkap" className="mobile-links">{allLinks.map((link, index) => <a href={link.href} key={link.href}><span className="menu-number">0{index + 1}</span>{link.label}<ArrowUpRight size={18} /></a>)}</nav><p className="eyebrow menu-label">RUANG KEISLAMAN</p><nav className="mobile-islamic" aria-label="Ruang Keislaman">{islamicLinks.map(link => <a key={link.href} href={link.href}>{link.label}</a>)}</nav></dialog>
  </>
}

export function SiteFooter() {
  return <footer className="site-footer"><div className="container"><div className="footer-grid"><div className="footer-intro"><Brand footer /><p>Ruang keislaman, keilmuan, dan pergerakan. Merawat nilai, mempertemukan gagasan, mempererat persahabatan.</p><a className="footer-contact" href="/tentang#kontak">Informasi kontak resmi<ArrowUpRight size={16} /></a></div><div><h2>Ruang Pergerakan</h2><a href="/berita">Berita</a><a href="/kegiatan">Kegiatan</a><a href="/karya">Karya Sahabat</a><a href="/agenda">Agenda</a></div><div><h2>Ruang Keislaman</h2>{islamicLinks.map(link => <a key={link.href} href={link.href}>{link.label}</a>)}</div><div><h2>Belajar & Mengenal</h2><a href="/materi">Materi PMII</a><a href="/materi?kategori=Aswaja">Aswaja</a><a href="/angkatan">Angkatan</a><a href="/tentang">Tentang PMII</a><a href="/tentang#kontak">Kontak & media sosial</a></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} PMII Institut Miftahul Huda</span><span>Keislaman. Keilmuan. Pergerakan.</span><a href="/kebijakan-publikasi">Publikasi & privasi</a></div></div></footer>
}

export function MobileBottomNav() {
  const pathname = useLocation({ select: location => location.pathname })
  const links = [{ label: 'Beranda', href: '/', icon: Home }, { label: 'Belajar', href: '/materi', icon: BookOpen }, { label: 'Berita', href: '/berita', icon: Newspaper }, { label: 'Angkatan', href: '/angkatan', icon: Users }, { label: 'Tentang', href: '/tentang', icon: GraduationCap }]
  return <nav className="bottom-nav" aria-label="Navigasi cepat seluler">{links.map(link => <a className={pathname === link.href || (link.href !== '/' && pathname.startsWith(`${link.href}/`)) ? 'active' : ''} href={link.href} key={link.href} aria-current={pathname === link.href ? 'page' : undefined}><link.icon size={20} strokeWidth={1.6} /><span>{link.label}</span></a>)}</nav>
}
