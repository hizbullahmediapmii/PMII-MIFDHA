import { ArrowDown, ArrowRight, ArrowUpRight } from 'lucide-react'
import type { ReactNode } from 'react'
import type { ContentEntry, PublicImage } from '@/data/types'
import { formatDate, imageUrl } from '@/utils/format'

export function Arrow({ diagonal = false }: { diagonal?: boolean }) {
  return diagonal ? <ArrowUpRight size={17} aria-hidden="true" /> : <ArrowRight size={17} aria-hidden="true" />
}

export function Photo({ image, className = '', eager = false, sizes = '(max-width: 650px) 100vw, (max-width: 1050px) 50vw, 600px' }: { image: PublicImage; className?: string; eager?: boolean; sizes?: string }) {
  return <img className={className} src={imageUrl(image.src, 960)} srcSet={`${imageUrl(image.src, 240)} 240w, ${imageUrl(image.src, 480)} 480w, ${imageUrl(image.src, 800)} 800w, ${imageUrl(image.src, 1200)} 1200w, ${imageUrl(image.src, 1600)} 1600w`} sizes={sizes} alt={image.alt} width={960} height={640} loading={eager ? 'eager' : 'lazy'} decoding="async" />
}

export function SectionHeading({ eyebrow, title, href, label = 'Lihat semua', children }: { eyebrow: string; title: string; href?: string; label?: string; children?: ReactNode }) {
  return <div className="section-heading"><div><p className="eyebrow">{eyebrow}</p><h2>{title}</h2>{children}</div>{href && <a className="text-link" href={href}>{label}<Arrow /></a>}</div>
}

export function ContentCard({ item, large = false, headingLevel = 3 }: { item: ContentEntry; large?: boolean; headingLevel?: 2 | 3 }) {
  const Heading = headingLevel === 2 ? 'h2' : 'h3'
  return <article className={`editorial-card ${large ? 'large' : ''}`}><a href={`/${item.kind}/${item.slug}`} className="photo-link"><Photo image={item.image} /><span className="photo-note">{item.image.illustrative ? 'Foto ilustrasi' : 'Dokumentasi publik'}</span></a><div className="card-body"><div className="entry-category"><span>{item.category}</span>{item.isDemo && <span className="demo-tag">Contoh editorial</span>}</div><Heading><a href={`/${item.kind}/${item.slug}`}>{item.title}</a></Heading>{large && <p className="card-excerpt">{item.excerpt}</p>}<div className="entry-meta"><time dateTime={item.publishedAt}>{formatDate(item.publishedAt)}</time><span>·</span><span>{item.readingMinutes} menit baca</span></div></div></article>
}

export function Breadcrumb({ items }: { items: { label: string; href?: string }[] }) {
  return <nav className="breadcrumb" aria-label="Jejak navigasi"><a href="/">Beranda</a>{items.map((item, index) => <span key={`${item.label}-${index}`}><span aria-hidden="true">/</span>{item.href ? <a href={item.href}>{item.label}</a> : <span aria-current="page">{item.label}</span>}</span>)}</nav>
}

export function DemoNotice({ short = false }: { short?: boolean }) {
  return <div className="demo-notice"><span className="notice-dot" /><p>{short ? 'Konten contoh · Foto ilustrasi, bukan dokumentasi organisasi.' : 'Konten contoh untuk memperlihatkan struktur publikasi. Nama kegiatan, jadwal, dan foto bukan informasi resmi organisasi. Publikasi resmi ditampilkan setelah persetujuan pengelola.'}</p><a href="/kebijakan-publikasi" aria-label="Baca kebijakan publikasi"><Arrow /></a></div>
}

export function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="empty-state"><span className="empty-symbol"><ArrowDown size={25} /></span><h2>{title}</h2><p>{text}</p></div>
}
