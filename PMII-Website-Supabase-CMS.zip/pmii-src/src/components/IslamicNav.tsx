import { ArrowUpRight, BookOpen, Compass, HandHeart, MoonStar, Sun } from 'lucide-react'

export const islamicItems = [
  { label: 'Al-Qur’an', href: '/al-quran', icon: BookOpen, note: 'Baca & renungkan' },
  { label: 'Dzikir', href: '/dzikir', icon: MoonStar, note: 'Tenangkan hati' },
  { label: 'Doa', href: '/doa', icon: HandHeart, note: 'Dalam keseharian' },
  { label: 'Jadwal Salat', href: '/jadwal-salat', icon: Sun, note: 'Jaga waktu ibadah' },
  { label: 'Arah Kiblat', href: '/arah-kiblat', icon: Compass, note: 'Temukan arah' },
]

export function IslamicNav({ compact = false }: { compact?: boolean }) {
  return <nav className={`islamic-nav ${compact ? 'compact' : ''}`} aria-label="Akses cepat Ruang Keislaman">{islamicItems.map(item => <a href={item.href} key={item.href}><span className="islamic-circle"><item.icon size={29} strokeWidth={1.25} /><ArrowUpRight className="circle-arrow" size={12} /></span><strong>{item.label}</strong>{!compact && <span className="circle-note">{item.note}</span>}</a>)}</nav>
}
