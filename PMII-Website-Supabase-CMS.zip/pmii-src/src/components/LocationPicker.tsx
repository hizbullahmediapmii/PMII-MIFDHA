import { useState } from 'react'
import { LocateFixed, MapPin } from 'lucide-react'
import { locations } from '@/data/locations'
import type { PublicLocation } from '@/data/locations'
import { requestLocation } from '@/utils/location'

export function LocationPicker({ location, onChange, coordinates = false }: { location: PublicLocation; onChange: (value: PublicLocation) => void; coordinates?: boolean }) {
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [latitude, setLatitude] = useState(String(location.latitude))
  const [longitude, setLongitude] = useState(String(location.longitude))
  const update = (next: PublicLocation) => { onChange(next); setLatitude(String(next.latitude)); setLongitude(String(next.longitude)); setMessage('') }
  const locate = async () => {
    setBusy(true); setMessage('Mencari lokasi setelah persetujuan Anda…')
    try { const next = await requestLocation(); update(next) } catch (reason) { setMessage(reason instanceof Error ? reason.message : 'Lokasi tidak tersedia.') } finally { setBusy(false) }
  }
  return <div className="location-picker"><div className="location-picker-row"><label><MapPin size={17} /><span className="sr-only">Pilih lokasi manual</span><select value={locations.some(item => item.name === location.name) ? location.name : 'custom'} onChange={event => { const next = locations.find(item => item.name === event.target.value); if (next) update(next) }}>{!locations.some(item => item.name === location.name) && <option value="custom">{location.name}</option>}{locations.map(item => <option value={item.name} key={item.name}>{item.name} · pilihan manual</option>)}</select></label><button className="outline-button" disabled={busy} onClick={locate}><LocateFixed size={16} />{busy ? 'Mencari…' : 'Gunakan lokasi saya'}</button></div>{coordinates && <details className="coordinate-input"><summary>Masukkan koordinat lain</summary><form onSubmit={event => { event.preventDefault(); const nextLatitude = Number(latitude); const nextLongitude = Number(longitude); if (!latitude.trim() || !longitude.trim() || !Number.isFinite(nextLatitude) || nextLatitude <= -90 || nextLatitude >= 90 || !Number.isFinite(nextLongitude) || nextLongitude < -180 || nextLongitude > 180) { setMessage('Lintang harus di antara −90 dan 90; bujur di antara −180 dan 180.'); return }; update({ name: 'Koordinat manual', latitude: nextLatitude, longitude: nextLongitude, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone }) }}><label>Lintang<input value={latitude} onChange={event => setLatitude(event.target.value)} inputMode="decimal" /></label><label>Bujur<input value={longitude} onChange={event => setLongitude(event.target.value)} inputMode="decimal" /></label><button type="submit" className="button">Terapkan</button></form></details>}<p className="location-status" role="status">{message}</p></div>
}
