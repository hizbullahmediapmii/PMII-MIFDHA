import type { ContentEntry, ContentKind, PublicImage, Visibility } from './types'

export interface PublicCategory {
  id: string
  name: string
  slug: string
  kinds: ContentKind[]
}

export interface PublicAuthor {
  id: string
  displayName: string
  biography?: string
  approvedPhoto?: PublicImage
  visibility: Visibility
}

export interface PublicProfile {
  id: string
  displayName: string
  publicRole?: string
  approvedBiography?: string
  approvedPhoto?: PublicImage
  visibility: Visibility
}

export interface PublicContentRepository {
  list(kind?: ContentKind): Promise<ContentEntry[]>
  find(kind: ContentKind, slug: string): Promise<ContentEntry | null>
  search(query: string, kinds?: ContentKind[]): Promise<ContentEntry[]>
}
