export type Visibility = 'DRAFT' | 'PRIVATE' | 'INTERNAL' | 'PUBLIC'
export type ContentKind = 'berita' | 'materi' | 'kegiatan' | 'karya' | 'agenda' | 'angkatan'

export interface PublicImage {
  src: string
  alt: string
  credit: string
  illustrative: boolean
}

export interface ContentEntry {
  id: string
  slug: string
  kind: ContentKind
  title: string
  category: string
  excerpt: string
  body: { heading?: string; text: string }[]
  image: PublicImage
  author: { name: string; role: string }
  publishedAt: string
  readingMinutes: number
  visibility: Visibility
  isDemo: boolean
  event?: { startsAt: string; endsAt: string; location: string; organizer: string }
  cohort?: { year: number; achievements: string[] }
  documentation?: PublicImage[]
}

export interface Section {
  title: string
  eyebrow: string
  description: string
  categories: string[]
}
