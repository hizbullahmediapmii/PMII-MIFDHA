export const verifiedFatihah = {
  "nomor": 1,
  "nama": "الفاتحة",
  "namaLatin": "Al-Fatihah",
  "jumlahAyat": 7,
  "tempatTurun": "Mekah",
  "arti": "Pembukaan",
  "ayat": [
    {
      "nomorAyat": 1,
      "teksArab": "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ",
      "teksLatin": "Bismillāhir-raḥmānir-raḥīm(i). ",
      "teksIndonesia": "Dengan nama Allah Yang Maha Pengasih lagi Maha Penyayang.",
      "audio": {
        "01": "https://cdn.equran.id/audio-partial/Abdullah-Al-Juhany/001001.mp3",
        "02": "https://cdn.equran.id/audio-partial/Abdul-Muhsin-Al-Qasim/001001.mp3",
        "03": "https://cdn.equran.id/audio-partial/Abdurrahman-as-Sudais/001001.mp3",
        "04": "https://cdn.equran.id/audio-partial/Ibrahim-Al-Dossari/001001.mp3",
        "05": "https://cdn.equran.id/audio-partial/Misyari-Rasyid-Al-Afasi/001001.mp3",
        "06": "https://cdn.equran.id/audio-partial/Yasser-Al-Dosari/001001.mp3"
      }
    },
    {
      "nomorAyat": 2,
      "teksArab": "اَلْحَمْدُ لِلّٰهِ رَبِّ الْعٰلَمِيْنَۙ",
      "teksLatin": "Al-ḥamdu lillāhi rabbil-‘ālamīn(a). ",
      "teksIndonesia": "Segala puji bagi Allah, Tuhan semesta alam",
      "audio": {
        "01": "https://cdn.equran.id/audio-partial/Abdullah-Al-Juhany/001002.mp3",
        "02": "https://cdn.equran.id/audio-partial/Abdul-Muhsin-Al-Qasim/001002.mp3",
        "03": "https://cdn.equran.id/audio-partial/Abdurrahman-as-Sudais/001002.mp3",
        "04": "https://cdn.equran.id/audio-partial/Ibrahim-Al-Dossari/001002.mp3",
        "05": "https://cdn.equran.id/audio-partial/Misyari-Rasyid-Al-Afasi/001002.mp3",
        "06": "https://cdn.equran.id/audio-partial/Yasser-Al-Dosari/001002.mp3"
      }
    },
    {
      "nomorAyat": 3,
      "teksArab": "الرَّحْمٰنِ الرَّحِيْمِۙ",
      "teksLatin": "Ar-raḥmānir-raḥīm(i). ",
      "teksIndonesia": "Yang Maha Pengasih lagi Maha Penyayang,",
      "audio": {
        "01": "https://cdn.equran.id/audio-partial/Abdullah-Al-Juhany/001003.mp3",
        "02": "https://cdn.equran.id/audio-partial/Abdul-Muhsin-Al-Qasim/001003.mp3",
        "03": "https://cdn.equran.id/audio-partial/Abdurrahman-as-Sudais/001003.mp3",
        "04": "https://cdn.equran.id/audio-partial/Ibrahim-Al-Dossari/001003.mp3",
        "05": "https://cdn.equran.id/audio-partial/Misyari-Rasyid-Al-Afasi/001003.mp3",
        "06": "https://cdn.equran.id/audio-partial/Yasser-Al-Dosari/001003.mp3"
      }
    },
    {
      "nomorAyat": 4,
      "teksArab": "مٰلِكِ يَوْمِ الدِّيْنِۗ",
      "teksLatin": "Māliki yaumid-dīn(i). ",
      "teksIndonesia": "Pemilik hari Pembalasan.",
      "audio": {
        "01": "https://cdn.equran.id/audio-partial/Abdullah-Al-Juhany/001004.mp3",
        "02": "https://cdn.equran.id/audio-partial/Abdul-Muhsin-Al-Qasim/001004.mp3",
        "03": "https://cdn.equran.id/audio-partial/Abdurrahman-as-Sudais/001004.mp3",
        "04": "https://cdn.equran.id/audio-partial/Ibrahim-Al-Dossari/001004.mp3",
        "05": "https://cdn.equran.id/audio-partial/Misyari-Rasyid-Al-Afasi/001004.mp3",
        "06": "https://cdn.equran.id/audio-partial/Yasser-Al-Dosari/001004.mp3"
      }
    },
    {
      "nomorAyat": 5,
      "teksArab": "اِيَّاكَ نَعْبُدُ وَاِيَّاكَ نَسْتَعِيْنُۗ",
      "teksLatin": "Iyyāka na‘budu wa iyyāka nasta‘īn(u), ",
      "teksIndonesia": "Hanya kepada Engkaulah kami menyembah dan hanya kepada Engkaulah kami memohon pertolongan.",
      "audio": {
        "01": "https://cdn.equran.id/audio-partial/Abdullah-Al-Juhany/001005.mp3",
        "02": "https://cdn.equran.id/audio-partial/Abdul-Muhsin-Al-Qasim/001005.mp3",
        "03": "https://cdn.equran.id/audio-partial/Abdurrahman-as-Sudais/001005.mp3",
        "04": "https://cdn.equran.id/audio-partial/Ibrahim-Al-Dossari/001005.mp3",
        "05": "https://cdn.equran.id/audio-partial/Misyari-Rasyid-Al-Afasi/001005.mp3",
        "06": "https://cdn.equran.id/audio-partial/Yasser-Al-Dosari/001005.mp3"
      }
    },
    {
      "nomorAyat": 6,
      "teksArab": "اِهْدِنَا الصِّرَاطَ الْمُسْتَقِيْمَۙ",
      "teksLatin": "Ihdinaṣ-ṣirāṭal-mustaqīm(a). ",
      "teksIndonesia": "Bimbinglah kami ke jalan yang lurus,",
      "audio": {
        "01": "https://cdn.equran.id/audio-partial/Abdullah-Al-Juhany/001006.mp3",
        "02": "https://cdn.equran.id/audio-partial/Abdul-Muhsin-Al-Qasim/001006.mp3",
        "03": "https://cdn.equran.id/audio-partial/Abdurrahman-as-Sudais/001006.mp3",
        "04": "https://cdn.equran.id/audio-partial/Ibrahim-Al-Dossari/001006.mp3",
        "05": "https://cdn.equran.id/audio-partial/Misyari-Rasyid-Al-Afasi/001006.mp3",
        "06": "https://cdn.equran.id/audio-partial/Yasser-Al-Dosari/001006.mp3"
      }
    },
    {
      "nomorAyat": 7,
      "teksArab": "صِرَاطَ الَّذِيْنَ اَنْعَمْتَ عَلَيْهِمْ ەۙ غَيْرِ الْمَغْضُوْبِ عَلَيْهِمْ وَلَا الضَّاۤلِّيْنَ ࣖ",
      "teksLatin": "Ṣirāṭal-lażīna an‘amta ‘alaihim, gairil-magḍūbi ‘alaihim wa laḍ-ḍāllīn(a). ",
      "teksIndonesia": "(yaitu) jalan orang-orang yang telah Engkau beri nikmat, bukan (jalan) mereka yang dimurkai dan bukan (pula jalan) orang-orang yang sesat.",
      "audio": {
        "01": "https://cdn.equran.id/audio-partial/Abdullah-Al-Juhany/001007.mp3",
        "02": "https://cdn.equran.id/audio-partial/Abdul-Muhsin-Al-Qasim/001007.mp3",
        "03": "https://cdn.equran.id/audio-partial/Abdurrahman-as-Sudais/001007.mp3",
        "04": "https://cdn.equran.id/audio-partial/Ibrahim-Al-Dossari/001007.mp3",
        "05": "https://cdn.equran.id/audio-partial/Misyari-Rasyid-Al-Afasi/001007.mp3",
        "06": "https://cdn.equran.id/audio-partial/Yasser-Al-Dosari/001007.mp3"
      }
    }
  ],
  "audioFull": {
    "01": "https://cdn.equran.id/audio-full/Abdullah-Al-Juhany/001.mp3",
    "02": "https://cdn.equran.id/audio-full/Abdul-Muhsin-Al-Qasim/001.mp3",
    "03": "https://cdn.equran.id/audio-full/Abdurrahman-as-Sudais/001.mp3",
    "04": "https://cdn.equran.id/audio-full/Ibrahim-Al-Dossari/001.mp3",
    "05": "https://cdn.equran.id/audio-full/Misyari-Rasyid-Al-Afasi/001.mp3",
    "06": "https://cdn.equran.id/audio-full/Yasser-Al-Dosari/001.mp3"
  }
}

export const verifiedDoa = [
  {
    "id": 1,
    "grup": "Doa Sebelum dan Sesudah Tidur",
    "nama": "Doa Sebelum Tidur 1",
    "ar": "بِاسْمِكَ رَبِّيْ وَضَعْتُ جَنْبِيْ، وَبِكَ أَرْفَعُهُ، إِنْ أَمْسَكْتَ نَفْسِيْ فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِيْنَ",
    "tr": "Bismika robbii wa dho'tu janbii, wa bika arfa'uhu, in amsakta nafsii farhamhaa, wa in arsaltahaa fahfazhhaa bimaa tahfazhu bihi 'ibaadakash-sholihiin.",
    "idn": "Dengan nama Engkau, wahai Tuhanku, aku meletakkan lambungku. Dan dengan namaMu pula aku bangun daripadanya. Apabila Engkau menahan rohku (mati), maka berilah rahmat padanya. Tapi apabila Engkau melepaskannya, maka peliharalah, sebagaimana Engkau memelihara hamba-hambaMu yang shalih.",
    "tentang": "HR. Al-Bukhari 11/126, Muslim 4/2084.\n\"Apabila seseorang di antara kalian bangkit dari tempat tidurnya kemudian ingin kembali lagi, hendaknya ia mengibaskan ujung kainnya 3x, dan menyebut nama Allah, karena ia tidak tahu apa yang ditinggalkannya di atas tempat tidur setelah ia bangkit. Apabila ia ingin berbaring, maka hendaknya ia membaca: (doa di atas).\"\n\n\nSumber: Hisnul Muslim.",
    "tag": [
      "tidur",
      "malam"
    ]
  },
  {
    "id": 6,
    "grup": "Doa Sebelum dan Sesudah Tidur",
    "nama": "Doa Bangun Tidur 1",
    "ar": "اَلْحَمْدُ لِلَّهِ الَّذِيْ أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُوْرِ",
    "tr": "Alhamdulillaahil-ladzii ahyaanaa ba'da maa amaatanaa wa ilaihin-nusyuur.",
    "idn": "Segala puji bagi Allah, yang membangunkan kami setelah ditidurkanNya dan kepadaNya kami dibangitkan.",
    "tentang": "HR. Al-Bukhari dalam Fathul Baari 11/113, Muslim 4/2083.\nSumber: Hisnul Muslim.",
    "tag": [
      "tidur",
      "malam"
    ]
  },
  {
    "id": 48,
    "grup": "Doa Perjalanan",
    "nama": "Doa Naik Kendaraan",
    "ar": "بِسْمِ اللَّهِ، اَلْحَمْدُ لِلَّهِ (سُبْحَانَ الَّذِيْ سَخَّرَ لَنَا هَـٰذَا وَمَا كُنَّا لَهُ مُقْرِنِيْنَ. وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُوْنَ) اَلْحَمْدُ لِلَّهِ، اَلْحَمْدُ لِلَّهِ، اَلْحَمْدُ لِلَّهِ، اَللَّهُ أَكْبَرُ، اَللَّهُ أَكْبَرُ، اَللَّهُ أَكْبَرُ، سُبْحَانَكَ اللَّهُمَّ إِنِّيْ ظَلَمْتُ نَفْسِيْ فَاغْفِرْ لِيْ، فَإِنَّهُ لاَ يَغْفِرُ الذُّنُوْبَ إِلاَّ أَنْتَ",
    "tr": "Bismillaah, alhamdulillaah, (subhaanal-ladzii sakh-khoro lanaa haadzaa wa maa kunnaa lahu muqriniin. Wa innaa ilaa robbinaa lamunqolibuun), alhamdulillaah (3x), allaahu akbar (3x), subhaanakallaahumma innii zholamtu nafsii faghfir lii, fa-innahu laa yaghfirudz-dzunuuba illaa anta.",
    "idn": "Dengan nama Allah, segala puji bagi Allah, (Maha Suci Tuhan yang menundukkan kendaraan ini untuk kami, padahal kami sebelumnya tidak mampu menguasainya. Dan sesungguhnya kami akan kembali kepada Tuhan kami (di hari Kiamat)). Segala puji bagi Allah (3x), Allah Maha Besar (3x), Maha Suci Engkau ya Allah, sesungguhnya aku menganiaya diriku, maka ampunilah aku. Sesungguhnya tidak ada yang mengampuni dosa-dosa kecuali Engkau.",
    "tentang": "HR. Abu Dawud 3/34, At-Tirmidzi 5/501, dan lihat Shahih At-Tirmidzi 3/156. Sumber: Hisnul Muslim",
    "tag": [
      "perjalanan"
    ]
  },
  {
    "id": 51,
    "grup": "Doa Perjalanan",
    "nama": "Doa Bepergian",
    "ar": "اَللَّهُ أَكْبَرُ، اَللَّهُ أَكْبَرُ، اَللَّهُ أَكْبَرُ، (سُبْحَانَ الَّذِيْ سَخَّرَ لَنَا هَـٰذَا وَمَا كُنَّا لَهُ مُقْرِنِيْنَ. وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُوْنَ) اَللَّهُمَّ إِنَّا نَسْأَلُكَ فِيْ سَفَرِنَا هَـٰذَا الْبِرَّ وَالتَّقْوَى، وَمِنَ الْعَمَلِ مَا تَرْضَى، اَللَّهُمَّ هَوِّنْ عَلَيْنَا سَفَرَنَا هَـٰذَا وَاطْوِ عَنَّا بُعْدَهُ، اَللَّهُمَّ أَنْتَ الصَّاحِبُ فِي السَّفَرِ وَالْخَلِيْفَةُ فِي اْلأَهْلِ، اَللَّهُمَّ إِنِّيْ أَعُوْذُ بِكَ مِنْ وَعْثَاءِ السَّفَرِ وَكَآبَةِ الْمَنْظَرِ وَسُوْءِ الْمُنْقَلَبِ فِي الْمَالِ وَاْلأَهْلِ",
    "tr": "Allaahu akbar (3x), (subhaanal-ladzii sakh-khoro lanaa haadzaa wa maa kunnaa lahu muqriniin. Wa innaa ilaa robbinaa lamunqolibuun), allaahumma innaa nas-aluka fii safarinaa haadzal birro wat-taqwaa, wa minal 'amali maa tardhoo, allaahumma hawwin 'alainaa safaronaa haadzaa wathwi 'annaa bu'dah, allaahumma antash-shoohibu fis-safari wal kholiifatu fil ahli, allaahumma innii a'uudzu bika min wa'tsaa-is-safari wa ka-aabatil manzhori wa suu-il munqolabi fil maali wal ahli.",
    "idn": "Allah Maha Besar (3x). (Maha Suci Tuhan yang menundukkan kendaraan ini untuk kami, padahal kami sebelumnya tidak mampu menguasainya. Dan sesungguhnya kami akan kembali kepada Tuhan kami (di hari Kiamat)). Ya Allah, sesungguhnya kami memohon kebaikan dan taqwa dalam bepergian ini, kami mohon perbuatan yang meridhakanMu. Ya Allah, permudahlah perjalanan kami ini, dan dekatkan jaraknya bagi kami. Ya Allah, Engkaulah teman dalam bepergian dan yang mengurusi keluarga(ku). Ya Allah, sesungguhnya aku berlindung kepada-Mu dari kelelahan dalam bepergian, pemandangan yang menyedihkan dan kepulangan yang jelek dalam harta dan keluarga.",
    "tentang": "Apabila kembali dari bepergian, doa di atas dibaca, dan ditambah:\n\nآيِبُوْنَ تَائِبُوْنَ عَابِدُوْنَ لِرَبِّنَا حَامِدُوْنَ\n\nAayibuuna taa-ibuuna 'aabiduuna lirobbinaa haamiduun.\n\nKami kembali dengan bertaubat, tetap beribadah dan selalu memuji kepada Tuhan kami.\n\n\nHR. Muslim 2/998.\n\nSumber: Hisnul Muslim.",
    "tag": [
      "perjalanan"
    ]
  },
  {
    "id": 66,
    "grup": "Doa Terkait Orang Tua",
    "nama": "Doa Memohon Ampun diri sendiri dan orang tua (Doa Nabil Ibrahim)",
    "ar": "رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ",
    "tr": "Robbanagh-fir lii wa liwaalidayya wa lil mu'miniina yauma yaquumul hisaab.",
    "idn": "Ya Tuhan kami, beri ampunlah aku dan kedua ibu bapakku dan sekalian orang-orang mukmin pada hari terjadinya hisab (hari kiamat).",
    "tentang": "(QS. Ibrahim [14]: 41)",
    "tag": [
      "ampunan",
      "orang tua"
    ]
  },
  {
    "id": 67,
    "grup": "Doa Terkait Orang Tua",
    "nama": "Doa Memohon Ampun Untuk Diri Sendiri, Orang Tua Dan Kaum Mukminin (Doa Nabi Nuh)",
    "ar": "رَّبِّ اغْفِرْ لِي وَلِوَالِدَيَّ وَلِمَن دَخَلَ بَيْتِيَ مُؤْمِنًا وَلِلْمُؤْمِنِينَ وَالْمُؤْمِنَاتِ وَلَا تَزِدِ الظَّالِمِينَ إِلَّا تَبَارًا",
    "tr": "Robbigh-fir lii wa liwaalidayya wa liman dakhola baitiya mu'minan wa lil mu'miniina wal mu'minaati wa laa tazidizh-zhoolimiina illaa tabaaroo.",
    "idn": "Ya Tuhanku! Ampunilah aku, ibu bapakku, orang yang masuk ke rumahku dengan beriman dan semua orang yang beriman laki-laki dan perempuan. Dan janganlah Engkau tambahkan bagi orang-orang yang zalim itu selain kebinasaan.",
    "tentang": "(QS. Nuh [71]: 28).",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 68,
    "grup": "Doa Terkait Orang Tua",
    "nama": "Doa Memohon Kasih Sayang Untuk Orang Tua",
    "ar": "رَّبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا",
    "tr": "Robbir-hamhumaa kamaa robbayaanii shoghiiroo.",
    "idn": "Wahai Tuhanku, kasihilah mereka keduanya, sebagaimana mereka berdua telah mendidik aku waktu kecil.",
    "tentang": "(QS. Al-Isra' [17]: 24).",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 95,
    "grup": "Doa Memohon Ilmu",
    "nama": "Doa Memohon Ilmu 1",
    "ar": "رَبِّ زِدْنِي عِلْمًا",
    "tr": "Robbi zidnii 'ilman.",
    "idn": "Wahai Rabb-ku, tambahkanlah ilmu kepadaku. (QS. Thaha [20]: 114).",
    "tentang": "Allah Ta'ala memerintahkan Nabi-Nya Shallallahu 'alaihi wa sallam agar meminta tambahan ilmu.\nAl-Hafidz Ibnu Hajar rahimahullah berkata, \"Ayat ini adalah dalil yang tegas tentang keutamaan ilmu. Sebab tidaklah Allah Ta'ala pernah memerintahkan Nabi-Nya Shallallahu 'alaihi wa sallam untuk meminta tambahan terhadap sesuatu, selain ilmu…\" (Fathul Baari, 1/187).",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 96,
    "grup": "Doa Memohon Ilmu",
    "nama": "Doa Memohon Ilmu 2",
    "ar": "اَللَّهُمَّ انْفَعْنِيْ بِمَا عَلَّمْتَنِيْ، وَعَلِّمْنِيْ مَا يَنْفَعُنِيْ، وَزِدْنِيْ عِلْماً",
    "tr": "Allaahumman-fa'nii bimaa 'allamtanii, wa 'allimnii maa yanfa'unii, wa zidnii 'ilman.",
    "idn": "Ya Allah, berilah aku manfaat dengan apa yang telah Engkau ajarkan kepadaku, ajarilah aku apa yang bermanfaat bagiku, dan tambahkanlah ilmu kepadaku.",
    "tentang": "HR. Ibnu Majah no. 251 dan 3833. Shahih. Tahqiq al-Albani.\n\nSumber: http://www.salamdakwah.com/baca-artikel/memohon-ilmu-yang-bermanfaat-1.html",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 172,
    "grup": "Doa Memohon Kebaikan Dan Berlindung Dari Keburukan",
    "nama": "Doa Sapu Jagad",
    "ar": "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً، وَفِي الْآخِرَةِ حَسَنَةً، وَقِنَا عَذَابَ النَّارِ",
    "tr": "Robbanaa aatinaa fid-dunyaa hasanah, wa fil aakhiroti hasanah, wa qinaa 'adzaaban-naar.",
    "idn": "Ya Tuhan kami, berilah kami kebaikan di dunia, dan kebaikan di akhirat, dan peliharalah kami dari siksa neraka. (Al-Baqarah [2]: 201).",
    "tentang": "Doa di atas sama dengan doa dalam hadits berikut:\nDari Anas radhiyallahu ‘anhu, ia berkata bahwa doa yang paling sering dibaca oleh Nabi shallallahu ‘alaihi wa sallam adalah, “Allaahumma aatinaa fid-dunyaa hasanah, wa fil aakhiroti hasanah, wa qinaa 'adzaaban-naar. (Artinya: Ya Allah, karuniakan kepada kami kebaikan di dunia, dan kebaikan di akhirat, dan selamatkanlah kami dari siksa neraka).” (Muttafaqun ‘alaih) [HR. Bukhari, 8:187-188; Muslim, no. 2690].\n\nPenjelasan Hadits:\nImam Muslim menambahkan dalam riwayatnya, “Jika Anas radhiyallahu ‘anhu hendak berdoa, ia pasti berdoa dengan doa tersebut. Jika ia hendak berdoa dengan doa yang lain, ia pun menyisipkan doa tersebut di dalamnya.” (HR. Muslim, no. 2690).\n\nIbnu Hajar rahimahullah menyebutkan, “Tidaklah seorang nabi maupun orang saleh berdoa melainkan mereka menggunakan doa ini.” (Fath Al-Bari, 2:322).\n\nIbnu Katsir rahimahullah menyatakan, “Doa sapu jagad ini berisi permintaan kebaikan di dunia seluruhnya dan dihindarkan dari seluruh kejelekan. Yang dimaksud kebaikan dunia adalah nikmat kesehatan, rumah yang lapang, istri yang penuh dengan kebaikan, rezeki yang luas, ilmu yang bermanfaat, amal saleh, kendaraan yang menyenangkan, pujian yang baik, serta kebaikan-kebaikan lainnya dengan berbagai ungkapan dari pakar tafsir. Apa yang disebutkan oleh para ulama pakar tafsir semuanya tidaklah saling bertentangan. Karena seluruh kebaikan dunia tercakup dalam doa tersebut.\n\nAdapun kebaikan di akhirat yang diminta dalam doa ini tentu saja lebih tinggi dari kebaikan di dunia yaitu dimasukkannya ke dalam surga, dibebaskan dari rasa khawatir (takut), diberi kemudahan dalam hisab (perhitungan amalan) di akhirat, serta berbagai kebaikan akhirat lainnya.\n\nAdapun permintaan diselamatkan dari siksa neraka mengandung permintaan agar kita dibebaskan dari berbagai sebab yang menjerumuskan ke dalam neraka, yaitu dengan dijauhkan dari berbagai perbuatan yang haram dan dosa, dan diberi petunjuk untuk meninggalkan hal-hal syubhat (yang masih samar/abu-abu) dan hal-hal yang haram.” (Tafsir Al-Qur’an Al-‘Azhim, 2:122).\n\nImam Nawawi rahimahullah berkata mengenai pengertian doa tersebut, “Pendapat yang lebih tepat mengenai tafsiran ‘kebaikan di dunia’ adalah ibadah dan ‘afiyah (kesehatan). Adapun ‘kebaikan di akhirat’ adalah surga dan ampunan Allah. Ada juga ulama yang mengatakan bahwa kebaikan di situ bersifat umum untuk seluruh kebaikan di dunia dan akhirat.” (Syarh Shahih Muslim, 17:13).\n\nFaedah Hadits:\n\nDianjurkan memperbanyak doa ini karena doanya yang singkat dengan lafazh yang sedikit, namun sudah berisi permintaan kebaikan dunia dan akhirat.\nDoa dari Rasulullah shallallahu ‘alaihi wa sallam kebanyakannya memakai doa ini dan ini diambil dari ayat, doa ini kandungannya padat mencakup doa seluruhnya, yaitu di dalamnya terdapat permintaan nikmat dunia, nikmat akhirat, dan diselamatkan dari siksa neraka.\nPara sahabat radhiyallahu ‘anhum semangat menjaga sunnah Nabi shallallahu ‘alaihi wa sallam dan menerapkannya.\n\nSumber: https://rumaysho.com/19550-doa-sapu-jagat-paling-sering-dibaca-nabi.html",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 201,
    "grup": "Istighfar Dan Taubat",
    "nama": "Doa Istighfar/Taubat 1",
    "ar": "أَسْتَغْفِرُ اللَّهَ الْعَظِيْمَ الَّذِيْ لاَ إِلَـٰهَ إِلاَّ هُوَ الْحَيُّ الْقَيُّوْمُ وَأَتُوْبُ إِلَيْهِ",
    "tr": "Astaghfirullaahal 'azhiimal-ladzii laa ilaaha illaa huwal hayyul qoyyuum, wa atuubu ilaih.",
    "idn": "Aku minta ampun kepada Allah Yang Maha Agung, tidak ada sesembahan yang berhak disembah kecuali Dia, Yang Hidup dan terus-menerus mengurus makhlukNya, dan aku bertaubat kepada-Nya.",
    "tentang": "HR. Abu Dawud 2/85, At-Tirmidzi 5/569, Al-Hakim, dan menurut pendapatnya hadits di atas adalah shahih. Imam Adz-Dzahabi menyetujuinya 1/511, Al-Albani menyatakan hadits tersebut adalah shahih. Lihat pula Shahih At-Tirmidzi 3/182, Jami'ul Ushul li ahaditsir Rasul 4/389-390 dengan tahqiq Al-Arnauth.\nRasul Shallallahu'alaihi wasallam bersabda: \"Barangsiapa yang membaca: (doa di atas) maka Allah mengampuninya, sekalipun dia pernah lari dari perang.\"\n\n\nSumber: Hisnul Muslim.",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 202,
    "grup": "Istighfar Dan Taubat",
    "nama": "Doa Istighfar/Taubat 2",
    "ar": "اَللَّهُمَّ إِنِّيْ ظَلَمْتُ نَفْسِيْ ظُلْمًا كَثِيْرًا، وَلاَ يَغْفِرُ الذُّنُوْبَ إِلاَّ أَنْتَ، فَاغْفِرْ لِيْ مَغْفِرَةً مِنْ عِنْدِكَ، وَارْحَمْنِيْ، إِنَّكَ أَنْتَ الْغَفُوْرُ الرَّحِيْمُ",
    "tr": "Allaahumma innii zholamtu nafsii zhulman katsiiron, wa laa yaghfirudz-dzunuuba illaa anta, faghfir lii maghfirotan min 'indika, warhamnii, innaka antal ghofuurur-rohiim.",
    "idn": "Ya Allah, sungguh aku telah menzalimi diriku dengan kezaliman yang banyak, dan tidak ada yang dapat mengampuni dosa-dosa kecuali Engkau. Maka ampunilah aku dengan suatu pengampunan dari sisi-Mu, dan rahmatilah aku. Sesungguhnya Engkau Maha Pengampun lagi Maha Penyayang.",
    "tentang": "HR. Bukhari no. 834 dan Muslim no. 2705.\n\nSumber: BBG Al-Ilmu (BlackBerry Group)",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 203,
    "grup": "Istighfar Dan Taubat",
    "nama": "Doa Istighfar/Taubat 3",
    "ar": "رَبِّ اغْفِرْ لِيْ وَتُبْ عَلَىَّ، إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيْمُ",
    "tr": "Robbighfir lii wa tub 'alayya, innaka antat-tawwaabur-rohiim.",
    "idn": "Ya Rabbku, ampunilah dosa-dosaku dan terimalah taubat dariku. Sesungguhnya Engkau Maha Penerima taubat lagi Maha Penyayang.",
    "tentang": "HR. Ahmad, at-Tirmidzi, Abu Dawud, an-Nasa'i dalam al-Kubra, al-Bukhari dalam al-Adabul Mufrad, Ibnu Hibban, ath-Thabrani dalam al-Kabiir. Dishahihhkan oleh Syaikh al-Albani dalam Shahih Sunan Abu Dawud no. 1342.\n\nSumber: https://www.facebook.com/permalink.php?story_fbid=340569015961100&id=113035155412349",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 204,
    "grup": "Lafal Dzikir Dan Keutamaannya",
    "nama": "Lafal Dzikir 1",
    "ar": "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
    "tr": "Subhaanallaahi wa bihamdih.",
    "idn": "Maha Suci Allah, aku memujiNya.",
    "tentang": "HR. Al-Bukhari 7/168, Muslim 4/2071.\nNabi Shallallahu'alaihi wasallam bersabda: \"Siapa yang membaca: (dzikir di atas) 100x dalam sehari, maka akan dihapuskan dosa-dosanya, meskipun sebanyak buih di lautan.\"\n\n\nSumber: Hisnul Muslim.",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 205,
    "grup": "Lafal Dzikir Dan Keutamaannya",
    "nama": "Lafal Dzikir 2 (Tasbih Malaikat)",
    "ar": "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
    "tr": "Subhaanallaahi wa bihamdih.",
    "idn": "Maha Suci Allah, aku memujiNya.",
    "tentang": "HR. Muslim no.2731.\nDari Abu Dzar, Nabi shallallahu 'alaihi wa sallam ditanya: Kalimat apakah yang paling mulia? Beliau menjawab: \"Kalimat yang Allah pilihkan untuk malaikat dan untuk para hambanya: (dzikir di atas).\"\n\nTentang tasbih para malaikat, Allah nyatakan dalam firman-Nya:\nIngatlah ketika Tuhanmu berfirman kepada para Malaikat: \"Sesungguhnya Aku hendak menjadikan seorang khalifah di muka bumi.\" Mereka berkata: \"Mengapa Engkau hendak menjadikan (khalifah) di bumi itu orang yang akan membuat kerusakan padanya dan menumpahkan darah, padahal kami senantiasa bertasbih dengan memuji Engkau dan mensucikan Engkau?\" Tuhan berfirman: \"Sesungguhnya Aku mengetahui apa yang tidak kamu ketahui.\" (Al-Baqarah [2]: 30).\n\nKalimat (dzikir di atas) itulah cara bertasbih malaikat",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 206,
    "grup": "Lafal Dzikir Dan Keutamaannya",
    "nama": "Lafal Dzikir 3 (Dua Kalimat Yang Ringan Di Lisan, Berat Di Timbangan)",
    "ar": "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيْمِ",
    "tr": "Subhaanallaahi wa bihamdih, subhaanallaahil 'azhiim.",
    "idn": "Maha Suci Allah, aku memujiNya, Maha Suci Allah Yang Maha Agung.",
    "tentang": "HR. Al-Bukhari 7/168 dan Muslim 4/2072.\nRasulullah Shallallahu'alaihi wasallam bersabda: \"Dua kalimat yang ringan di lidah, pahalanya berat di timbangan (hari Kiamat) dan disenangi oleh Tuhan Yang Maha Pengasih, adalah: (dzikir di atas).\"\n\n\nSumber: Hisnul Muslim.",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 207,
    "grup": "Lafal Dzikir Dan Keutamaannya",
    "nama": "Lafal Dzikir 4 (Pohon Kurma Di Surga)",
    "ar": "سُبْحَانَ اللَّهِ الْعَظِيْمِ وَبِحَمْدِهِ",
    "tr": "Subhaanallaahil 'azhiimi wa bihamdih.",
    "idn": "Maha Suci Allah Yang Maha Agung, aku memujiNya.",
    "tentang": "HR. At-Tirmidzi 5/511 dan Al-Hakim 1/501. Menurut pendapatnya, hadits tersebut shahih. Imam Adz-Dzahabi menyetujuinya. Lihat pula Shahihul Jami' 5/531 dan Shahih At-Tirmidzi 3/160.\n\"Barangsiapa yang membaca: (dzikir di atas), maka ditanam untuknya sebatang pohon kurma di Surga.\"\n\n\nSumber: Hisnul Muslim.",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 208,
    "grup": "Lafal Dzikir Dan Keutamaannya",
    "nama": "Lafal Dzikir 5",
    "ar": "سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلاَ إِلَـٰهَ إِلاَّ اللَّهُ، وَاللَّهُ أَكْبَرُ",
    "tr": "Subhaanallaah, wal hamdulillaah, wa laa ilaaha illallaah, wallaahu akbar.",
    "idn": "Maha Suci Allah, Segala Puji bagi Allah, tidak ada sesembahan yang berhak disembah kecuali Allah, Allah Maha Besar.",
    "tentang": "HR. Muslim 4/2072.\nRasulullah Shallallahu'alaihi wasallam bersabda: \"Sungguh, apabila aku membaca: (dzikir di atas) adalah lebih senang bagiku dari apa yang disinari oleh matahari terbit.\"\n\n\nSumber: Hisnul Muslim.",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 209,
    "grup": "Lafal Dzikir Dan Keutamaannya",
    "nama": "Lafal Dzikir 6 (Doa Dan Dzikir Terbaik)",
    "ar": "Sesungguhnya doa yang terbaik adalah membaca:\nاَلْحَمْدُ لِلَّهِ",
    "tr": "Alhamdulillaah.",
    "idn": "Segala Puji bagi Allah.",
    "tentang": "Sedang dzikir yang terbaik adalah:\n\nلاَ إِلَـٰهَ إِلاَّ اللَّهُ\n\nLaa ilaaha illallaah.\n\nTidak ada sesembahan yang berhak disembah kecuali Allah.\n\n\nHR. At-Tirmidzi 5/462, Ibnu Majah 2/1249, Al-Hakim 1/503. Menurut Al-Hakim, hadits tersebut adalah shahih. Imam Adz-Dzahabi menyetujuinya, Lihat pula Shahihul Jami' 1/362.\n\nSumber: Hisnul Muslim.",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 210,
    "grup": "Lafal Dzikir Dan Keutamaannya",
    "nama": "Lafal Dzikir 7 (Pahalanya Lebih Besar Daripada Dzikir Sehari Semalam)",
    "ar": "اَلْحَمْدُ لِلَّهِ عَدَدَ مَا خَلَقَ\nوَالْحَمْدُ لِلَّهِ مِلْءَ مَا خَلَقَ\nوَالْحَمْدُ لِلَّهِ عَدَدَ مَا فِي السَّمَاوَاتِ وَمَا فِي الأَرْضِ\nوَالْحَمْدُ لِلَّهِ عَدَدَ مَا أَحْصَى كِتَابُهُ\nوَالْحَمْدُ لِلَّهِ مِلْءَ مَا أَحْصَى كِتَابُهُ\nوَالْحَمْدُ لِلَّهِ عَدَدَ كُلِّ شَيْءٍ\nوَالْحَمْدُ لِلَّهِ مِلْءَ كُلِّ شَيْءٍ\n\nسُبْحَانَ اللَّهِ عَدَدَ مَا خَلَقَ\nوَسُبْحَانَ اللَّهِ مِلْءَ مَا خَلَقَ\nوَسُبْحَانَ اللَّهِ عَدَدَ مَا فِي السَّمَاوَاتِ وَمَا فِي الأَرْضِ\nوَسُبْحَانَ اللَّهِ عَدَدَ مَا أَحْصَى كِتَابُهُ\nوَسُبْحَانَ اللَّهِ مِلْءَ مَا أَحْصَى كِتَابُهُ\nوَسُبْحَانَ اللَّهِ عَدَدَ كُلِّ شَيْءٍ\nوَسُبْحَانَ اللَّهِ مِلْءَ كُلِّ شَيْءٍ",
    "tr": "Alhamdulillaahi 'adada maa kholaq,\nwalhamdulillaahi mil-a maa kholaq,\nwalhamdulillaahi 'adada maa fis-samaawaati wa maa fil ardh,\nwalhamdulillaahi 'adada maa ahshoo kitaabuh,\nwalhamdulillaahi mil-a maa ahshoo kitaabuh,\nwalhamdulillaahi 'adada kulli syai-in,\nwalhamdulillaahi mil-a kulli syai-in,\n\nSubhaanallaahi 'adada maa kholaq,\nwa subhaanallaahi mil-a maa kholaq,\nwa subhaanallaahi 'adada maa fis-samaawaati wa maa fil ardh,\nwa subhaanallaahi 'adada maa ahshoo kitaabuh,\nwa subhaanallaahi mil-a maa ahshoo kitaabuh,\nwa subhaanallaahi 'adada kulli syai-in,\nwa subhaanallaahi mil-a kulli syai-in.",
    "idn": "Segala puji bagi Allah sebanyak ciptaan-Nya,\nSegala puji bagi Allah meliputi seluruh ciptaan-Nya,\nSegala puji bagi Allah sebanyak segala yang ada di langit dan di bumi,\nSegala puji bagi Allah sebanyak segala yang terhitung dalam kitab-Nya,\nSegala puji bagi Allah meliputi semua yang dapat dihitung dalam kitab-Nya,\nSegala puji bagi Allah sebanyak segala sesuatu,\nSegala puji bagi Allah meliputi segala sesuatu,\n\nMaha suci Allah sebanyak ciptaan-Nya,\nMaha suci Allah meliputi seluruh ciptaan-Nya,\nMaha suci Allah sebanyak segala yang ada di langit dan di bumi,\nMaha suci Allah sebanyak segala yang terhitung dalam kitab-Nya,\nMaha suci Allah meliputi semua yang dapat dihitung dalam kitab-Nya,\nMaha suci Allah sebanyak segala sesuatu,\nMaha suci Allah meliputi segala sesuatu.",
    "tentang": "HR. Imam Nasa’i 6/50 hadits no 9994, Ibnu Khuzaimah 1/371 hadits nomor 754 dan Imam Thabrani 8/238 hadits no. 7930. Dishahihkan oleh Syaikh Al Albani dalam kitab Shahihul Jami’ no 2615.\nSuatu saat Nabi -shallallahu alaihi wasallam- melihat Abu Umamah -radhiallahu anhu- menggerakkan bibirnya, maka beliau bertanya, “Apa yang sedang kau baca wahai Abu Umamah?” Dia menjawab, “Aku sedang berdzikir kepada Allah.” Beliau mengatakan, “Maukah aku tunjukkan kepadamu dzikir yang pahalanya lebih banyak dari dzikirmu selama sehari semalam?” Kemudian beliau mengajarinya: (dzikir di atas), dan beliau berpesan, “Ajarkanlah dzikir ini kepada orang-orang setelahmu.”\n\n\nSumber: http://www.madinatulquran.or.id/dzikir-yang-sangat-dahsyat-pahalanya dan http://jilbab.or.id/archives/2153-berdzikir-sekali-mendapat-pahala-berdzikir-sepanjang-malam-dan-siang-hari",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 225,
    "grup": "Beberapa Doa Terkait Shalat",
    "nama": "Bacaan Setelah Salam Shalat Witir",
    "ar": "(سُبْحَانَ الْمَلِكِ الْقُدُّوْسِ (3×) (رَبِّ الْمَلاَئِكَةِ وَالرُّوْحِ",
    "tr": "Subhaanal malikil qudduus (3x), (robbil malaa-ikati war-ruuh).",
    "idn": "Maha suci Allah, Raja Yang Maha suci (3x, dan yang ketiga, beliau membacanya dengan suara keras dan panjang, dan menambahkan) Tuhannya para malaikat dan Jibril.",
    "tentang": "HR. An-Nasai 3/244, Ad-Daruquthni dan beberapa imam hadis yang lain. Sedang kalimat antara dua tanda kurung adalah tambahan menurut riwayatnya 2/31. Sanadnya shahih, lihat Zadul Ma'ad yang ditahqiq oleh Syu'aib Al-Arnauth dan Abdul Qadir Al-Arnauth 1/337.\nKeterangan:\nTidak ada doa setelah tarawih maupun di sela tarawih. Yang ada adalah doa setelah witir. Berikut beberapa doa setelah witir yang diajarkan Rasulullah shallallahu 'alaihi wa sallam.\n\nSubhaanal malikil qudduus. (Maha suci Allah, Raja Yang Maha suci).\n\nHadis Selengkapnya:\nDari Ubay bin Ka'ab radhiyallahu 'anhu, beliau mengatakan: Rasulullah shallallahu 'alaihi wa sallam setelah salam shalat witir, beliau membaca: Subhaanal malikil qudduus. (HR. Abu Daud 1430, dishahihkan Al-Albani).\n\nDalam riwayat Nasa'i dari Abdurrahman bin Abza radhiyallahu 'anhu, terdapat tambahan: Rasulullah shallallahu 'alaihi wa sallam melakukan witir dengan membaca surat Al-A'la (rakaat pertama), surat Al-Kafirun (rakaat kedua), dan surat Al-Ikhlas (rakaat ketiga). Setelah salam, beliau membaca: Subhaanal malikil qudduus 3x. Beliau keraskan yang ketiga. (HR. Nasa'i 1732 dan dishahihkan Al-Albani).\n\nDalam riwayat yang lain, terdapat tambahan: \"Beliau baca panjang yang ketiga.\" (HR. Nasa'i 1734 dan dishahihkan Al-Albani).\n\nTambahan \"Rabbil Malaaikati war Ruuh\":\nDisebutkan dalam riwayat Thabrani adanya tambahan:\n\nRabbil Malaaikati war Ruuh. (Tuhannya para malaikat dan Jibril).\n\nDari Ubay bin Ka'ab radhiyallahu 'anhu, beliau mengatakan: Di bagian akhir beliau membaca: Rabbil Malaaikati war Ruuh. (HR. Ad-Daruquthni 1660. Dalam fatwa islam (no. 14093) dinyatakan: sanadnya shahih, dan disebutkan Ibnul Qoyim dalam Zadul Ma'ad 1/323).\n\nDari beberapa riwayat di atas, dapat kita simpulkan terkait bacaan doa ini:\n\nDoa ini dibaca tepat setelah salam shalat witir.\nDoa ini dibaca 3x.\nPada bacaan kali ke-3, dikeraskan dan dipanjangkan \"Subhaaanal malikil qudduuuuu … ss\".\nDisambung dengan membaca \"Rabbil malaaikati war ruuh…\".\nKalimat: \"Subbuuhun qudduusun rabbul malaaikati war ruuh\":\nKalimat termasuk salah satu doa yang diajarkan Nabi shallallahu 'alaihi wa sallam ketika rukuk atau sujud. A'isyah radhiyallahu 'anha mengatakan: Bahwa Rasulullah shallallahu 'alaihi wa sallam membaca doa ketika rukuk dan sujud beliau: \"Subbuuhun qudduusun… dst\". (HR. Muslim 487). Mengingat lafal \"Subbuuhun qudduusun… dst\" adalah doa sujud atau rukuk ketika shalat, sehingga tambahan ini tidak ada hubungannya dengan shalat witir. Karena tidak perlu dibaca seusai witir.\n\nAllahu a'lam.\n\n\nSumber: Hisnul Muslim dan http://www.facebook.com/doa.dzikir.shahih.harian/posts/271175212982544",
    "tag": [
      "umum"
    ]
  },
  {
    "id": 227,
    "grup": "Beberapa Doa Terkait Shalat",
    "nama": "Doa Setelah Shalat Dhuha",
    "ar": "اَللَّهُمَّ اغْفِرْ لِي وَتُبْ عَلَيَّ، إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ",
    "tr": "Allaahummagh-fir lii wa tub 'alayya, innaka antat-tawwaabur-rohiim (100x).",
    "idn": "Ya Allah, ampunilah dosaku dan terimalah taubatku, sesungguhnya Engkau Maha Penerima Taubat lagi Maha Penyayang (100x).",
    "tentang": "HR. Bukhari dalam al-Adab al-Mufrod 217 no. 619. Dishahihkan oleh al-Albani.\nDari Aisyah radhiyallahu anha, ia berkata, “Rasulullah shallallahu alaihi wa sallam melaksanakan shalat dhuha kemudian Beliau berucap: (doa di atas). Beliau mengulangnya hingga 100 kali.”\n\n\nSumber: http://www.salamdakwah.com/baca-pertanyaan/dzikir-sholat-dhuha.html",
    "tag": [
      "umum"
    ]
  }
]
