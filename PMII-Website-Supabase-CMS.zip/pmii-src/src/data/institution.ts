export const institution = {
  name: 'PMII Institut Miftahul Huda',
  description: 'Ruang keislaman, keilmuan, kaderisasi, dan informasi Pergerakan Mahasiswa Islam Indonesia di Institut Miftahul Huda.',
  approvedHistory: null as string | null,
  approvedVision: null as string | null,
  approvedMission: [] as string[],
  approvedStructure: [] as { role: string; publicName: string }[],
  publicContact: null as { email?: string; address?: string; mapUrl?: string } | null,
  publicSocials: [] as { label: string; url: string }[],
}
