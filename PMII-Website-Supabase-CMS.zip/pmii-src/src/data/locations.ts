export interface PublicLocation { name: string; latitude: number; longitude: number; timezone: string }

export const locations: PublicLocation[] = [
  { name: 'Jakarta', latitude: -6.2088, longitude: 106.8456, timezone: 'Asia/Jakarta' },
  { name: 'Bandung', latitude: -6.9175, longitude: 107.6191, timezone: 'Asia/Jakarta' },
  { name: 'Semarang', latitude: -6.9667, longitude: 110.4167, timezone: 'Asia/Jakarta' },
  { name: 'Yogyakarta', latitude: -7.7956, longitude: 110.3695, timezone: 'Asia/Jakarta' },
  { name: 'Surabaya', latitude: -7.2575, longitude: 112.7521, timezone: 'Asia/Jakarta' },
  { name: 'Malang', latitude: -7.9666, longitude: 112.6326, timezone: 'Asia/Jakarta' },
  { name: 'Medan', latitude: 3.5952, longitude: 98.6722, timezone: 'Asia/Jakarta' },
  { name: 'Makassar', latitude: -5.1477, longitude: 119.4327, timezone: 'Asia/Makassar' },
  { name: 'Jayapura', latitude: -2.5916, longitude: 140.669, timezone: 'Asia/Jayapura' },
]
