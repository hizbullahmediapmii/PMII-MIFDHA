export const surahIndex = [
  {
    "nomor": 1,
    "nama": "الفاتحة",
    "namaLatin": "Al-Fatihah",
    "jumlahAyat": 7,
    "tempatTurun": "Mekah",
    "arti": "Pembukaan"
  },
  {
    "nomor": 2,
    "nama": "البقرة",
    "namaLatin": "Al-Baqarah",
    "jumlahAyat": 286,
    "tempatTurun": "Madinah",
    "arti": "Sapi"
  },
  {
    "nomor": 3,
    "nama": "اٰل عمران",
    "namaLatin": "Ali 'Imran",
    "jumlahAyat": 200,
    "tempatTurun": "Madinah",
    "arti": "Keluarga Imran"
  },
  {
    "nomor": 4,
    "nama": "النساۤء",
    "namaLatin": "An-Nisa'",
    "jumlahAyat": 176,
    "tempatTurun": "Madinah",
    "arti": "Wanita"
  },
  {
    "nomor": 5,
    "nama": "الماۤئدة",
    "namaLatin": "Al-Ma'idah",
    "jumlahAyat": 120,
    "tempatTurun": "Madinah",
    "arti": "Hidangan"
  },
  {
    "nomor": 6,
    "nama": "الانعام",
    "namaLatin": "Al-An'am",
    "jumlahAyat": 165,
    "tempatTurun": "Mekah",
    "arti": "Binatang Ternak"
  },
  {
    "nomor": 7,
    "nama": "الاعراف",
    "namaLatin": "Al-A'raf",
    "jumlahAyat": 206,
    "tempatTurun": "Mekah",
    "arti": "Tempat Tertinggi"
  },
  {
    "nomor": 8,
    "nama": "الانفال",
    "namaLatin": "Al-Anfal",
    "jumlahAyat": 75,
    "tempatTurun": "Madinah",
    "arti": "Rampasan Perang"
  },
  {
    "nomor": 9,
    "nama": "التوبة",
    "namaLatin": "At-Taubah",
    "jumlahAyat": 129,
    "tempatTurun": "Madinah",
    "arti": "Pengampunan"
  },
  {
    "nomor": 10,
    "nama": "يونس",
    "namaLatin": "Yunus",
    "jumlahAyat": 109,
    "tempatTurun": "Mekah",
    "arti": "Yunus"
  },
  {
    "nomor": 11,
    "nama": "هود",
    "namaLatin": "Hud",
    "jumlahAyat": 123,
    "tempatTurun": "Mekah",
    "arti": "Hud"
  },
  {
    "nomor": 12,
    "nama": "يوسف",
    "namaLatin": "Yusuf",
    "jumlahAyat": 111,
    "tempatTurun": "Mekah",
    "arti": "Yusuf"
  },
  {
    "nomor": 13,
    "nama": "الرّعد",
    "namaLatin": "Ar-Ra'd",
    "jumlahAyat": 43,
    "tempatTurun": "Madinah",
    "arti": "Guruh"
  },
  {
    "nomor": 14,
    "nama": "ابرٰهيم",
    "namaLatin": "Ibrahim",
    "jumlahAyat": 52,
    "tempatTurun": "Mekah",
    "arti": "Ibrahim"
  },
  {
    "nomor": 15,
    "nama": "الحجر",
    "namaLatin": "Al-Hijr",
    "jumlahAyat": 99,
    "tempatTurun": "Mekah",
    "arti": "Hijr"
  },
  {
    "nomor": 16,
    "nama": "النحل",
    "namaLatin": "An-Nahl",
    "jumlahAyat": 128,
    "tempatTurun": "Mekah",
    "arti": "Lebah"
  },
  {
    "nomor": 17,
    "nama": "الاسراۤء",
    "namaLatin": "Al-Isra'",
    "jumlahAyat": 111,
    "tempatTurun": "Mekah",
    "arti": "Memperjalankan Malam Hari"
  },
  {
    "nomor": 18,
    "nama": "الكهف",
    "namaLatin": "Al-Kahf",
    "jumlahAyat": 110,
    "tempatTurun": "Mekah",
    "arti": "Goa"
  },
  {
    "nomor": 19,
    "nama": "مريم",
    "namaLatin": "Maryam",
    "jumlahAyat": 98,
    "tempatTurun": "Mekah",
    "arti": "Maryam"
  },
  {
    "nomor": 20,
    "nama": "طٰهٰ",
    "namaLatin": "Taha",
    "jumlahAyat": 135,
    "tempatTurun": "Mekah",
    "arti": "Taha"
  },
  {
    "nomor": 21,
    "nama": "الانبياۤء",
    "namaLatin": "Al-Anbiya'",
    "jumlahAyat": 112,
    "tempatTurun": "Mekah",
    "arti": "Para Nabi"
  },
  {
    "nomor": 22,
    "nama": "الحج",
    "namaLatin": "Al-Hajj",
    "jumlahAyat": 78,
    "tempatTurun": "Madinah",
    "arti": "Haji"
  },
  {
    "nomor": 23,
    "nama": "المؤمنون",
    "namaLatin": "Al-Mu'minun",
    "jumlahAyat": 118,
    "tempatTurun": "Mekah",
    "arti": "Orang-Orang Mukmin"
  },
  {
    "nomor": 24,
    "nama": "النّور",
    "namaLatin": "An-Nur",
    "jumlahAyat": 64,
    "tempatTurun": "Madinah",
    "arti": "Cahaya"
  },
  {
    "nomor": 25,
    "nama": "الفرقان",
    "namaLatin": "Al-Furqan",
    "jumlahAyat": 77,
    "tempatTurun": "Mekah",
    "arti": "Pembeda"
  },
  {
    "nomor": 26,
    "nama": "الشعراۤء",
    "namaLatin": "Asy-Syu'ara'",
    "jumlahAyat": 227,
    "tempatTurun": "Mekah",
    "arti": "Para Penyair"
  },
  {
    "nomor": 27,
    "nama": "النمل",
    "namaLatin": "An-Naml",
    "jumlahAyat": 93,
    "tempatTurun": "Mekah",
    "arti": "Semut-semut"
  },
  {
    "nomor": 28,
    "nama": "القصص",
    "namaLatin": "Al-Qasas",
    "jumlahAyat": 88,
    "tempatTurun": "Mekah",
    "arti": "Kisah-Kisah"
  },
  {
    "nomor": 29,
    "nama": "العنكبوت",
    "namaLatin": "Al-'Ankabut",
    "jumlahAyat": 69,
    "tempatTurun": "Mekah",
    "arti": "Laba-Laba"
  },
  {
    "nomor": 30,
    "nama": "الرّوم",
    "namaLatin": "Ar-Rum",
    "jumlahAyat": 60,
    "tempatTurun": "Mekah",
    "arti": "Romawi"
  },
  {
    "nomor": 31,
    "nama": "لقمٰن",
    "namaLatin": "Luqman",
    "jumlahAyat": 34,
    "tempatTurun": "Mekah",
    "arti": "Luqman"
  },
  {
    "nomor": 32,
    "nama": "السّجدة",
    "namaLatin": "As-Sajdah",
    "jumlahAyat": 30,
    "tempatTurun": "Mekah",
    "arti": "Sajdah"
  },
  {
    "nomor": 33,
    "nama": "الاحزاب",
    "namaLatin": "Al-Ahzab",
    "jumlahAyat": 73,
    "tempatTurun": "Madinah",
    "arti": "Golongan Yang Bersekutu"
  },
  {
    "nomor": 34,
    "nama": "سبأ",
    "namaLatin": "Saba'",
    "jumlahAyat": 54,
    "tempatTurun": "Mekah",
    "arti": "Saba'"
  },
  {
    "nomor": 35,
    "nama": "فاطر",
    "namaLatin": "Fatir",
    "jumlahAyat": 45,
    "tempatTurun": "Mekah",
    "arti": "Maha Pencipta"
  },
  {
    "nomor": 36,
    "nama": "يٰسۤ",
    "namaLatin": "Yasin",
    "jumlahAyat": 83,
    "tempatTurun": "Mekah",
    "arti": "Yasin"
  },
  {
    "nomor": 37,
    "nama": "الصّٰۤفّٰت",
    "namaLatin": "As-Saffat",
    "jumlahAyat": 182,
    "tempatTurun": "Mekah",
    "arti": "Barisan-Barisan"
  },
  {
    "nomor": 38,
    "nama": "ص",
    "namaLatin": "Sad",
    "jumlahAyat": 88,
    "tempatTurun": "Mekah",
    "arti": "Sad"
  },
  {
    "nomor": 39,
    "nama": "الزمر",
    "namaLatin": "Az-Zumar",
    "jumlahAyat": 75,
    "tempatTurun": "Mekah",
    "arti": "Rombongan"
  },
  {
    "nomor": 40,
    "nama": "غافر",
    "namaLatin": "Ghafir",
    "jumlahAyat": 85,
    "tempatTurun": "Mekah",
    "arti": "Maha Pengampun"
  },
  {
    "nomor": 41,
    "nama": "فصّلت",
    "namaLatin": "Fussilat",
    "jumlahAyat": 54,
    "tempatTurun": "Mekah",
    "arti": "Yang Dijelaskan"
  },
  {
    "nomor": 42,
    "nama": "الشورى",
    "namaLatin": "Asy-Syura",
    "jumlahAyat": 53,
    "tempatTurun": "Mekah",
    "arti": "Musyawarah"
  },
  {
    "nomor": 43,
    "nama": "الزخرف",
    "namaLatin": "Az-Zukhruf",
    "jumlahAyat": 89,
    "tempatTurun": "Mekah",
    "arti": "Perhiasan"
  },
  {
    "nomor": 44,
    "nama": "الدخان",
    "namaLatin": "Ad-Dukhan",
    "jumlahAyat": 59,
    "tempatTurun": "Mekah",
    "arti": "Kabut"
  },
  {
    "nomor": 45,
    "nama": "الجاثية",
    "namaLatin": "Al-Jasiyah",
    "jumlahAyat": 37,
    "tempatTurun": "Mekah",
    "arti": "Berlutut"
  },
  {
    "nomor": 46,
    "nama": "الاحقاف",
    "namaLatin": "Al-Ahqaf",
    "jumlahAyat": 35,
    "tempatTurun": "Mekah",
    "arti": "Bukit Pasir"
  },
  {
    "nomor": 47,
    "nama": "محمّد",
    "namaLatin": "Muhammad",
    "jumlahAyat": 38,
    "tempatTurun": "Madinah",
    "arti": "Muhammad"
  },
  {
    "nomor": 48,
    "nama": "الفتح",
    "namaLatin": "Al-Fath",
    "jumlahAyat": 29,
    "tempatTurun": "Madinah",
    "arti": "Kemenangan"
  },
  {
    "nomor": 49,
    "nama": "الحجرٰت",
    "namaLatin": "Al-Hujurat",
    "jumlahAyat": 18,
    "tempatTurun": "Madinah",
    "arti": "Kamar-Kamar"
  },
  {
    "nomor": 50,
    "nama": "ق",
    "namaLatin": "Qaf",
    "jumlahAyat": 45,
    "tempatTurun": "Mekah",
    "arti": "Qaf"
  },
  {
    "nomor": 51,
    "nama": "الذّٰريٰت",
    "namaLatin": "Az-Zariyat",
    "jumlahAyat": 60,
    "tempatTurun": "Mekah",
    "arti": "Angin yang Menerbangkan"
  },
  {
    "nomor": 52,
    "nama": "الطور",
    "namaLatin": "At-Tur",
    "jumlahAyat": 49,
    "tempatTurun": "Mekah",
    "arti": "Bukit Tursina"
  },
  {
    "nomor": 53,
    "nama": "النجم",
    "namaLatin": "An-Najm",
    "jumlahAyat": 62,
    "tempatTurun": "Mekah",
    "arti": "Bintang"
  },
  {
    "nomor": 54,
    "nama": "القمر",
    "namaLatin": "Al-Qamar",
    "jumlahAyat": 55,
    "tempatTurun": "Mekah",
    "arti": "Bulan"
  },
  {
    "nomor": 55,
    "nama": "الرحمن",
    "namaLatin": "Ar-Rahman",
    "jumlahAyat": 78,
    "tempatTurun": "Madinah",
    "arti": "Maha Pengasih"
  },
  {
    "nomor": 56,
    "nama": "الواقعة",
    "namaLatin": "Al-Waqi'ah",
    "jumlahAyat": 96,
    "tempatTurun": "Mekah",
    "arti": "Hari Kiamat"
  },
  {
    "nomor": 57,
    "nama": "الحديد",
    "namaLatin": "Al-Hadid",
    "jumlahAyat": 29,
    "tempatTurun": "Madinah",
    "arti": "Besi"
  },
  {
    "nomor": 58,
    "nama": "المجادلة",
    "namaLatin": "Al-Mujadilah",
    "jumlahAyat": 22,
    "tempatTurun": "Madinah",
    "arti": "Gugatan"
  },
  {
    "nomor": 59,
    "nama": "الحشر",
    "namaLatin": "Al-Hasyr",
    "jumlahAyat": 24,
    "tempatTurun": "Madinah",
    "arti": "Pengusiran"
  },
  {
    "nomor": 60,
    "nama": "الممتحنة",
    "namaLatin": "Al-Mumtahanah",
    "jumlahAyat": 13,
    "tempatTurun": "Madinah",
    "arti": "Wanita Yang Diuji"
  },
  {
    "nomor": 61,
    "nama": "الصّفّ",
    "namaLatin": "As-Saff",
    "jumlahAyat": 14,
    "tempatTurun": "Madinah",
    "arti": "Barisan"
  },
  {
    "nomor": 62,
    "nama": "الجمعة",
    "namaLatin": "Al-Jumu'ah",
    "jumlahAyat": 11,
    "tempatTurun": "Madinah",
    "arti": "Jumat"
  },
  {
    "nomor": 63,
    "nama": "المنٰفقون",
    "namaLatin": "Al-Munafiqun",
    "jumlahAyat": 11,
    "tempatTurun": "Madinah",
    "arti": "Orang-Orang Munafik"
  },
  {
    "nomor": 64,
    "nama": "التغابن",
    "namaLatin": "At-Tagabun",
    "jumlahAyat": 18,
    "tempatTurun": "Madinah",
    "arti": "Pengungkapan Kesalahan"
  },
  {
    "nomor": 65,
    "nama": "الطلاق",
    "namaLatin": "At-Talaq",
    "jumlahAyat": 12,
    "tempatTurun": "Madinah",
    "arti": "Talak"
  },
  {
    "nomor": 66,
    "nama": "التحريم",
    "namaLatin": "At-Tahrim",
    "jumlahAyat": 12,
    "tempatTurun": "Madinah",
    "arti": "Pengharaman"
  },
  {
    "nomor": 67,
    "nama": "الملك",
    "namaLatin": "Al-Mulk",
    "jumlahAyat": 30,
    "tempatTurun": "Mekah",
    "arti": "Kerajaan"
  },
  {
    "nomor": 68,
    "nama": "القلم",
    "namaLatin": "Al-Qalam",
    "jumlahAyat": 52,
    "tempatTurun": "Mekah",
    "arti": "Pena"
  },
  {
    "nomor": 69,
    "nama": "الحاۤقّة",
    "namaLatin": "Al-Haqqah",
    "jumlahAyat": 52,
    "tempatTurun": "Mekah",
    "arti": "Hari Kiamat"
  },
  {
    "nomor": 70,
    "nama": "المعارج",
    "namaLatin": "Al-Ma'arij",
    "jumlahAyat": 44,
    "tempatTurun": "Mekah",
    "arti": "Tempat Naik"
  },
  {
    "nomor": 71,
    "nama": "نوح",
    "namaLatin": "Nuh",
    "jumlahAyat": 28,
    "tempatTurun": "Mekah",
    "arti": "Nuh"
  },
  {
    "nomor": 72,
    "nama": "الجن",
    "namaLatin": "Al-Jinn",
    "jumlahAyat": 28,
    "tempatTurun": "Mekah",
    "arti": "Jin"
  },
  {
    "nomor": 73,
    "nama": "المزّمّل",
    "namaLatin": "Al-Muzzammil",
    "jumlahAyat": 20,
    "tempatTurun": "Mekah",
    "arti": "Orang Yang Berselimut"
  },
  {
    "nomor": 74,
    "nama": "المدّثّر",
    "namaLatin": "Al-Muddassir",
    "jumlahAyat": 56,
    "tempatTurun": "Mekah",
    "arti": "Orang Yang Berkemul"
  },
  {
    "nomor": 75,
    "nama": "القيٰمة",
    "namaLatin": "Al-Qiyamah",
    "jumlahAyat": 40,
    "tempatTurun": "Mekah",
    "arti": "Hari Kiamat"
  },
  {
    "nomor": 76,
    "nama": "الانسان",
    "namaLatin": "Al-Insan",
    "jumlahAyat": 31,
    "tempatTurun": "Madinah",
    "arti": "Manusia"
  },
  {
    "nomor": 77,
    "nama": "المرسلٰت",
    "namaLatin": "Al-Mursalat",
    "jumlahAyat": 50,
    "tempatTurun": "Mekah",
    "arti": "Malaikat Yang Diutus"
  },
  {
    "nomor": 78,
    "nama": "النبأ",
    "namaLatin": "An-Naba'",
    "jumlahAyat": 40,
    "tempatTurun": "Mekah",
    "arti": "Berita Besar"
  },
  {
    "nomor": 79,
    "nama": "النّٰزعٰت",
    "namaLatin": "An-Nazi'at",
    "jumlahAyat": 46,
    "tempatTurun": "Mekah",
    "arti": "Malaikat Yang Mencabut"
  },
  {
    "nomor": 80,
    "nama": "عبس",
    "namaLatin": "'Abasa",
    "jumlahAyat": 42,
    "tempatTurun": "Mekah",
    "arti": "Bermuka Masam"
  },
  {
    "nomor": 81,
    "nama": "التكوير",
    "namaLatin": "At-Takwir",
    "jumlahAyat": 29,
    "tempatTurun": "Mekah",
    "arti": "Penggulungan"
  },
  {
    "nomor": 82,
    "nama": "الانفطار",
    "namaLatin": "Al-Infitar",
    "jumlahAyat": 19,
    "tempatTurun": "Mekah",
    "arti": "Terbelah"
  },
  {
    "nomor": 83,
    "nama": "المطفّفين",
    "namaLatin": "Al-Mutaffifin",
    "jumlahAyat": 36,
    "tempatTurun": "Mekah",
    "arti": "Orang-Orang Curang"
  },
  {
    "nomor": 84,
    "nama": "الانشقاق",
    "namaLatin": "Al-Insyiqaq",
    "jumlahAyat": 25,
    "tempatTurun": "Mekah",
    "arti": "Terbelah"
  },
  {
    "nomor": 85,
    "nama": "البروج",
    "namaLatin": "Al-Buruj",
    "jumlahAyat": 22,
    "tempatTurun": "Mekah",
    "arti": "Gugusan Bintang"
  },
  {
    "nomor": 86,
    "nama": "الطارق",
    "namaLatin": "At-Tariq",
    "jumlahAyat": 17,
    "tempatTurun": "Mekah",
    "arti": "Yang Datang Di Malam Hari"
  },
  {
    "nomor": 87,
    "nama": "الاعلى",
    "namaLatin": "Al-A'la",
    "jumlahAyat": 19,
    "tempatTurun": "Mekah",
    "arti": "Maha Tinggi"
  },
  {
    "nomor": 88,
    "nama": "الغاشية",
    "namaLatin": "Al-Gasyiyah",
    "jumlahAyat": 26,
    "tempatTurun": "Mekah",
    "arti": "Hari Kiamat"
  },
  {
    "nomor": 89,
    "nama": "الفجر",
    "namaLatin": "Al-Fajr",
    "jumlahAyat": 30,
    "tempatTurun": "Mekah",
    "arti": "Fajar"
  },
  {
    "nomor": 90,
    "nama": "البلد",
    "namaLatin": "Al-Balad",
    "jumlahAyat": 20,
    "tempatTurun": "Mekah",
    "arti": "Negeri"
  },
  {
    "nomor": 91,
    "nama": "الشمس",
    "namaLatin": "Asy-Syams",
    "jumlahAyat": 15,
    "tempatTurun": "Mekah",
    "arti": "Matahari"
  },
  {
    "nomor": 92,
    "nama": "الّيل",
    "namaLatin": "Al-Lail",
    "jumlahAyat": 21,
    "tempatTurun": "Mekah",
    "arti": "Malam"
  },
  {
    "nomor": 93,
    "nama": "الضحى",
    "namaLatin": "Ad-Duha",
    "jumlahAyat": 11,
    "tempatTurun": "Mekah",
    "arti": "Duha"
  },
  {
    "nomor": 94,
    "nama": "الشرح",
    "namaLatin": "Al-Insyirah",
    "jumlahAyat": 8,
    "tempatTurun": "Mekah",
    "arti": "Lapang"
  },
  {
    "nomor": 95,
    "nama": "التين",
    "namaLatin": "At-Tin",
    "jumlahAyat": 8,
    "tempatTurun": "Mekah",
    "arti": "Buah Tin"
  },
  {
    "nomor": 96,
    "nama": "العلق",
    "namaLatin": "Al-'Alaq",
    "jumlahAyat": 19,
    "tempatTurun": "Mekah",
    "arti": "Segumpal Darah"
  },
  {
    "nomor": 97,
    "nama": "القدر",
    "namaLatin": "Al-Qadr",
    "jumlahAyat": 5,
    "tempatTurun": "Mekah",
    "arti": "Kemuliaan"
  },
  {
    "nomor": 98,
    "nama": "البيّنة",
    "namaLatin": "Al-Bayyinah",
    "jumlahAyat": 8,
    "tempatTurun": "Madinah",
    "arti": "Bukti Nyata"
  },
  {
    "nomor": 99,
    "nama": "الزلزلة",
    "namaLatin": "Az-Zalzalah",
    "jumlahAyat": 8,
    "tempatTurun": "Madinah",
    "arti": "Guncangan"
  },
  {
    "nomor": 100,
    "nama": "العٰديٰت",
    "namaLatin": "Al-'Adiyat",
    "jumlahAyat": 11,
    "tempatTurun": "Mekah",
    "arti": "Kuda Yang Berlari Kencang"
  },
  {
    "nomor": 101,
    "nama": "القارعة",
    "namaLatin": "Al-Qari'ah",
    "jumlahAyat": 11,
    "tempatTurun": "Mekah",
    "arti": "Hari Kiamat"
  },
  {
    "nomor": 102,
    "nama": "التكاثر",
    "namaLatin": "At-Takasur",
    "jumlahAyat": 8,
    "tempatTurun": "Mekah",
    "arti": "Bermegah-Megahan"
  },
  {
    "nomor": 103,
    "nama": "العصر",
    "namaLatin": "Al-'Asr",
    "jumlahAyat": 3,
    "tempatTurun": "Mekah",
    "arti": "Masa"
  },
  {
    "nomor": 104,
    "nama": "الهمزة",
    "namaLatin": "Al-Humazah",
    "jumlahAyat": 9,
    "tempatTurun": "Mekah",
    "arti": "Pengumpat"
  },
  {
    "nomor": 105,
    "nama": "الفيل",
    "namaLatin": "Al-Fil",
    "jumlahAyat": 5,
    "tempatTurun": "Mekah",
    "arti": "Gajah"
  },
  {
    "nomor": 106,
    "nama": "قريش",
    "namaLatin": "Quraisy",
    "jumlahAyat": 4,
    "tempatTurun": "Mekah",
    "arti": "Quraisy"
  },
  {
    "nomor": 107,
    "nama": "الماعون",
    "namaLatin": "Al-Ma'un",
    "jumlahAyat": 7,
    "tempatTurun": "Mekah",
    "arti": "Barang Yang Berguna"
  },
  {
    "nomor": 108,
    "nama": "الكوثر",
    "namaLatin": "Al-Kausar",
    "jumlahAyat": 3,
    "tempatTurun": "Mekah",
    "arti": "Pemberian Yang Banyak"
  },
  {
    "nomor": 109,
    "nama": "الكٰفرون",
    "namaLatin": "Al-Kafirun",
    "jumlahAyat": 6,
    "tempatTurun": "Mekah",
    "arti": "Orang-Orang kafir"
  },
  {
    "nomor": 110,
    "nama": "النصر",
    "namaLatin": "An-Nasr",
    "jumlahAyat": 3,
    "tempatTurun": "Madinah",
    "arti": "Pertolongan"
  },
  {
    "nomor": 111,
    "nama": "اللهب",
    "namaLatin": "Al-Lahab",
    "jumlahAyat": 5,
    "tempatTurun": "Mekah",
    "arti": "Api Yang Bergejolak"
  },
  {
    "nomor": 112,
    "nama": "الاخلاص",
    "namaLatin": "Al-Ikhlas",
    "jumlahAyat": 4,
    "tempatTurun": "Mekah",
    "arti": "Ikhlas"
  },
  {
    "nomor": 113,
    "nama": "الفلق",
    "namaLatin": "Al-Falaq",
    "jumlahAyat": 5,
    "tempatTurun": "Madinah",
    "arti": "Subuh"
  },
  {
    "nomor": 114,
    "nama": "الناس",
    "namaLatin": "An-Nas",
    "jumlahAyat": 6,
    "tempatTurun": "Madinah",
    "arti": "Manusia"
  }
]
