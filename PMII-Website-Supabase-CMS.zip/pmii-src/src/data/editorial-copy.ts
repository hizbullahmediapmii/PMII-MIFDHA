import type { ContentEntry } from './types'

type Paragraphs = ContentEntry['body']

export const editorialCopy: Record<string, Paragraphs> = {
  'merawat-tradisi-diskusi': [
    { text: 'Di kampus, pengetahuan tidak hanya berpindah melalui ceramah. Ia juga tumbuh ketika seorang mahasiswa mengajukan pertanyaan, ketika peserta lain menyampaikan keberatan, dan ketika sebuah gagasan dibaca kembali dengan lebih teliti.' },
    { heading: 'Memberi tempat bagi perbedaan', text: 'Sebuah forum membutuhkan kesepakatan sederhana: mendengar sampai selesai, menyebut sumber, dan membedakan kritik terhadap argumen dari penilaian terhadap orang. Kebiasaan ini membuat diskusi lebih aman tanpa menghilangkan ketajamannya.' },
    { heading: 'Percakapan yang meninggalkan catatan', text: 'Hasil diskusi dapat dirawat melalui catatan singkat. Apa pertanyaan utamanya? Sumber apa yang perlu dibaca? Bagian mana yang belum disepakati? Catatan semacam itu membantu forum berikutnya melanjutkan percakapan, bukan selalu memulai dari awal.' },
  ],
  'literasi-di-ruang-kampus': [
    { text: 'Buku di perpustakaan baru menjadi bagian dari kehidupan kampus ketika ia dibuka dan dibicarakan. Literasi bukan hanya keterampilan memahami kalimat, tetapi juga kesediaan memeriksa hubungan antara teks dan pengalaman sehari-hari.' },
    { heading: 'Memulai dari bacaan yang dekat', text: 'Kelompok baca tidak harus berangkat dari buku yang tebal. Sebuah esai pendek, arsip organisasi, atau laporan mengenai lingkungan sekitar dapat menjadi bahan pertama. Pilih satu pertanyaan, baca sumber bersama, lalu buat catatan yang bisa diakses kembali.' },
    { heading: 'Ketekunan, bukan perlombaan', text: 'Jumlah buku bukan satu-satunya ukuran pembelajaran. Kemampuan menjelaskan argumen dengan bahasa sendiri, menemukan batas informasi, dan mengubah pendapat setelah membaca adalah bagian dari kebiasaan literasi yang patut dijaga.' },
  ],
  'keislaman-dan-kepedulian': [
    { text: 'Percakapan tentang keislaman di ruang mahasiswa dapat dibuka melalui persoalan yang dekat: cara memperlakukan sesama, kejujuran dalam pekerjaan, dan kesediaan memperhatikan mereka yang jarang mendapat tempat dalam percakapan.' },
    { heading: 'Mendengar sebelum menyimpulkan', text: 'Kepedulian memerlukan pengetahuan tentang keadaan orang lain. Mendengar pengalaman, memeriksa kebutuhan, dan menghormati batas privasi merupakan langkah awal sebelum merancang sebuah kegiatan sosial.' },
    { heading: 'Rujukan yang dapat ditelusuri', text: 'Pembahasan nilai agama perlu menyertakan sumber dan konteks. Kutipan yang tersebar tanpa rujukan tidak sebaiknya langsung menjadi dasar keputusan. Bimbingan pembimbing agama tetap penting, terutama ketika percakapan menyangkut ketentuan amalan.' },
  ],
  'budaya-menulis-mahasiswa': [
    { text: 'Tidak semua gagasan langsung hadir dalam bentuk tulisan yang rapi. Ada yang dimulai dari pertanyaan selepas diskusi, coretan pada halaman buku, atau catatan tentang peristiwa yang baru saja diamati.' },
    { heading: 'Memberi ruang bagi draf', text: 'Budaya menulis tumbuh ketika tulisan yang belum selesai boleh dibaca tanpa segera dihakimi. Umpan balik yang berguna menunjukkan bagian yang belum jelas, pertanyaan yang belum terjawab, serta sumber yang dapat memperkuat argumen.' },
    { heading: 'Menyunting sebagai kerja bersama', text: 'Penyuntingan bukan sekadar membetulkan ejaan. Ia juga membantu penulis menjaga ketepatan informasi dan mempertimbangkan pembacanya. Tulisan yang diterbitkan perlu membedakan fakta, opini, dan dugaan secara terang.' },
  ],
  'ruang-publik-yang-inklusif': [
    { text: 'Ruang kampus yang terbuka tidak cukup ditandai oleh pintu yang dapat dimasuki. Ia juga terlihat dari siapa yang boleh berbicara, siapa yang didengar, dan bagaimana informasi dibagikan kepada mereka yang tidak hadir.' },
    { heading: 'Akses yang sering terlewat', text: 'Pengumuman yang hanya beredar di satu kelompok dapat membuat sebagian mahasiswa tertinggal. Informasi publik perlu ditulis dengan jelas: apa acaranya, untuk siapa, kapan berlangsung, dan siapa yang bertanggung jawab.' },
    { heading: 'Terbuka tanpa mengabaikan privasi', text: 'Keterbukaan tidak membenarkan penyebaran biodata pribadi. Dokumentasi harus memperhatikan persetujuan orang yang ada di dalamnya. Informasi kegiatan dapat dibagikan tanpa menampilkan nomor kontak, dokumen internal, atau data keanggotaan.' },
  ],
  'mengenal-pmii': [
    { heading: 'Organisasi sebagai pengalaman belajar', text: 'Mengenal organisasi dapat dimulai dengan membaca dokumen resminya, mendengar penjelasan pengurus, dan memperhatikan cara kerja sehari-hari. Identitas tidak cukup dipahami dari singkatan atau lambang; ia juga dibaca melalui nilai dan tanggung jawab yang diemban.' },
    { heading: 'Pertanyaan untuk pembaca baru', text: 'Apa tujuan organisasi? Bagaimana keputusan diambil? Apa hubungan antara pembelajaran dan kegiatan? Pertanyaan ini membantu anggota baru melihat bahwa organisasi adalah ruang yang perlu dipahami, bukan hanya tempat mengikuti agenda.' },
    { heading: 'Melanjutkan pembacaan', text: 'Catat istilah yang belum dipahami, lalu bawa ke forum pembelajaran. Gunakan dokumen organisasi yang disahkan sebagai rujukan. Tulisan pengantar ini membantu menata pertanyaan; ia tidak menggantikan materi kaderisasi resmi.' },
  ],
  'membaca-ndp': [
    { text: 'Nilai Dasar Pergerakan perlu dibaca sebagai dokumen yang memiliki konteks dan arah. Pembaca sebaiknya memulai dari naskah resmi, bukan hanya potongan kalimat yang dikutip tanpa penjelasan.' },
    { heading: 'Dari istilah menuju pemahaman', text: 'Tandai istilah penting, tuliskan pemahaman sementara, lalu bandingkan dengan penjelasan dalam forum pembelajaran. Perbedaan tafsir perlu dibicarakan dengan menyebut dasar pembacaan masing-masing.' },
    { heading: 'Menguji nilai dalam pengalaman', text: 'Pertanyaan reflektif dapat membantu: bagaimana sebuah keputusan mencerminkan nilai yang dipelajari? Apa yang perlu diperbaiki dalam cara bekerja bersama? Jawaban tidak harus selesai dalam satu pertemuan; ia dapat menjadi catatan pembelajaran yang terus diperbarui.' },
  ],
  'aswaja-dan-kehidupan': [
    { text: 'Pembelajaran Aswaja menuntut ketelitian dalam memilih sumber dan memahami konteks. Pengantar yang baik membantu pembaca mengenali istilah sebelum melangkah pada pembahasan yang lebih luas.' },
    { heading: 'Membedakan sumber dan penjelasan', text: 'Ketika membaca, catat mana teks sumber, mana penjelasan pengajar, dan mana pemahaman pribadi. Pembedaan ini menjaga agar sebuah pendapat tidak keliru dianggap sebagai kutipan atau ketentuan agama.' },
    { heading: 'Ruang dialog yang bertanggung jawab', text: 'Pertanyaan tentang tradisi, pemikiran, dan praktik keagamaan sebaiknya dibahas bersama pembimbing yang memahami rujukannya. Tulisan ini merupakan panduan kebiasaan belajar, bukan kesimpulan teologis atau fatwa.' },
  ],
  'organisasi-sebagai-ruang-belajar': [
    { text: 'Pekerjaan organisasi mempertemukan orang dengan kebiasaan dan pengalaman yang berbeda. Menata agenda, membagi tanggung jawab, dan menyelesaikan perbedaan pendapat dapat menjadi proses belajar jika dilakukan dengan kesadaran.' },
    { heading: 'Keputusan yang dapat dijelaskan', text: 'Sebuah keputusan lebih mudah dipertanggungjawabkan ketika alasan, pembagian tugas, dan batas waktunya tercatat. Catatan rapat tidak perlu panjang, tetapi harus jelas bagi pihak yang memang berhak mengaksesnya.' },
    { heading: 'Evaluasi tanpa saling menyalahkan', text: 'Evaluasi dapat dimulai dari rencana yang telah disepakati: bagian mana yang berjalan, apa yang terhambat, dan dukungan apa yang belum tersedia? Fokus pada proses membantu anggota menyusun perbaikan yang lebih konkret.' },
  ],
  'kepemimpinan-yang-mendengar': [
    { text: 'Kepemimpinan tidak selalu terlihat dari orang yang paling banyak berbicara. Kadang ia hadir melalui kemampuan menjaga percakapan agar semua pihak memahami masalah yang sedang dihadapi.' },
    { heading: 'Mendengar dengan tujuan yang jelas', text: 'Mendengar bukan berarti menerima semua usulan tanpa pertimbangan. Pemimpin perlu mengumpulkan informasi, menjelaskan keterbatasan, dan membuka alasan keputusan agar dapat dipahami bersama.' },
    { heading: 'Membagi tanggung jawab', text: 'Pembagian tugas yang baik mencantumkan hasil yang diharapkan, sumber daya yang tersedia, dan waktu untuk memeriksa kemajuan. Orang yang menerima tugas juga perlu memiliki ruang untuk bertanya dan menyampaikan kendala.' },
  ],
  'membaca-sejarah-organisasi': [
    { text: 'Sejarah organisasi tidak sebaiknya dibangun hanya dari ingatan satu orang. Arsip, dokumen resmi, foto yang diketahui konteksnya, dan kesaksian yang dapat diperiksa saling membantu menyusun gambaran yang lebih utuh.' },
    { heading: 'Mencatat asal sebuah informasi', text: 'Tuliskan siapa pembuat dokumen, kapan disusun, dan untuk tujuan apa. Jika dua sumber berbeda, pertahankan keterangan perbedaannya sampai ada penjelasan yang memadai; jangan menghapus ketidakpastian demi cerita yang terlihat rapi.' },
    { heading: 'Batas arsip publik', text: 'Tidak semua arsip layak diterbitkan. Dokumen yang memuat biodata, laporan keuangan internal, atau korespondensi pribadi membutuhkan peninjauan khusus. Ringkasan sejarah publik dapat disusun tanpa membuka informasi yang dilindungi.' },
  ],
  'kaderisasi-sebagai-proses': [
    { text: 'Pembelajaran dalam organisasi berlangsung melalui bacaan, perjumpaan, dan pengalaman bekerja bersama. Prosesnya memerlukan pendampingan agar peserta tidak hanya mengetahui istilah, tetapi juga memahami alasan di balik suatu praktik.' },
    { heading: 'Rencana pembelajaran yang terukur', text: 'Sebuah sesi dapat dimulai dengan tujuan yang sederhana: memahami satu dokumen, menyusun satu pertanyaan, atau mampu menjelaskan suatu gagasan. Pilihan bahan dan metode perlu disesuaikan dengan kebutuhan peserta.' },
    { heading: 'Pendampingan dan refleksi', text: 'Berikan kesempatan untuk bertanya tanpa tekanan. Catatan refleksi membantu melihat perubahan pemahaman dan kebutuhan berikutnya. Panduan ini bersifat pengantar; jenjang dan ketentuan kaderisasi mengikuti keputusan resmi organisasi.' },
  ],
  'etika-membaca-sumber-agama': [
    { text: 'Kecepatan berbagi informasi sering melampaui kesempatan untuk memeriksanya. Dalam bacaan keagamaan, ketelitian menjadi penting karena sebuah kutipan dapat kehilangan makna ketika dipisahkan dari sumbernya.' },
    { heading: 'Periksa sebelum meneruskan', text: 'Cari teks asli, penulis atau penyusun, serta keterangan rujukannya. Jangan menambahkan redaksi atau jumlah pengulangan yang tidak tercantum dalam sumber. Jika sumber belum ditemukan, nyatakan batas pengetahuan itu dengan jelas.' },
    { heading: 'Belajar bersama pembimbing', text: 'Teks dan terjemahan dapat membantu membuka pembacaan, tetapi tidak menggantikan penjelasan yang memadai. Ketika menyangkut hukum atau bimbingan amalan, rujuk pengajar yang memiliki kompetensi dan memahami konteks pertanyaan.' },
  ],
  'mahasiswa-dan-keindonesiaan': [
    { text: 'Membicarakan Indonesia dari ruang kampus dapat dimulai dengan lingkungan terdekat: akses pendidikan, kehidupan pekerja, kebudayaan setempat, serta cara masyarakat membicarakan persoalan bersama.' },
    { heading: 'Berangkat dari pengamatan', text: 'Bedakan pengalaman pribadi dari keadaan yang berlaku lebih luas. Data resmi, arsip kebijakan, dan wawancara yang dilakukan dengan persetujuan dapat membantu memperjelas persoalan. Catat juga keterbatasan bahan yang dimiliki.' },
    { heading: 'Gagasan yang dapat diperiksa', text: 'Usulan yang baik menjelaskan masalah, dasar informasi, pihak yang terlibat, serta kemungkinan dampaknya. Kesediaan memperbaiki usulan setelah menerima tanggapan merupakan bagian dari tanggung jawab intelektual.' },
  ],
  'membangun-argumen': [
    { text: 'Sebuah argumen menghubungkan pernyataan dengan alasan. Ia menjadi lebih kuat bukan karena disampaikan dengan keras, tetapi karena dasar informasinya dapat diperiksa dan hubungannya dapat dijelaskan.' },
    { heading: 'Pernyataan, alasan, dan bukti', text: 'Tuliskan terlebih dahulu apa yang ingin Anda sampaikan. Susun alasan yang mendukungnya, lalu cari bukti yang relevan. Hindari menggunakan satu pengalaman sebagai penjelasan untuk seluruh keadaan.' },
    { heading: 'Membaca keberatan', text: 'Coba temukan tanggapan paling masuk akal terhadap pandangan Anda. Mengakui keberatan tidak selalu melemahkan tulisan; ia dapat membantu menunjukkan batas argumen serta bagian yang masih membutuhkan pembacaan.' },
  ],
  'kampus-dan-ruang-berpikir': [
    { text: 'Ada sore ketika sebuah halaman terasa lebih panjang daripada seluruh kabar yang lewat di layar. Kita berhenti, membaca ulang, lalu menemukan bahwa kalimat yang semula sederhana ternyata menyimpan pertanyaan.' },
    { heading: 'Kebebasan untuk tidak segera menjawab', text: 'Di kampus, kesibukan sering membuat jawaban cepat tampak lebih berharga. Padahal, sebagian pertanyaan membutuhkan waktu. Membaca pelan memberi kesempatan untuk tidak berpura-pura memahami sesuatu yang belum kita mengerti.' },
    { text: 'Barangkali ruang belajar yang baik bukan tempat semua orang memiliki jawaban. Ia adalah tempat seseorang boleh berkata, “Saya belum tahu,” lalu mendapat teman untuk mencari. Di antara buku dan percakapan, sikap semacam itu layak dipelihara.' },
  ],
  'membaca-untuk-memahami': [
    { text: 'Ketika sebuah bacaan hanya dipakai untuk memenangkan perdebatan, kita mudah memilih kalimat yang mendukung pendapat sendiri dan melewatkan bagian yang mengganggunya. Buku menjadi gudang pembenaran, bukan ruang untuk belajar.' },
    { heading: 'Mengenali kebiasaan sendiri', text: 'Cobalah menuliskan argumen penulis sebelum menyampaikan keberatan. Apakah kita telah menjelaskan pandangannya secara adil? Adakah konteks yang belum dibaca? Pertanyaan ini membantu kritik menjadi percakapan, bukan sekadar penolakan.' },
    { text: 'Memahami tidak selalu berarti menyetujui. Kita tetap dapat berbeda pendapat setelah membaca dengan saksama. Perbedaannya terletak pada kesediaan untuk menjelaskan alasan, mengakui batas, dan tidak mengubah pandangan orang lain menjadi sesuatu yang lebih mudah dikalahkan.' },
  ],
  'bangku-dekat-jendela': [
    { text: 'Setiap sore, bangku dekat jendela perpustakaan itu dibiarkan kosong beberapa menit sebelum seseorang duduk. Di atas mejanya selalu ada bekas lingkaran cangkir yang tidak sepenuhnya hilang meski sudah dilap.' },
    { text: 'Hari itu, sebuah catatan tertinggal di sela buku: “Jika sudah selesai, letakkan kembali. Masih ada yang ingin membaca.” Tidak ada nama. Ia membaca kalimat itu dua kali, lalu melipat kertasnya dengan lebih rapi.' },
    { text: 'Ketika bel penutup berbunyi, buku kembali ke rak. Bangku dekat jendela kosong lagi. Di luar, hujan belum berhenti, tetapi seseorang telah meninggalkan sesuatu yang lebih lama daripada sore: kesempatan bagi pembaca berikutnya.' },
    { text: 'Cerita pendek fiktif yang ditulis sebagai contoh karya. Tokoh dan peristiwa tidak merujuk anggota atau kegiatan organisasi.' },
  ],
  'catatan-untuk-resensi': [
    { heading: 'Lebih dari ringkasan isi', text: 'Resensi mempertemukan pembaca dengan sebuah buku melalui pilihan yang dibuat penulis resensi: apa gagasan utamanya, bagaimana argumennya disusun, dan untuk siapa bacaan itu dapat berguna.' },
    { heading: 'Membaca dengan pertanyaan', text: 'Sebelum menilai, catat tujuan buku dan jenis pembaca yang dibayangkan. Periksa apakah contoh dan sumbernya mendukung argumen. Sebuah keberatan akan lebih berguna jika disertai bagian teks yang menjadi dasar pembacaan.' },
    { text: 'Naskah ini adalah catatan tentang cara menulis resensi, bukan ulasan atas buku tertentu. Pada publikasi resmi, identitas buku, edisi, penerbit, dan tahun terbit perlu dicantumkan agar pembaca dapat menemukan sumber yang sama.' },
  ],
  'menata-kajian-literatur': [
    { heading: 'Pertanyaan kajian', text: 'Sebuah kajian literatur dapat dimulai dengan pertanyaan yang dibatasi secara jelas. Catat tema, periode, jenis sumber, dan alasan pembatasannya sebelum mengumpulkan bahan.' },
    { heading: 'Pencatatan sumber', text: 'Gunakan tabel kerja untuk mencatat identitas publikasi, metode, gagasan utama, serta keterbatasan yang disebut penulis. Bedakan temuan sumber dari penafsiran Anda sendiri. Kutipan dan parafrasa sama-sama membutuhkan rujukan.' },
    { heading: 'Batas naskah contoh', text: 'Naskah ini memperlihatkan rancangan struktur tulisan ilmiah. Tidak ada data penelitian, hasil pengujian, atau temuan empiris yang diklaim. Sebuah karya ilmiah lengkap memerlukan proses peninjauan dan sumber yang dapat diperiksa.' },
  ],
  'membaca-ruang-melalui-fotografi': [
    { text: 'Foto sebuah ruang tidak hanya memperlihatkan bangunan atau benda. Pilihan jarak, cahaya, dan bagian yang dibiarkan di luar bingkai ikut membentuk cara kita melihatnya.' },
    { heading: 'Keterangan adalah bagian dari karya', text: 'Dokumentasi yang bertanggung jawab mencantumkan konteks dan kredit fotografer. Foto ilustrasi perlu diberi keterangan sebagai ilustrasi agar tidak keliru dianggap sebagai bukti kegiatan.' },
    { text: 'Gambar pada halaman ini bersumber dari Unsplash dan dipakai sebagai ilustrasi. Ia bukan karya fotografi anggota PMII dan bukan dokumentasi lokasi organisasi. Halaman ini menjadi contoh struktur publikasi fotografi yang dapat diganti dengan karya berizin.' },
  ],
  'lingkar-baca': [
    { heading: 'Tentang format kegiatan', text: 'Halaman ini memperlihatkan cara sebuah kegiatan literasi dapat didokumentasikan: tema, waktu, tempat, penyelenggara, dan catatan pembelajaran dipisahkan agar mudah ditemukan. Ini bukan laporan kegiatan yang sudah berlangsung.' },
    { heading: 'Catatan yang perlu dihimpun', text: 'Pada dokumentasi resmi, pengelola dapat mencatat bahan bacaan, pertanyaan utama, dan refleksi peserta yang telah menyetujui publikasi. Daftar hadir serta nomor kontak tidak menjadi bagian dari halaman publik.' },
    { heading: 'Dokumentasi berizin', text: 'Galeri di bawah menggunakan foto ilustrasi. Foto kegiatan sesungguhnya perlu diperiksa konteks, kredit, dan persetujuannya sebelum menggantikan gambar contoh.' },
  ],
  'kelas-penulisan': [
    { heading: 'Ruang belajar editorial', text: 'Contoh halaman ini menggambarkan struktur dokumentasi kelas penulisan. Informasi mengenai fasilitator, peserta, waktu, dan lokasi belum merupakan informasi kegiatan resmi.' },
    { heading: 'Dari draf menuju tulisan', text: 'Catatan pembelajaran dapat memuat proses memilih topik, memeriksa sumber, menyusun argumen, dan menerima penyuntingan. Kutipan peserta hanya dapat diterbitkan setelah persetujuan.' },
    { heading: 'Arsip yang dapat dibaca kembali', text: 'Bahan pembelajaran yang mendapat izin publikasi dapat ditautkan dari dokumentasi. Dokumen internal, hasil penilaian pribadi, dan kontak peserta tetap berada di luar arsip publik.' },
  ],
  'ruang-pengabdian': [
    { heading: 'Mencatat proses pengabdian', text: 'Halaman ini adalah contoh format arsip pengabdian. Tidak ada program, mitra, penerima manfaat, atau hasil kegiatan nyata yang diklaim telah berlangsung.' },
    { heading: 'Kebutuhan dan persetujuan', text: 'Laporan publik perlu menjelaskan kebutuhan yang dibicarakan bersama masyarakat, bentuk kegiatan, serta batas hasil yang dapat disampaikan. Foto dan cerita pribadi harus mengikuti persetujuan pihak terkait.' },
    { heading: 'Belajar dari pelaksanaan', text: 'Refleksi dapat membahas apa yang perlu diteruskan dan apa yang perlu diperbaiki tanpa mengungkap keadaan pribadi orang yang terlibat. Arsip keuangan internal tidak diterbitkan dalam dokumentasi kegiatan.' },
  ],
  'forum-baca': [
    { heading: 'Tentang agenda contoh', text: 'Format ini menggambarkan forum baca tentang hubungan kampus dan kehidupan masyarakat. Tanggal yang tercantum hanya dipakai untuk memperlihatkan fungsi kalender, bukan jadwal acara resmi.' },
    { heading: 'Susunan informasi', text: 'Agenda resmi perlu memuat bahan yang dibahas, waktu, tempat, penyelenggara, dan informasi akses. Jika suatu informasi belum disahkan, pengelola tidak sebaiknya menyajikannya sebagai kepastian.' },
    { text: 'Berkas kalender yang dapat diunduh tetap diberi penanda CONTOH. Tidak ada pendaftaran, biaya, atau pengumpulan data peserta pada halaman ini.' },
  ],
  'laboratorium-tulisan': [
    { heading: 'Tentang agenda contoh', text: 'Halaman ini menunjukkan format pertemuan penulisan: topik, tanggal, waktu, dan tempat disajikan secara ringkas. Pertemuan ini belum merupakan undangan atau keputusan organisasi.' },
    { heading: 'Ruang bagi naskah', text: 'Pada agenda yang sudah disahkan, pengelola dapat menjelaskan jenis bahan yang perlu dibawa dan cara berbagi naskah. Naskah pribadi tidak perlu dibuka ke publik untuk mengikuti proses pembelajaran.' },
    { text: 'Berkas kalender berlabel CONTOH tersedia untuk mencoba pengalaman agenda. Situs ini tidak menjanjikan fasilitator, sertifikat, atau hasil kegiatan.' },
  ],
  'dialog-kaderisasi': [
    { heading: 'Tentang agenda contoh', text: 'Format agenda ini menyediakan ruang untuk menjelaskan sebuah dialog pembelajaran. Tema dan waktu dalam contoh tidak menandakan kegiatan telah mendapat persetujuan penyelenggara.' },
    { heading: 'Informasi yang perlu jelas', text: 'Ketika agenda resmi diterbitkan, pembaca perlu mengetahui sasaran peserta, materi, lokasi, dan penanggung jawab. Ketentuan internal tetap mengikuti dokumen organisasi, bukan isi contoh situs.' },
    { text: 'Tidak ada formulir pendaftaran atau pengumpulan biodata. Pengunduhan kalender hanya menyimpan informasi agenda contoh di perangkat Anda.' },
  ],
}
