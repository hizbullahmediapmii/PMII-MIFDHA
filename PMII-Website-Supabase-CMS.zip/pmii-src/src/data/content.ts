import type { ContentEntry, ContentKind, PublicImage, Section } from './types'
import { editorialCopy } from './editorial-copy'

export const images: Record<string, PublicImage> = {
  study: { src: '/img/study-circle.jpg', alt: 'Sekelompok mahasiswa berdiskusi bersama di meja belajar; foto ilustrasi, bukan dokumentasi PMII', credit: 'Foto ilustrasi: Unsplash', illustrative: true },
  library: { src: '/img/library.jpg', alt: 'Rak buku di perpustakaan; foto ilustrasi ruang keilmuan', credit: 'Foto ilustrasi: Unsplash', illustrative: true },
  writing: { src: '/img/writing.jpg', alt: 'Buku catatan dan kegiatan menulis; foto ilustrasi', credit: 'Foto ilustrasi: Unsplash', illustrative: true },
  reflection: { src: '/img/reflection.jpg', alt: 'Langit malam di atas pegunungan; foto ilustrasi untuk ruang refleksi', credit: 'Foto ilustrasi: Unsplash', illustrative: true },
}

export const sections: Record<ContentKind, Section> = {
  berita: { title: 'Berita & Wacana', eyebrow: 'KABAR PERGERAKAN', description: 'Membaca peristiwa, merawat nalar, dan melihat kehidupan kampus dari dekat.', categories: ['Politik', 'Daerah', 'Nasional', 'Pendidikan', 'Keislaman', 'PMII', 'Sosial', 'Budaya', 'Olahraga'] },
  materi: { title: 'Ruang Belajar PMII', eyebrow: 'ARSIP PENGETAHUAN', description: 'Tempat membaca, mendalami nilai, dan membangun pemahaman bersama.', categories: ['Ke-PMII-an', 'NDP PMII', 'Aswaja', 'Keislaman', 'Keindonesiaan', 'Kaderisasi', 'Organisasi', 'Kepemimpinan', 'Intelektual', 'Sejarah PMII'] },
  kegiatan: { title: 'Kegiatan PMII', eyebrow: 'DARI GAGASAN KE GERAKAN', description: 'Ruang perjumpaan, pembelajaran, dan pengabdian. Dokumentasi yang terbuka untuk publik.', categories: ['Diskusi', 'Kaderisasi', 'Pengabdian', 'Kebudayaan'] },
  karya: { title: 'Karya Sahabat', eyebrow: 'SUARA & GAGASAN', description: 'Tulisan yang tumbuh dari kegelisahan, pembacaan, dan pengalaman para sahabat.', categories: ['Esai', 'Opini', 'Puisi', 'Cerpen', 'Resensi', 'Karya Ilmiah', 'Fotografi'] },
  agenda: { title: 'Agenda Pergerakan', eyebrow: 'CATAT TANGGALNYA', description: 'Ruang temu untuk belajar dan bergerak. Informasi waktu serta tempat tersedia pada setiap agenda.', categories: ['Diskusi', 'Kaderisasi', 'Pengabdian', 'Literasi'] },
  angkatan: { title: 'Jejak Angkatan', eyebrow: 'MERAWAT PERSAHABATAN', description: 'Setiap angkatan membawa cerita. Ruang ini hanya memuat profil dan dokumentasi yang disetujui untuk publik.', categories: ['2025', '2024', '2023'] },
}

const learningBody = [
  { heading: 'Memulai dari pertanyaan', text: 'Belajar di perguruan tinggi tidak berhenti pada ruang kelas. Percakapan antarmahasiswa membuka kesempatan untuk menghubungkan pengetahuan dengan persoalan yang hadir dalam kehidupan sehari-hari. Sebuah pertanyaan yang sederhana dapat menjadi awal pembacaan yang lebih mendalam.' },
  { heading: 'Membaca, mendengar, dan berdialog', text: 'Diskusi yang baik memberi tempat bagi perbedaan. Peserta perlu membedakan pendapat, pengalaman, dan informasi yang dapat diperiksa. Membaca sumber asli, mencatat argumen, serta mendengar dengan saksama membantu kita menyusun pandangan yang bertanggung jawab.' },
  { heading: 'Menyambungkan ilmu dengan kehidupan', text: 'Pengetahuan menjadi bermakna ketika ia membantu kita memahami lingkungan sekitar. Catatan bacaan dapat diolah menjadi tulisan, bahan diskusi, atau gagasan pengabdian. Yang penting bukan sekadar banyaknya kegiatan, melainkan ketekunan untuk menilai kembali apa yang telah dipelajari.' },
  { text: 'Tulisan ini merupakan contoh editorial untuk memperlihatkan pengalaman membaca pada situs publik. Ia bukan laporan kegiatan, pernyataan resmi, atau pengganti dokumen organisasi yang telah disahkan.' },
]

function entry(kind: ContentKind, slug: string, title: string, category: string, excerpt: string, photo = 'study', day = '03'): ContentEntry {
  const body = editorialCopy[slug] ?? learningBody
  const readingMinutes = Math.max(1, Math.ceil(body.map(paragraph => paragraph.text).join(' ').split(/\s+/).length / 180))
  return { id: `${kind}-${slug}`, kind, slug, title, category, excerpt, body, image: images[photo], author: { name: 'Redaksi', role: 'Konten contoh' }, publishedAt: `2026-10-${day}T09:00:00+07:00`, readingMinutes, visibility: 'PUBLIC', isDemo: true }
}

export const demoContent: ContentEntry[] = [
  entry('berita', 'merawat-tradisi-diskusi', 'Merawat tradisi diskusi, menumbuhkan keberanian berpikir', 'Pendidikan', 'Kampus adalah tempat bertemunya gagasan. Percakapan yang terbuka menjadi bagian penting dari kehidupan mahasiswa.'),
  entry('berita', 'literasi-di-ruang-kampus', 'Literasi tidak berhenti di ruang kelas', 'Pendidikan', 'Membaca buku, menyusun pertanyaan, dan membicarakan hal-hal yang dekat dengan keseharian.', 'library', '02'),
  entry('berita', 'keislaman-dan-kepedulian', 'Keislaman dan kepedulian terhadap sesama', 'Keislaman', 'Menempatkan kepedulian sosial sebagai bagian dari percakapan tentang nilai dan tanggung jawab.', 'study', '01'),
  entry('berita', 'budaya-menulis-mahasiswa', 'Menghidupkan budaya menulis di kalangan mahasiswa', 'Budaya', 'Tulisan adalah cara memperpanjang percakapan dan menjaga gagasan agar tidak lekas hilang.', 'writing', '01'),
  entry('berita', 'ruang-publik-yang-inklusif', 'Membayangkan ruang publik kampus yang lebih inklusif', 'Sosial', 'Setiap suara perlu ruang untuk didengar. Catatan tentang keterbukaan dan kehidupan bersama.', 'study', '01'),
  entry('materi', 'mengenal-pmii', 'Mengenal PMII: nilai, identitas, dan arah pergerakan', 'Ke-PMII-an', 'Pengantar untuk menata pertanyaan awal tentang organisasi dan ruang belajar mahasiswa.', 'library'),
  entry('materi', 'membaca-ndp', 'Membaca Nilai Dasar Pergerakan', 'NDP PMII', 'Mendekati nilai sebagai bahan refleksi, bukan sekadar istilah yang dihafalkan.', 'writing', '02'),
  entry('materi', 'aswaja-dan-kehidupan', 'Aswaja sebagai ruang belajar dan dialog', 'Aswaja', 'Catatan pengantar tentang pentingnya sumber, konteks, dan kehati-hatian dalam membaca.', 'library', '01'),
  entry('materi', 'organisasi-sebagai-ruang-belajar', 'Organisasi sebagai ruang belajar bersama', 'Organisasi', 'Membangun kebiasaan mendengar, mencatat, dan mengambil keputusan secara bertanggung jawab.', 'study', '01'),
  entry('materi', 'kepemimpinan-yang-mendengar', 'Kepemimpinan dimulai dari kesediaan mendengar', 'Kepemimpinan', 'Catatan pembelajaran tentang tanggung jawab dan kerja kolektif.', 'writing', '01'),
  entry('materi', 'membaca-sejarah-organisasi', 'Cara membaca sejarah organisasi', 'Sejarah PMII', 'Mengutamakan arsip dan sumber resmi sebelum menyusun kesimpulan.', 'library', '01'),
  entry('materi', 'kaderisasi-sebagai-proses', 'Kaderisasi sebagai proses pembelajaran', 'Kaderisasi', 'Pendampingan, pembacaan, dan refleksi sebagai kebiasaan belajar bersama.', 'study', '01'),
  entry('materi', 'etika-membaca-sumber-agama', 'Etika membaca dan membagikan sumber agama', 'Keislaman', 'Memeriksa asal kutipan, memahami batas, dan belajar bersama pembimbing.', 'library', '01'),
  entry('materi', 'mahasiswa-dan-keindonesiaan', 'Mahasiswa dan percakapan tentang Indonesia', 'Keindonesiaan', 'Menautkan kehidupan kampus dengan persoalan masyarakat secara bertanggung jawab.', 'study', '01'),
  entry('materi', 'membangun-argumen', 'Membangun argumen yang dapat diperiksa', 'Intelektual', 'Menyambungkan pernyataan, alasan, dan bukti tanpa mengabaikan keberatan.', 'writing', '01'),
  entry('karya', 'kampus-dan-ruang-berpikir', 'Kampus, buku, dan ruang untuk berpikir pelan', 'Esai', 'Di tengah arus informasi yang cepat, membaca pelan dapat menjadi bentuk keberanian.', 'writing'),
  entry('karya', 'catatan-di-tepi-halaman', 'Catatan di tepi halaman', 'Puisi', 'Tentang kata-kata yang tinggal setelah buku ditutup.', 'reflection', '02'),
  entry('karya', 'membaca-untuk-memahami', 'Membaca bukan untuk menang, melainkan memahami', 'Opini', 'Membuka ruang bagi pendapat yang berbeda tanpa kehilangan ketelitian.', 'library', '01'),
  entry('karya', 'bangku-dekat-jendela', 'Bangku dekat jendela', 'Cerpen', 'Sebuah buku, selembar catatan, dan kesempatan bagi pembaca berikutnya. Cerita fiktif.', 'library', '01'),
  entry('karya', 'catatan-untuk-resensi', 'Catatan kecil untuk menulis resensi', 'Resensi', 'Membicarakan buku dengan adil, lebih jauh dari sekadar ringkasan.', 'writing', '01'),
  entry('karya', 'menata-kajian-literatur', 'Menata catatan literatur: rancangan kajian mahasiswa', 'Karya Ilmiah', 'Contoh struktur kajian, bukan laporan penelitian atau temuan empiris.', 'library', '01'),
  entry('karya', 'membaca-ruang-melalui-fotografi', 'Membaca ruang melalui fotografi', 'Fotografi', 'Tentang bingkai, konteks, dan pentingnya keterangan pada sebuah gambar.', 'library', '01'),
  entry('kegiatan', 'lingkar-baca', 'Lingkar baca & diskusi mahasiswa', 'Diskusi', 'Contoh dokumentasi kegiatan literasi. Bukan laporan kegiatan resmi yang telah dilaksanakan.'),
  entry('kegiatan', 'kelas-penulisan', 'Kelas penulisan dan kerja editorial', 'Kebudayaan', 'Contoh halaman kegiatan untuk mengarsipkan proses belajar menulis.', 'writing', '02'),
  entry('kegiatan', 'ruang-pengabdian', 'Belajar bersama, mengabdi dengan pengetahuan', 'Pengabdian', 'Contoh struktur dokumentasi pengabdian dan refleksi kegiatan.', 'library', '01'),
  ...[
    { slug: 'forum-baca', title: 'Forum baca: kampus dan tanggung jawab sosial', category: 'Diskusi', date: '2026-11-07T15:30:00+07:00' },
    { slug: 'laboratorium-tulisan', title: 'Laboratorium tulisan sahabat', category: 'Literasi', date: '2026-11-14T09:00:00+07:00' },
    { slug: 'dialog-kaderisasi', title: 'Dialog tentang ruang belajar dan kaderisasi', category: 'Kaderisasi', date: '2026-11-21T13:00:00+07:00' },
  ].map(item => ({ ...entry('agenda', item.slug, item.title, item.category, 'Agenda contoh untuk memperlihatkan format kalender. Bukan undangan atau jadwal resmi.'), event: { startsAt: item.date, endsAt: item.date.replace(/T\d{2}:\d{2}/, 'T17:00'), location: 'Lokasi belum dipublikasikan — agenda contoh', organizer: 'Contoh format penyelenggara' } })),
  ...[2025, 2024, 2023].map(year => ({ ...entry('angkatan', `angkatan-${year}`, `Angkatan ${year}`, String(year), 'Contoh profil angkatan. Nama, dokumentasi, dan pencapaian resmi hanya ditampilkan setelah persetujuan publikasi.'), body: [{ heading: `Ruang publik Angkatan ${year}`, text: 'Profil ini memperlihatkan struktur halaman angkatan: cerita bersama, foto berizin, kegiatan publik, dan pencapaian yang dapat diperiksa. Tidak ada daftar nama anggota atau biodata pada contoh ini.' }, { heading: 'Kegiatan dan dokumentasi', text: 'Dokumentasi kegiatan diterbitkan setelah judul, waktu, keterangan foto, dan persetujuan publikasi dikonfirmasi. Foto yang terlihat sekarang adalah ilustrasi, bukan foto angkatan.' }, { text: 'Nomor telepon, email pribadi, sertifikat, keuangan, dan arsip internal tidak menjadi bagian dari profil publik.' }], cohort: { year, achievements: [] } })),
]

demoContent.filter(item => item.kind === 'kegiatan').forEach(item => {
  item.event = { startsAt: item.publishedAt, endsAt: item.publishedAt, location: 'Lokasi belum dipublikasikan — kegiatan contoh', organizer: 'Contoh format penyelenggara' }
  item.documentation = [item.image, images.library]
})

const poem = demoContent.find(item => item.slug === 'catatan-di-tepi-halaman')
if (poem) poem.body = [{ text: 'Di tepi halaman\nsebuah pertanyaan tumbuh.\nBukan untuk lekas dijawab,\nmelainkan untuk dibawa pulang.' }, { text: 'Buku ditutup,\npercakapan belum.\nAda yang tertinggal di antara kata:\nkesediaan untuk mendengar.' }, { text: 'Puisi contoh, ditulis untuk situs ini. Bukan karya yang diatribusikan kepada anggota organisasi.' }]
