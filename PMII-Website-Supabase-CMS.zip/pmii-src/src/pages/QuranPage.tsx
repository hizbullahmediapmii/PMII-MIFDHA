import { useEffect, useState } from 'react'
import { ArrowLeft, ArrowRight, Bookmark, BookOpen, Check, Copy, Search, X } from 'lucide-react'
import { Breadcrumb, EmptyState } from '@/components/editorial'
import { IslamicNav } from '@/components/IslamicNav'
import { surahIndex } from '@/data/surah-index'
import { islamicService } from '@/services/islamic'
import type { ReadingState, Surah } from '@/services/islamic'

export function QuranPage({ surahNumber, initialAyah = '' }: { surahNumber?: number; initialAyah?: string }) {
  const [query, setQuery] = useState('')
  const [ayahQuery, setAyahQuery] = useState('')
  const [surah, setSurah] = useState<Surah | null>(null)
  const [offline, setOffline] = useState(false)
  const [error, setError] = useState('')
  const [retry, setRetry] = useState(0)
  const [translation, setTranslation] = useState(true)
  const [fontSize, setFontSize] = useState(32)
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)
  const [readerState, setReaderState] = useState<'loading' | 'available' | 'unavailable'>('loading')
  const [readerRetry, setReaderRetry] = useState(0)
  const [showSaved, setShowSaved] = useState(false)
  const [saved, setSaved] = useState<ReadingState>({ lastRead: null, bookmarks: [] })
  useEffect(() => {
    let active = true
    setReaderState('loading')
    islamicService.readingState().then(value => { if (active) { setSaved(value); setReaderState('available') } }).catch(() => { if (active) { setReaderState('unavailable'); setStatus('Penyimpanan bacaan belum tersedia. Membaca dan menyalin tetap dapat digunakan.') } })
    return () => { active = false }
  }, [readerRetry])
  useEffect(() => {
    if (!status) return
    const timer = setTimeout(() => setStatus(''), 7000)
    return () => clearTimeout(timer)
  }, [status])
  useEffect(() => {
    if (!surahNumber) return
    const controller = new AbortController()
    setSurah(null); setError('')
    islamicService.surah(surahNumber, controller.signal).then(result => { setSurah(result.data); setOffline(result.offline) }).catch(reason => { if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Surah belum dapat dimuat.') })
    return () => controller.abort()
  }, [surahNumber, retry])
  useEffect(() => {
    if (surah && Number(initialAyah) >= 1 && Number(initialAyah) <= surah.jumlahAyat) document.getElementById(`ayat-${Number(initialAyah)}`)?.scrollIntoView({ block: 'start' })
  }, [surah, initialAyah])
  const store = async (ayah: number, action: 'bookmark' | 'remove' | 'last-read') => {
    if (!surahNumber || busy || readerState === 'loading') return
    setBusy(true)
    try {
      const position = { surah: surahNumber, ayah }
      await islamicService.saveReading(position, action)
      setReaderState('available')
      setSaved(current => action === 'last-read' ? { ...current, lastRead: position } : { ...current, bookmarks: action === 'bookmark' ? [...current.bookmarks, position] : current.bookmarks.filter(item => item.surah !== surahNumber || item.ayah !== ayah) })
      setStatus(action === 'last-read' ? `Bacaan terakhir disimpan pada ayat ${ayah}.` : action === 'bookmark' ? `Ayat ${ayah} ditandai.` : `Penanda ayat ${ayah} dihapus.`)
    } catch (reason) { setStatus(reason instanceof Error ? reason.message : 'Penanda belum berhasil disimpan.') } finally { setBusy(false) }
  }
  const normalizeSearch = (value: string) => value.normalize('NFKC').replace(/[\u064B-\u065F\u0670\u0640]/g, '').toLocaleLowerCase('id-ID').trim()
  const normalizedQuery = normalizeSearch(query)
  const filtered = surahIndex.filter(item => /^\d+$/.test(normalizedQuery) ? item.nomor === Number(normalizedQuery) : normalizeSearch(`${item.namaLatin} ${item.nama} ${item.arti} ${item.nomor}`).includes(normalizedQuery))
  const savedFiltered = saved.bookmarks.filter(position => filtered.some(info => info.nomor === position.surah))
  const normalizedAyahQuery = normalizeSearch(ayahQuery)
  const visibleAyahs = surah?.ayat.filter(ayah => {
    if (/^\d+$/.test(normalizedAyahQuery)) return ayah.nomorAyat === Number(normalizedAyahQuery)
    if (/^\d+:\d+$/.test(normalizedAyahQuery)) { const [chapter, verse] = normalizedAyahQuery.split(':').map(Number); return chapter === surahNumber && verse === ayah.nomorAyat }
    return normalizeSearch(`${ayah.teksArab} ${ayah.teksLatin} ${ayah.teksIndonesia}`).includes(normalizedAyahQuery)
  }) ?? []
  const jumpToAyah = (number: string) => {
    setAyahQuery('')
    setTimeout(() => document.getElementById(`ayat-${number}`)?.scrollIntoView({ block: 'start', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }), 0)
  }
  const copy = async (arabic: string, indonesian: string, ayah: number) => {
    try { await navigator.clipboard.writeText(`${arabic}\n\n${indonesian}\n\nQS. ${surah?.namaLatin} ${surahNumber}:${ayah} — EQuran.id`); setStatus(`Teks ayat ${ayah} berhasil disalin.`) } catch { setStatus('Penyalinan tidak tersedia. Pilih teks untuk menyalin secara manual.') }
  }
  return <div className={`container quran-page ${surahNumber ? 'reading-page' : ''}`}><Breadcrumb items={surahNumber ? [{ label: 'Al-Qur’an', href: '/al-quran' }, { label: surahIndex.find(item => item.nomor === surahNumber)?.namaLatin ?? 'Surah' }] : [{ label: 'Al-Qur’an' }]} />{!surahNumber ? <>
    <header className="page-heading quran-heading"><p className="eyebrow">RUANG KEISLAMAN · AL-QUR’AN</p><h1>Membaca. Merenungkan.<br /><em>Mendekatkan diri.</em></h1><p>114 surah, teks Arab, dan terjemahan Indonesia dari EQuran.id. Baca dengan tenang, lanjutkan dari tempat Anda berhenti.</p></header><div className="quran-list-top"><div className="collection-search"><Search size={19} /><label htmlFor="surah-query" className="sr-only">Cari nama atau nomor surah</label><input id="surah-query" value={query} onChange={event => setQuery(event.target.value)} placeholder="Cari nama, arti, atau nomor surah…" /></div><button className={`outline-button ${showSaved ? 'selected' : ''}`} onClick={() => setShowSaved(!showSaved)} aria-pressed={showSaved}><Bookmark size={17} />Penanda ({saved.bookmarks.length})</button></div>{saved.lastRead && <a className="last-read" href={`/al-quran/${saved.lastRead.surah}?ayat=${saved.lastRead.ayah}`}><BookOpen size={22} /><span><small>BACAAN TERAKHIR</small><strong>{surahIndex.find(item => item.nomor === saved.lastRead?.surah)?.namaLatin} · Ayat {saved.lastRead.ayah}</strong></span><ArrowRight size={20} /></a>}{showSaved ? readerState === 'loading' ? <div className="reading-skeleton" role="status"><span /><p>Memuat penanda perangkat…</p></div> : readerState === 'unavailable' ? <div className="api-error"><h2>Penanda belum dapat dimuat.</h2><p>Penyimpanan sedang tidak tersedia. Bacaan Al-Qur’an tetap dapat dibuka.</p><button className="button" onClick={() => setReaderRetry(value => value + 1)}>Muat ulang penanda</button></div> : savedFiltered.length ? <div className="surah-grid">{savedFiltered.map(item => <a key={`${item.surah}-${item.ayah}`} className="surah-item" href={`/al-quran/${item.surah}?ayat=${item.ayah}`}><Bookmark size={20} /><div><strong>{surahIndex.find(surahInfo => surahInfo.nomor === item.surah)?.namaLatin}</strong><span>Ayat {item.ayah}</span></div><ArrowRight size={16} /></a>)}</div> : <EmptyState title={query ? 'Penanda tidak ditemukan.' : 'Belum ada ayat yang ditandai.'} text={query ? 'Coba nama atau nomor surah lain.' : 'Buka sebuah surah, lalu pilih ikon penanda pada ayat yang ingin Anda baca kembali.'} /> : <><p className="result-count" role="status">{filtered.length} dari 114 surah</p><div className="surah-grid">{filtered.map(item => <a href={`/al-quran/${item.nomor}`} className="surah-item" key={item.nomor}><span className="surah-number">{String(item.nomor).padStart(2, '0')}</span><div><strong>{item.namaLatin}</strong><span>{item.arti} · {item.jumlahAyat} ayat</span></div><span className="arabic surah-arabic" lang="ar" dir="rtl">{item.nama}</span></a>)}</div>{!filtered.length && <EmptyState title="Surah tidak ditemukan." text="Gunakan nama Latin, arti surah, atau nomor 1 sampai 114." />}</>}
  </> : <>
    <header className="surah-reading-heading"><p className="eyebrow">AL-QUR’AN · SURAH {surahNumber}</p><h1>{surah?.namaLatin ?? surahIndex.find(item => item.nomor === surahNumber)?.namaLatin}</h1>{surah && <><p className="arabic" lang="ar" dir="rtl">{surah.nama}</p><span>{surah.arti} · {surah.tempatTurun} · {surah.jumlahAyat} ayat</span></>}</header><div className="reader-toolbar"><label>Surah<select value={surahNumber} onChange={event => { window.location.href = `/al-quran/${event.target.value}` }}>{surahIndex.map(item => <option key={item.nomor} value={item.nomor}>{item.nomor}. {item.namaLatin}</option>)}</select></label><label>Ke ayat<select defaultValue={initialAyah || '1'} onChange={event => jumpToAyah(event.target.value)}>{Array.from({ length: surah?.jumlahAyat ?? 1 }, (_, index) => <option value={index + 1} key={index + 1}>{index + 1}</option>)}</select></label><button className="outline-button" aria-pressed={translation} onClick={() => setTranslation(!translation)}>{translation ? 'Sembunyikan arti' : 'Tampilkan arti'}</button><div className="font-controls"><button aria-label="Perkecil teks Arab" disabled={fontSize <= 26} onClick={() => setFontSize(value => value - 2)}>A−</button><button aria-label="Perbesar teks Arab" disabled={fontSize >= 46} onClick={() => setFontSize(value => value + 2)}>A+</button></div></div><div className="ayah-search"><div className="collection-search"><Search size={18} /><label htmlFor="ayah-query" className="sr-only">Cari teks atau nomor ayat dalam surah ini</label><input id="ayah-query" value={ayahQuery} onChange={event => setAyahQuery(event.target.value)} placeholder="Cari arti, teks Arab, transliterasi, atau nomor ayat…" /></div>{ayahQuery && surah && <p className="result-count" role="status">{visibleAyahs.length} ayat ditemukan dalam {surah.namaLatin}</p>}</div>{offline && <p className="source-note">Cuplikan Al-Fatihah tersimpan dari EQuran.id pada 5 Oktober 2026. Layanan langsung sedang tidak tersedia; ini bukan salinan lengkap Al-Qur’an.</p>}{error ? <div className="api-error" role="alert"><h2>Bacaan belum dapat dimuat.</h2><p>{error}</p><button className="button" onClick={() => setRetry(value => value + 1)}>Coba kembali</button><a className="text-link" href="/al-quran/1">Buka Al-Fatihah<ArrowRight size={17} /></a></div> : !surah ? <div className="reading-skeleton" role="status" aria-label="Memuat surah"><span /><span /><span /><p>Memuat bacaan dari sumber…</p></div> : <div className="ayah-list">{visibleAyahs.map(ayah => {
      const bookmarked = saved.bookmarks.some(position => position.surah === surahNumber && position.ayah === ayah.nomorAyat)
      return <article className="ayah" key={ayah.nomorAyat} id={`ayat-${ayah.nomorAyat}`}><div className="ayah-top"><span>{surahNumber}:{ayah.nomorAyat}</span><div><button className={`icon-button ${bookmarked ? 'bookmarked' : ''}`} disabled={busy || readerState === 'loading'} onClick={() => store(ayah.nomorAyat, bookmarked ? 'remove' : 'bookmark')} aria-pressed={bookmarked} aria-label={`${bookmarked ? 'Hapus penanda' : 'Tandai'} ayat ${ayah.nomorAyat}`}><Bookmark size={18} fill={bookmarked ? 'currentColor' : 'none'} /></button><button className="icon-button" onClick={() => copy(ayah.teksArab, ayah.teksIndonesia, ayah.nomorAyat)} aria-label={`Salin ayat ${ayah.nomorAyat}`}><Copy size={17} /></button><button className={`icon-button ${saved.lastRead?.surah === surahNumber && saved.lastRead?.ayah === ayah.nomorAyat ? 'last-read-marker' : ''}`} aria-pressed={saved.lastRead?.surah === surahNumber && saved.lastRead?.ayah === ayah.nomorAyat} disabled={busy || readerState === 'loading'} onClick={() => store(ayah.nomorAyat, 'last-read')} aria-label={`Simpan ayat ${ayah.nomorAyat} sebagai bacaan terakhir`}><Check size={19} /></button></div></div><p className="arabic ayah-arabic" lang="ar" dir="rtl" style={{ fontSize: `${fontSize}px` }}>{ayah.teksArab}</p>{translation && <><p className="ayah-latin">{ayah.teksLatin}</p><p className="ayah-translation">{ayah.teksIndonesia}</p></>}</article>
    })}{visibleAyahs.length === 0 && <EmptyState title="Ayat tidak ditemukan dalam surah ini." text="Ubah kata pencarian atau kosongkan isian untuk kembali membaca seluruh surah." />}{surah.audioFull?.['05'] && <div className="quran-audio"><span>Murattal · Misyari Rasyid Al-Afasi · EQuran.id</span><audio controls preload="none" src={surah.audioFull['05']} aria-label={`Murattal surah ${surah.namaLatin}`} /></div>}</div>}<div className="surah-pager">{surahNumber > 1 ? <a className="outline-button" href={`/al-quran/${surahNumber - 1}`}><ArrowLeft size={17} />Surah sebelumnya</a> : <span />}<a className="text-link" href="/al-quran">Daftar surah</a>{surahNumber < 114 ? <a className="outline-button" href={`/al-quran/${surahNumber + 1}`}>Surah berikutnya<ArrowRight size={17} /></a> : <span />}</div>
  </>}<div aria-live="polite">{status && <div className="reading-feedback" role="status"><p>{status}</p><button className="icon-button" onClick={() => setStatus('')} aria-label="Tutup pemberitahuan bacaan"><X size={17} /></button></div>}</div><div className="quran-source"><p>Sumber teks Arab dan terjemahan: <a href="https://equran.id/apidev" target="_blank" rel="noreferrer">EQuran.id</a>. Metadata 114 surah tersedia tanpa koneksi; teks lengkap dimuat per surah. Penanda tersimpan untuk perangkat ini, tanpa akun.</p><a href="/kebijakan-publikasi">Kelola data bacaan & privasi</a></div><IslamicNav compact /></div>
}
