import { useEffect, useMemo, useState } from 'react'
import { signIn, supabaseRequest } from '../services/supabase'
import type { ContentKind } from '../data/types'

const kinds: ContentKind[] = ['berita','materi','kegiatan','karya','agenda','angkatan']
const tables: Record<ContentKind,string> = { berita:'articles', materi:'materials', kegiatan:'activities', karya:'works', agenda:'agendas', angkatan:'cohorts' }

type Row = Record<string, any>

export function AdminPage() {
  const [session, setSession] = useState<any>(() => { try { return JSON.parse(localStorage.getItem('pmii_admin_session') || 'null') } catch { return null } })
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [kind, setKind] = useState<ContentKind>('berita')
  const [rows, setRows] = useState<Row[]>([])
  const [editing, setEditing] = useState<Row | null>(null)
  const [message, setMessage] = useState('')

  const token = session?.access_token
  const empty = useMemo(() => ({ title:'', slug:'', category:'', excerpt:'', content:'', featured_image:'', status:'draft', author_name:'', event_date:'', start_at:'', end_at:'', location:'', organizer:'', year:'' }), [])

  async function load() {
    if (!token) return
    const data = await supabaseRequest<Row[]>(`/rest/v1/${tables[kind]}?select=*&order=created_at.desc`, {}, token)
    setRows(data)
  }
  useEffect(() => { void load().catch(error => setMessage(error.message)) }, [kind, token])

  async function login(event: React.FormEvent) {
    event.preventDefault(); setMessage('')
    try { const next = await signIn(email, password); localStorage.setItem('pmii_admin_session', JSON.stringify(next)); setSession(next) } catch (error) { setMessage(error instanceof Error ? error.message : 'Login gagal') }
  }
  function logout() { localStorage.removeItem('pmii_admin_session'); setSession(null) }

  async function save(event: React.FormEvent) {
    event.preventDefault(); if (!token || !editing) return
    const payload: Row = { title: editing.title, slug: editing.slug || editing.title.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''), excerpt: editing.excerpt || null, content: editing.content || null, status: editing.status || 'draft', author_name: editing.author_name || null, featured_image: editing.featured_image || null }
    if (kind === 'kegiatan') Object.assign(payload, { event_date: editing.event_date || null, location: editing.location || null, organizer: editing.organizer || null })
    if (kind === 'agenda') Object.assign(payload, { start_at: editing.start_at || null, end_at: editing.end_at || null, location: editing.location || null, organizer: editing.organizer || null })
    if (kind === 'angkatan') Object.assign(payload, { year: editing.year ? Number(editing.year) : null, description: editing.excerpt || null })
    try {
      if (editing.id) await supabaseRequest(`/rest/v1/${tables[kind]}?id=eq.${editing.id}`, { method:'PATCH', headers:{Prefer:'return=minimal'}, body:JSON.stringify(payload) }, token)
      else await supabaseRequest(`/rest/v1/${tables[kind]}`, { method:'POST', headers:{Prefer:'return=minimal'}, body:JSON.stringify(payload) }, token)
      setEditing(null); setMessage('Tersimpan.'); await load()
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal menyimpan') }
  }
  async function remove(id: string) {
    if (!token || !confirm('Hapus konten ini?')) return
    try { await supabaseRequest(`/rest/v1/${tables[kind]}?id=eq.${id}`, { method:'DELETE' }, token); await load() } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal menghapus') }
  }

  if (!session) return <main className="mx-auto max-w-md px-6 py-20"><h1 className="font-serif text-3xl">Admin PMII</h1><p className="mt-2 text-slate-600">Kelola konten publik tanpa mengubah tampilan website.</p><form onSubmit={login} className="mt-8 space-y-4"><input required type="email" placeholder="Email admin" value={email} onChange={e=>setEmail(e.target.value)} className="w-full rounded-lg border p-3"/><input required type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full rounded-lg border p-3"/><button className="w-full rounded-lg bg-slate-900 px-4 py-3 text-white">Masuk</button></form>{message && <p className="mt-4 text-sm text-red-700">{message}</p>}</main>

  return <main className="mx-auto max-w-6xl px-5 py-8"><div className="flex flex-wrap items-center justify-between gap-4"><div><p className="text-xs uppercase tracking-[.2em] text-slate-500">Ruang Redaksi</p><h1 className="font-serif text-3xl">Admin PMII Institut Miftahul Huda</h1></div><button onClick={logout} className="rounded-lg border px-4 py-2">Keluar</button></div><div className="mt-8 flex flex-wrap gap-2">{kinds.map(item=><button key={item} onClick={()=>{setKind(item);setEditing(null)}} className={`rounded-full border px-4 py-2 ${kind===item?'bg-slate-900 text-white':''}`}>{item}</button>)}<button onClick={()=>setEditing(empty)} className="rounded-full bg-[#c9a227] px-4 py-2 text-slate-950">+ Tambah</button></div>{message&&<p className="mt-4 text-sm text-emerald-700">{message}</p>}<div className="mt-6 grid gap-3">{rows.map(row=><article key={row.id} className="flex flex-wrap items-center justify-between gap-3 border-b py-4"><div><h2 className="font-serif text-xl">{row.title}</h2><p className="text-sm text-slate-500">{row.status} · {row.slug}</p></div><div className="flex gap-2"><button onClick={()=>setEditing({...empty,...row})} className="rounded-lg border px-3 py-2">Edit</button><button onClick={()=>remove(row.id)} className="rounded-lg border px-3 py-2 text-red-700">Hapus</button></div></article>)}</div>{editing&&<form onSubmit={save} className="mt-8 grid gap-4 border-t pt-8"><h2 className="font-serif text-2xl">{editing.id?'Edit':'Tambah'} {kind}</h2>{[['title','Judul'],['slug','Slug'],['category','Kategori'],['excerpt','Ringkasan'],['featured_image','URL foto'],['author_name','Penulis'],['event_date','Tanggal kegiatan'],['start_at','Mulai agenda'],['end_at','Selesai agenda'],['location','Lokasi'],['organizer','Penyelenggara'],['year','Tahun angkatan']].map(([key,label])=><input key={key} placeholder={label} value={editing[key] ?? ''} onChange={e=>setEditing({...editing,[key]:e.target.value})} className="w-full rounded-lg border p-3"/>)}<select value={editing.status ?? 'draft'} onChange={e=>setEditing({...editing,status:e.target.value})} className="rounded-lg border p-3"><option value="draft">Draft</option><option value="review">Review</option><option value="published">Published</option><option value="archived">Archived</option></select><textarea placeholder="Isi konten" rows={12} value={editing.content ?? ''} onChange={e=>setEditing({...editing,content:e.target.value})} className="w-full rounded-lg border p-3"/><div className="flex gap-2"><button className="rounded-lg bg-slate-900 px-5 py-3 text-white">Simpan</button><button type="button" onClick={()=>setEditing(null)} className="rounded-lg border px-5 py-3">Batal</button></div></form>}</main>
}
