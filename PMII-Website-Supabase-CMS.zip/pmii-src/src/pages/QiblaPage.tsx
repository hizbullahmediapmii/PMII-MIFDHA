import { useEffect, useRef, useState } from 'react'
import { Compass, Navigation, RotateCcw } from 'lucide-react'
import { Breadcrumb } from '@/components/editorial'
import { IslamicNav } from '@/components/IslamicNav'
import { LocationPicker } from '@/components/LocationPicker'
import { locations } from '@/data/locations'
import { qiblaBearing } from '@/utils/location'

type CompassEvent = DeviceOrientationEvent & { webkitCompassHeading?: number; webkitCompassAccuracy?: number }

export function QiblaPage() {
  const [location, setLocation] = useState(locations[0])
  const [heading, setHeading] = useState<number | null>(null)
  const [status, setStatus] = useState('Sensor kompas belum aktif. Diagram menunjukkan arah terhadap utara sejati, bukan orientasi perangkat.')
  const [sensorActive, setSensorActive] = useState(false)
  const cleanup = useRef<(() => void) | null>(null)
  const bearing = qiblaBearing(location.latitude, location.longitude)
  useEffect(() => () => cleanup.current?.(), [])
  const activate = async () => {
    cleanup.current?.(); setHeading(null); setSensorActive(false)
    if (!window.DeviceOrientationEvent) { setStatus('Sensor orientasi tidak tersedia. Gunakan derajat arah dan kompas fisik yang dikalibrasi.'); return }
    try {
      const orientation = window.DeviceOrientationEvent as typeof DeviceOrientationEvent & { requestPermission?: () => Promise<string> }
      if (orientation.requestPermission && await orientation.requestPermission() !== 'granted') { setStatus('Izin sensor tidak diberikan. Diagram arah manual tetap tersedia.'); return }
      let received = false
      const handle = (event: Event) => {
        const compass = event as CompassEvent
        const measured = typeof compass.webkitCompassHeading === 'number' && (compass.webkitCompassAccuracy == null || compass.webkitCompassAccuracy >= 0) ? compass.webkitCompassHeading : compass.absolute && compass.alpha !== null ? (360 - compass.alpha) % 360 : null
        if (measured === null || !Number.isFinite(measured)) return
        received = true; setHeading(measured); setSensorActive(true); setStatus('Data orientasi perangkat diterima. Akurasi bergantung pada kalibrasi dan gangguan magnetik; periksa dengan kompas fisik.')
      }
      window.addEventListener('deviceorientationabsolute', handle)
      window.addEventListener('deviceorientation', handle)
      const timer = setTimeout(() => { if (!received) { setStatus('Tidak ada pembacaan kompas absolut. Gunakan arah manual; arah perangkat tidak ditampilkan.'); setSensorActive(false); window.removeEventListener('deviceorientationabsolute', handle); window.removeEventListener('deviceorientation', handle) } }, 5000)
      cleanup.current = () => { clearTimeout(timer); window.removeEventListener('deviceorientationabsolute', handle); window.removeEventListener('deviceorientation', handle) }
      setStatus('Menunggu pembacaan kompas absolut…')
    } catch { setStatus('Sensor tidak dapat diaktifkan. Gunakan diagram arah manual.'); setSensorActive(false) }
  }
  const stop = () => { cleanup.current?.(); cleanup.current = null; setHeading(null); setSensorActive(false); setStatus('Sensor dihentikan. Diagram kembali menunjukkan arah terhadap utara sejati.') }
  return <div className="container qibla-page"><Breadcrumb items={[{ label: 'Arah Kiblat' }]} /><header className="page-heading"><p className="eyebrow">RUANG KEISLAMAN · MENEMUKAN ARAH</p><h1>Arah Kiblat<span className="gold-dot">.</span></h1><p>Arah menuju Ka’bah dari lokasi pilihan. Gunakan utara sejati sebagai acuan ketika sensor perangkat tidak tersedia.</p></header><LocationPicker location={location} onChange={setLocation} coordinates /><div className="qibla-layout"><section className="compass-section" aria-label={`Arah kiblat ${bearing.toFixed(1)} derajat dari utara sejati`}><div className="compass"><div className="compass-rings" aria-hidden="true" /><div className="compass-directions" style={{ transform: `rotate(${-1 * (heading ?? 0)}deg)` }} aria-hidden="true"><span className="compass-north">U</span><span className="compass-east">T</span><span className="compass-south">S</span><span className="compass-west">B</span></div><div className="compass-arrow" style={{ transform: `rotate(${bearing - (heading ?? 0)}deg)` }} aria-hidden="true"><Navigation size={90} strokeWidth={1} /></div><span className="compass-center" aria-hidden="true" /></div><div className="bearing-label"><span>ARAH KIBLAT</span><strong>{bearing.toFixed(1)}<small>°</small></strong><p>{heading === null ? 'Dari utara sejati, searah jarum jam' : `Orientasi sensor: ${heading.toFixed(1)}° · estimasi`}</p></div></section><aside className="qibla-instructions"><p className="eyebrow">{location.name.toUpperCase()}</p><h2>Satu arah.<br /><em>Dengan acuan yang tepat.</em></h2><p className="location-coordinates">{location.latitude.toFixed(5)}, {location.longitude.toFixed(5)}</p><ol><li>Letakkan perangkat mendatar, jauh dari logam dan medan magnet.</li><li>Jika sensor tidak tersedia, tentukan utara sejati dengan kompas yang dikalibrasi atau peta.</li><li>Putar searah jarum jam sebesar {bearing.toFixed(1)}° dari utara untuk menghadap kiblat.</li></ol><div className="sensor-status" role="status"><Compass size={22} /><p>{status}</p></div><div className="sensor-actions"><button className="button" onClick={activate}><Compass size={17} />{sensorActive ? 'Kalibrasi ulang sensor' : 'Aktifkan sensor kompas'}</button>{sensorActive && <button className="outline-button" onClick={stop}><RotateCcw size={16} />Hentikan sensor</button>}</div><p className="section-note">Diagram tanpa sensor bukan kompas langsung. Arah dihitung dengan rumus azimut lingkaran besar ke koordinat Ka’bah (21.422487, 39.826206). Sensor dapat menggunakan utara magnetik, yang berbeda dari utara sejati.</p></aside></div><IslamicNav compact /></div>
}
