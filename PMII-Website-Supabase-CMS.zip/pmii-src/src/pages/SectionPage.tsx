import { lazy, Suspense } from 'react'
import { CollectionPage } from './CollectionPage'
import { SearchPage } from './SearchPage'
import { isContentKind } from '@/services/content'

const QuranPage = lazy(() => import('./QuranPage').then(module => ({ default: module.QuranPage })))
const DevotionalPage = lazy(() => import('./DevotionalPage').then(module => ({ default: module.DevotionalPage })))
const PrayerPage = lazy(() => import('./PrayerPage').then(module => ({ default: module.PrayerPage })))
const QiblaPage = lazy(() => import('./QiblaPage').then(module => ({ default: module.QiblaPage })))
const AboutPage = lazy(() => import('./AboutPage').then(module => ({ default: module.AboutPage })))
const PolicyPage = lazy(() => import('./PolicyPage').then(module => ({ default: module.PolicyPage })))

export function SectionPage({ section, search }: { section: string; search: { q: string; kategori: string; jenis: string } }) {
  if (isContentKind(section)) return <CollectionPage key={section} kind={section} initialCategory={search.kategori} />
  if (section === 'cari') return <SearchPage initialQuery={search.q} initialKind={search.jenis} />
  return <Suspense fallback={<div className="container reading-skeleton" role="status"><span /><span /><span /><p>Memuat ruang bacaan…</p></div>}>
    {section === 'al-quran' && <QuranPage />}
    {(section === 'dzikir' || section === 'doa') && <DevotionalPage key={section} kind={section} />}
    {section === 'jadwal-salat' && <PrayerPage />}
    {section === 'arah-kiblat' && <QiblaPage />}
    {section === 'tentang' && <AboutPage />}
    {section === 'kebijakan-publikasi' && <PolicyPage />}
  </Suspense>
}
