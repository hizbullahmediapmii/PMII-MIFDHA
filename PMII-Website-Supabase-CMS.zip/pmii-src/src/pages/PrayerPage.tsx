import { useEffect, useState } from 'react'
import { Clock, MoonStar, Sun } from 'lucide-react'
import { Breadcrumb } from '@/components/editorial'
import { IslamicNav } from '@/components/IslamicNav'
import { LocationPicker } from '@/components/LocationPicker'
import { locations } from '@/data/locations'
import type { PrayerSchedule } from '@/services/prayer'
import { prayerService } from '@/services/prayer'
import { localClock } from '@/utils/location'

const prayerNames = [{ key: 'Fajr', label: 'Subuh' }, { key: 'Dhuhr', label: 'Dzuhur' }, { key: 'Asr', label: 'Ashar' }, { key: 'Maghrib', label: 'Maghrib' }, { key: 'Isha', label: 'Isya' }] as const

export function PrayerPage() {
  const [location, setLocation] = useState(locations[0])
  const [now, setNow] = useState<Date | null>(null)
  const [schedule, setSchedule] = useState<PrayerSchedule | null>(null)
  const [error, setError] = useState('')
  const [retry, setRetry] = useState(0)
  useEffect(() => { setNow(new Date()); const timer = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(timer) }, [])
  const localDate = now ? localClock(now, location.timezone).date : ''
  useEffect(() => {
    if (!localDate) return
    const controller = new AbortController()
    setSchedule(null); setError('')
    prayerService.schedule(location, localDate, controller.signal).then(value => {
      if (controller.signal.aborted) return
      if (value.today.data.meta.timezone !== location.timezone) setLocation(current => ({ ...current, timezone: value.today.data.meta.timezone }))
      if (localClock(new Date(), value.today.data.meta.timezone).date !== localDate) return
      setSchedule(value)
    }).catch(reason => { if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Jadwal belum tersedia.') })
    return () => controller.abort()
  }, [location, localDate, retry])
  const timezone = schedule?.today.data.meta.timezone ?? location.timezone
  const clock = now ? localClock(now, timezone) : null
  const timeSeconds = (value: string) => { const [hours, minutes] = value.slice(0, 5).split(':').map(Number); return hours * 3600 + minutes * 60 }
  const next = schedule && clock ? prayerNames.find(prayer => timeSeconds(schedule.today.data.timings[prayer.key]) > clock.seconds) : undefined
  const nextLabel = next?.label ?? 'Subuh'
  const nextTime = schedule ? (next ? schedule.today.data.timings[next.key] : schedule.tomorrow.data.timings.Fajr) : null
  const remaining = clock && nextTime ? (next ? 0 : 86400) + timeSeconds(nextTime) - clock.seconds : 0
  const countdown = remaining > 0 ? [Math.floor(remaining / 3600), Math.floor(remaining / 60) % 60, remaining % 60].map(value => String(value).padStart(2, '0')).join(':') : '—'
  return <div className="container prayer-page"><Breadcrumb items={[{ label: 'Jadwal Salat' }]} /><header className="page-heading"><p className="eyebrow">RUANG KEISLAMAN · MENJAGA WAKTU</p><h1>Jadwal Salat<span className="gold-dot">.</span></h1><p>Waktu ibadah untuk lokasi yang Anda pilih. Lokasi perangkat hanya diakses setelah Anda menekan tombol dan memberikan izin.</p></header><LocationPicker location={location} onChange={setLocation} coordinates /><section className="prayer-display"><div className="prayer-date-line"><div><span className="eyebrow">{location.name.toUpperCase()}</span><p>{now ? new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: timezone }).format(now) : 'Memuat tanggal…'}</p><span>{schedule ? `${schedule.today.data.date.hijri.day} ${schedule.today.data.date.hijri.month.en} ${schedule.today.data.date.hijri.year} H` : 'Tanggal Hijriah menunggu data sumber'}</span></div><Sun size={52} strokeWidth={0.8} aria-hidden="true" /></div>{error ? <div className="api-error" role="alert"><h2>Jadwal belum tersedia.</h2><p>{error}</p><button className="button button-gold" onClick={() => setRetry(value => value + 1)}>Coba kembali</button></div> : <><div className="next-prayer"><span><Clock size={15} />{schedule ? `MENUJU ${nextLabel.toUpperCase()}${!next ? ' BESOK' : ''}` : 'MEMUAT WAKTU SALAT'}</span><strong>{schedule ? countdown : '— : — : —'}</strong><p>{schedule ? `${nextLabel} · ${nextTime?.slice(0, 5)} · ${timezone}` : 'Waktu tidak diperkirakan tanpa data sumber.'}</p></div><div className="prayer-times" aria-label="Lima waktu salat">{prayerNames.map(prayer => <div className={next?.key === prayer.key ? 'active' : ''} key={prayer.key}>{prayer.key === 'Isha' || prayer.key === 'Fajr' ? <MoonStar size={22} strokeWidth={1.1} /> : <Sun size={22} strokeWidth={1.1} />}<span>{prayer.label}</span><strong>{schedule?.today.data.timings[prayer.key].slice(0, 5) ?? '—'}</strong>{next?.key === prayer.key && <small>BERIKUTNYA</small>}</div>)}</div></>}</section><div className="prayer-explanation"><h2>Lokasi yang jelas, waktu yang dapat diperiksa.</h2><p>Lokasi: {location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}. Zona waktu mengikuti data jadwal: {timezone}. Pilihan awal Jakarta adalah lokasi manual, bukan lokasi kampus atau hasil deteksi perangkat.</p><p>Perhitungan dari Aladhan, metode 20 (Kementerian Agama Republik Indonesia). Waktu merupakan hasil perhitungan, bukan jadwal resmi setempat. Cocokkan dengan masjid atau otoritas agama setempat. Tanggal Hijriah dapat berbeda berdasarkan penetapan resmi.</p><p>Tidak ada notifikasi otomatis. Koordinat digunakan untuk meminta jadwal, tidak disimpan dalam database situs.</p><a className="text-link" href="https://aladhan.com/prayer-times-api" target="_blank" rel="noreferrer">Tentang sumber perhitungan</a></div><IslamicNav compact /></div>
}
