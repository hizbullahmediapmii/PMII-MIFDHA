import { useEffect, useState } from 'react'
import { ArrowUpRight, Copy, Minus, Plus, RotateCcw, Search } from 'lucide-react'
import { Breadcrumb, EmptyState } from '@/components/editorial'
import { IslamicNav } from '@/components/IslamicNav'
import { dailyAdhkar } from '@/data/daily-adhkar'
import { islamicService } from '@/services/islamic'
import type { Doa } from '@/services/islamic'

const dzikirCategories = ['Dzikir Pagi', 'Dzikir Petang', 'Tasbih', 'Tahmid', 'Takbir', 'Istighfar', 'Setelah Salat', 'Tahlil']
const doaCategories = ['Doa Harian', 'Doa Sebelum Tidur', 'Doa Bangun Tidur', 'Doa Untuk Orang Tua', 'Doa Bepergian', 'Doa Setelah Salat', 'Doa Belajar', 'Doa Kebaikan Dunia Akhirat']
const dzikirIds: Record<string, number[]> = { Tasbih: [205, 206, 207], Tahmid: [204, 209], Takbir: [204], Istighfar: [201, 202, 203], 'Setelah Salat': [225], Tahlil: [208, 209] }

function matchesDoa(item: Doa, category: string) {
  const text = `${item.grup} ${item.nama}`.toLocaleLowerCase('id-ID')
  if (category === 'Doa Sebelum Tidur') return /sebelum tidur/.test(text)
  if (category === 'Doa Bangun Tidur') return /bangun tidur/.test(text)
  if (category === 'Doa Untuk Orang Tua') return /orang tua/.test(text)
  if (category === 'Doa Bepergian') return /perjalanan|bepergian|kendaraan/.test(text)
  if (category === 'Doa Setelah Salat') return /setelah shalat|setelah salam/.test(text)
  if (category === 'Doa Belajar') return /memohon ilmu|paham tentang agama/.test(text)
  if (category === 'Doa Kebaikan Dunia Akhirat') return item.id === 172
  return !/jenazah|bersetubuh|melahirkan|meninggal/.test(text)
}

export function DevotionalPage({ kind }: { kind: 'dzikir' | 'doa' }) {
  const categories = kind === 'dzikir' ? dzikirCategories : doaCategories
  const [category, setCategory] = useState(categories[0])
  const [query, setQuery] = useState('')
  const [items, setItems] = useState<Doa[]>([])
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState('')
  const [retry, setRetry] = useState(0)
  const [offline, setOffline] = useState(false)
  const [status, setStatus] = useState('')
  const [limit, setLimit] = useState(12)
  const [count, setCount] = useState(0)
  useEffect(() => {
    const controller = new AbortController()
    setLoaded(false); setError('')
    islamicService.doa(controller.signal).then(result => { setItems(result.data); setOffline(result.offline); setLoaded(true) }).catch(() => { if (!controller.signal.aborted) { setError('Bacaan belum dapat dimuat dari sumber. Silakan coba kembali.'); setLoaded(true) } })
    return () => controller.abort()
  }, [retry])
  const selected = kind === 'dzikir' ? (category === 'Dzikir Pagi' || category === 'Dzikir Petang' ? dailyAdhkar : items.filter(item => dzikirIds[category]?.includes(item.id))) : items.filter(item => matchesDoa(item, category))
  const filtered = selected.filter(item => `${item.nama} ${item.idn}`.toLocaleLowerCase('id-ID').includes(query.toLocaleLowerCase('id-ID')))
  const copy = async (item: Doa) => {
    try { await navigator.clipboard.writeText(`${item.nama}\n\n${item.ar}\n\n${item.idn}\n\n${item.tentang}\nSumber: EQuran.id${item.id < 0 ? ' / Hisnul Muslim' : ''}`); setStatus('Bacaan berhasil disalin beserta rujukannya.') } catch { setStatus('Penyalinan tidak tersedia. Pilih teks untuk menyalin secara manual.') }
  }
  return <div className="container devotional-page"><Breadcrumb items={[{ label: kind === 'dzikir' ? 'Dzikir' : 'Doa' }]} /><header className="page-heading"><p className="eyebrow">RUANG KEISLAMAN</p><h1>{kind === 'dzikir' ? <>Mengingat dalam<br /><em>setiap langkah.</em></> : <>Doa dalam<br /><em>keseharian.</em></>}</h1><p>{kind === 'dzikir' ? 'Ruang untuk mengingat dan menenangkan hati. Pilihan bacaan disertai sumber; bukan penetapan susunan wirid atau fatwa.' : 'Himpunan doa dengan teks Arab, transliterasi, terjemahan, dan rujukan yang dapat Anda telusuri.'}</p></header><div className="devotional-layout"><aside className="devotional-sidebar"><p className="small-heading">PILIHAN BACAAN</p><nav aria-label={`Kategori ${kind}`}>{categories.map(value => <button className={category === value ? 'active' : ''} key={value} aria-pressed={category === value} onClick={() => { setCategory(value); setLimit(12); setQuery(''); setCount(0) }}>{value}<ArrowUpRight size={15} /></button>)}</nav>{kind === 'dzikir' && <div className="dhikr-counter"><span>PENCATAT PRIBADI</span><strong aria-live="polite">{count}</strong><div><button className="icon-button" onClick={() => setCount(value => Math.max(0, value - 1))} aria-label="Kurangi hitungan" disabled={!count}><Minus size={18} /></button><button className="counter-add" onClick={() => setCount(value => value + 1)} aria-label="Tambah hitungan dzikir"><Plus size={24} /></button><button className="icon-button" onClick={() => setCount(0)} aria-label="Atur ulang hitungan"><RotateCcw size={17} /></button></div><p>Hitungan sesi ini, tidak disimpan. Bukan ketentuan jumlah amalan.</p></div>}</aside><div className="devotional-content"><div className="devotional-content-top"><h2>{category}</h2><div className="collection-search"><Search size={18} /><label htmlFor="devotional-query" className="sr-only">Cari bacaan</label><input id="devotional-query" value={query} onChange={event => setQuery(event.target.value)} placeholder="Cari dalam kategori…" /></div></div>{offline && <p className="source-note">Layanan langsung sedang tidak tersedia. Menampilkan cuplikan bacaan yang disalin dari EQuran.id pada 5 Oktober 2026, bukan katalog lengkap.</p>}{kind === 'dzikir' && category === 'Setelah Salat' && <p className="source-note">Cuplikan sumber yang tersedia adalah bacaan setelah salam salat witir. Bukan rangkaian lengkap dzikir setelah salat wajib.</p>}{kind === 'dzikir' && (category === 'Dzikir Pagi' || category === 'Dzikir Petang') && <p className="source-note">Pilihan ayat berdasarkan bab Dzikir Pagi dan Petang dalam Hisnul Muslim. Teks dan terjemahan ayat dari EQuran.id. Ini cuplikan, bukan rangkaian lengkap.</p>}{error ? <div className="api-error" role="alert"><h2>Bacaan belum tersedia.</h2><p>{error}</p><button className="button" onClick={() => setRetry(value => value + 1)}>Coba kembali</button></div> : !loaded && kind === 'doa' ? <div className="reading-skeleton" role="status"><span /><span /><p>Memuat himpunan bacaan…</p></div> : !loaded && kind === 'dzikir' && category !== 'Dzikir Pagi' && category !== 'Dzikir Petang' ? <div className="reading-skeleton" role="status"><span /><span /><p>Memuat bacaan…</p></div> : filtered.length ? <>{filtered.slice(0, limit).map(item => <article className="devotional-reading" key={item.id}><div className="devotional-reading-title"><h3>{item.nama}</h3><button className="icon-button" onClick={() => copy(item)} aria-label={`Salin ${item.nama}`}><Copy size={17} /></button></div><p className="arabic" lang="ar" dir="rtl">{item.ar}</p><p className="ayah-latin">{item.tr}</p><p className="devotional-translation">{item.idn}</p><details className="religious-source"><summary>Sumber & keterangan</summary><p>{item.tentang}</p><a href="https://equran.id/doa" target="_blank" rel="noreferrer">Telusuri EQuran.id<ArrowUpRight size={14} /></a>{item.id < 0 && <a href="https://www.hisnmuslim.com/api/ar/27.json" target="_blank" rel="noreferrer">Rujukan Hisnul Muslim<ArrowUpRight size={14} /></a>}</details></article>)}{filtered.length > limit && <button className="outline-button load-more" onClick={() => setLimit(value => value + 12)}>Tampilkan bacaan berikutnya ({filtered.length - limit})</button>}</> : <EmptyState title="Tidak ada bacaan yang sesuai." text="Coba kata lain atau kategori berbeda. Bacaan tanpa sumber yang dapat ditelusuri tidak ditampilkan." />}</div></div><p className="action-status" role="status">{status}</p><p className="religious-disclaimer">Keterangan dan rujukan hadis mengikuti data penyedia. Situs ini tidak memberikan penilaian mandiri terhadap derajat hadis. Untuk bimbingan amalan, rujuk pembimbing agama yang tepercaya.</p><IslamicNav compact /></div>
}
