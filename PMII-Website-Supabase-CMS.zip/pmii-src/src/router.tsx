import { createRouter } from '@tanstack/react-router'

import { routeTree } from './routeTree.gen'

export const getRouter = () => {
  const router = createRouter({
    routeTree,
    scrollRestoration: true,
    trailingSlash: 'never',
    defaultPreloadStaleTime: 0,
  })

  return router
}
