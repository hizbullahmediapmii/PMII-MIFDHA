import { demoContent, sections } from '../data/content'
import type { ContentEntry, ContentKind, PublicImage, Visibility } from '../data/types'
import { isSupabaseConfigured, supabaseRequest } from './supabase'

const tableByKind: Record<ContentKind, string> = {
  berita: 'articles',
  materi: 'materials',
  kegiatan: 'activities',
  karya: 'works',
  agenda: 'agendas',
  angkatan: 'cohorts',
}

function image(src?: string, title = 'Dokumentasi PMII') : PublicImage {
  return { src: src || '/img/study-circle.jpg', alt: title, credit: src ? 'Dokumentasi PMII' : 'Foto ilustrasi', illustrative: !src }
}

function bodyFrom(value: unknown) {
  const text = typeof value === 'string' ? value : ''
  return text.split(/\n\s*\n/).filter(Boolean).map(paragraph => ({ text: paragraph.replace(/<[^>]+>/g, '').trim() }))
}

function mapRow(kind: ContentKind, row: any): ContentEntry {
  const publishedAt = row.published_at || row.created_at || new Date().toISOString()
  const authorName = row.author_name || 'Redaksi'
  const title = row.title || 'Tanpa judul'
  const category = row.category?.name || row.category_name || 'Umum'
  const content = row.content || row.description || row.excerpt || ''
  const entry: ContentEntry = {
    id: row.id,
    slug: row.slug,
    kind,
    title,
    category,
    excerpt: row.excerpt || row.description || '',
    body: bodyFrom(content),
    image: image(row.featured_image || row.thumbnail_url || row.featured_image_url, title),
    author: { name: authorName, role: row.author_position || 'Kontributor' },
    publishedAt,
    readingMinutes: Math.max(1, Math.ceil(String(content).split(/\s+/).filter(Boolean).length / 180)),
    visibility: row.status === 'published' ? 'PUBLIC' : row.status === 'archived' ? 'INTERNAL' : 'DRAFT',
    isDemo: false,
  }
  if (kind === 'kegiatan' || kind === 'agenda') {
    entry.event = { startsAt: row.event_date || row.start_at || publishedAt, endsAt: row.end_at || row.event_date || publishedAt, location: row.location || 'Lokasi belum dicantumkan', organizer: row.organizer || 'PMII Institut Miftahul Huda' }
  }
  if (kind === 'angkatan') entry.cohort = { year: Number(row.year || 0), achievements: [] }
  return entry
}

async function remoteList(kind?: ContentKind) {
  const kinds = kind ? [kind] : (Object.keys(tableByKind) as ContentKind[])
  const rows = await Promise.all(kinds.map(async current => {
    const table = tableByKind[current]
    const data = await supabaseRequest<any[]>(`/rest/v1/${table}?select=*&status=eq.published&order=published_at.desc.nullslast,created_at.desc`)
    return data.map(row => mapRow(current, row))
  }))
  return rows.flat()
}

export const contentService = {
  async list(kind?: ContentKind): Promise<ContentEntry[]> {
    if (!isSupabaseConfigured()) return demoContent.filter(item => item.visibility === 'PUBLIC' && (!kind || item.kind === kind))
    try { return await remoteList(kind) } catch { return demoContent.filter(item => item.visibility === 'PUBLIC' && (!kind || item.kind === kind)) }
  },
  async find(kind: ContentKind, slug: string): Promise<ContentEntry | null> {
    const items = await this.list(kind)
    return items.find(item => item.slug === slug) ?? null
  },
  async search(query: string, kind?: ContentKind): Promise<ContentEntry[]> {
    const normalized = query.toLocaleLowerCase('id-ID').trim()
    return (await this.list(kind)).filter(item => `${item.title} ${item.category} ${item.excerpt} ${item.body.map(p => `${p.heading ?? ''} ${p.text}`).join(' ')}`.toLocaleLowerCase('id-ID').includes(normalized))
  },
}

export function isContentKind(value: string): value is ContentKind { return Object.hasOwn(sections, value) }

export const utilitySections = {
  'al-quran': { title: 'Al-Qur’an', description: 'Baca 114 surah, telusuri ayat, dan lanjutkan bacaan dalam ruang yang tenang.' },
  dzikir: { title: 'Dzikir', description: 'Bacaan dan ruang refleksi dengan sumber yang dapat ditelusuri.' },
  doa: { title: 'Doa', description: 'Himpunan doa sehari-hari, teks Arab, transliterasi, arti, dan rujukannya.' },
  'jadwal-salat': { title: 'Jadwal Salat', description: 'Waktu salat sesuai lokasi pilihan Anda. Tidak mengaktifkan notifikasi secara otomatis.' },
  'arah-kiblat': { title: 'Arah Kiblat', description: 'Temukan arah kiblat dari lokasi Anda, dengan informasi kemampuan sensor yang jelas.' },
  tentang: { title: 'Tentang PMII', description: 'Mengenal ruang keislaman, keilmuan, dan pergerakan di Institut Miftahul Huda.' },
  cari: { title: 'Pencarian', description: 'Telusuri berita, bahan belajar, karya, kegiatan, dan agenda.' },
  'kebijakan-publikasi': { title: 'Kebijakan Publikasi & Privasi', description: 'Komitmen terhadap keterbukaan informasi publik dan perlindungan data pribadi.' },
}
export function sectionInfo(value: string) { if (isContentKind(value)) return sections[value]; if (Object.hasOwn(utilitySections, value)) return utilitySections[value as keyof typeof utilitySections]; return undefined }
