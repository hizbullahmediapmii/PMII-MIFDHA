import { z } from 'zod'
import { verifiedDoa, verifiedFatihah } from '@/data/verified-readings'

const ayahSchema = z.object({ nomorAyat: z.number().int(), teksArab: z.string(), teksLatin: z.string(), teksIndonesia: z.string() })
const surahSchema = z.object({ nomor: z.number().int(), nama: z.string(), namaLatin: z.string(), jumlahAyat: z.number().int(), tempatTurun: z.string(), arti: z.string(), ayat: z.array(ayahSchema), audioFull: z.record(z.string(), z.string()).optional() })
const doaSchema = z.object({ id: z.number(), grup: z.string(), nama: z.string(), ar: z.string(), tr: z.string(), idn: z.string(), tentang: z.string(), tag: z.array(z.string()).optional() })

export type Surah = z.infer<typeof surahSchema>
export type Doa = z.infer<typeof doaSchema>
export interface ReadingPosition { surah: number; ayah: number }
export interface ReadingState { lastRead: ReadingPosition | null; bookmarks: ReadingPosition[] }

async function requestJson(url: string, signal?: AbortSignal) {
  const response = await fetch(url, { signal })
  if (!response.ok) throw new Error('Layanan belum tersedia. Silakan coba kembali.')
  return response.json()
}

export const islamicService = {
  async surah(number: number, signal?: AbortSignal): Promise<{ data: Surah; offline: boolean }> {
    try {
      const value = await requestJson(`/api/islamic-data?resource=surah&number=${number}`, signal)
      const data = surahSchema.parse(value.data)
      if (data.nomor !== number || data.ayat.length !== data.jumlahAyat) throw new Error('Incomplete surah')
      return { data, offline: false }
    } catch (error) {
      if (signal?.aborted) throw error
      if (number === 1) return { data: surahSchema.parse(verifiedFatihah), offline: true }
      throw new Error('Surah ini belum dapat dimuat. Periksa koneksi atau buka Al-Fatihah yang tersedia sebagai cuplikan tersimpan.')
    }
  },
  async doa(signal?: AbortSignal): Promise<{ data: Doa[]; offline: boolean }> {
    try {
      const value = await requestJson('/api/islamic-data?resource=doa', signal)
      return { data: z.array(doaSchema).parse(value.data), offline: false }
    } catch (error) {
      if (signal?.aborted) throw error
      return { data: z.array(doaSchema).parse(verifiedDoa), offline: true }
    }
  },
  async readingState(): Promise<ReadingState> {
    const value = await requestJson('/api/reading-state')
    return z.object({ lastRead: z.object({ surah: z.number(), ayah: z.number() }).nullable(), bookmarks: z.array(z.object({ surah: z.number(), ayah: z.number() })) }).parse(value)
  },
  async saveReading(position: ReadingPosition, action: 'bookmark' | 'remove' | 'last-read') {
    const response = await fetch('/api/reading-state', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...position, action }) }).catch(() => { throw new Error('Koneksi penyimpanan belum tersedia. Penanda belum disimpan; silakan coba kembali.') })
    const data = await response.json().catch(() => ({ message: 'Penyimpanan belum dapat dikonfirmasi. Silakan coba kembali.' }))
    if (!response.ok || data.saved !== true) throw new Error(data.message || 'Penanda belum berhasil disimpan.')
  },
  async deleteReading() {
    const response = await fetch('/api/reading-state', { method: 'DELETE' }).catch(() => { throw new Error('Koneksi penyimpanan belum tersedia. Data belum dihapus; silakan coba kembali.') })
    const data = await response.json().catch(() => null)
    if (!response.ok || data?.deleted !== true) throw new Error('Data bacaan belum berhasil dihapus. Silakan coba kembali.')
  },
}
