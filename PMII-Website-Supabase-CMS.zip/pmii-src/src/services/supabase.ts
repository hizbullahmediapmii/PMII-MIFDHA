const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

export function isSupabaseConfigured() {
  return Boolean(supabaseUrl && supabaseAnonKey)
}

function apiUrl(path: string) {
  if (!supabaseUrl) throw new Error('VITE_SUPABASE_URL belum diatur.')
  return `${supabaseUrl.replace(/\/$/, '')}${path}`
}

export async function supabaseRequest<T>(path: string, init: RequestInit = {}, accessToken?: string): Promise<T> {
  if (!supabaseAnonKey) throw new Error('VITE_SUPABASE_ANON_KEY belum diatur.')
  const headers = new Headers(init.headers)
  headers.set('apikey', supabaseAnonKey)
  headers.set('Content-Type', 'application/json')
  if (accessToken) headers.set('Authorization', `Bearer ${accessToken}`)
  const response = await fetch(apiUrl(path), { ...init, headers })
  const text = await response.text()
  if (!response.ok) throw new Error(text || `Supabase request gagal (${response.status})`)
  return text ? JSON.parse(text) as T : (undefined as T)
}

export interface SupabaseSession {
  access_token: string
  refresh_token: string
  user: { id: string; email?: string }
}

export async function signIn(email: string, password: string) {
  return supabaseRequest<SupabaseSession>('/auth/v1/token?grant_type=password', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  })
}
