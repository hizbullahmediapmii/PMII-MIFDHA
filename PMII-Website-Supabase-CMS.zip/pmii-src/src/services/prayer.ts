import { z } from 'zod'
import type { PublicLocation } from '@/data/locations'

const timeSchema = z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d(?:\s.*)?$/)
const timezoneSchema = z.string().refine(value => { try { new Intl.DateTimeFormat('id-ID', { timeZone: value }); return true } catch { return false } })
const prayerDaySchema = z.object({ code: z.literal(200), data: z.object({ timings: z.object({ Fajr: timeSchema, Dhuhr: timeSchema, Asr: timeSchema, Maghrib: timeSchema, Isha: timeSchema }), date: z.object({ readable: z.string(), hijri: z.object({ day: z.string(), month: z.object({ en: z.string() }), year: z.string() }), gregorian: z.object({ date: z.string() }) }), meta: z.object({ timezone: timezoneSchema }) }) })
const scheduleSchema = z.object({ today: prayerDaySchema, tomorrow: prayerDaySchema })
export type PrayerSchedule = z.infer<typeof scheduleSchema>

export const prayerService = {
  async schedule(location: PublicLocation, date: string, signal?: AbortSignal) {
    const params = new URLSearchParams({ resource: 'prayer', lat: String(location.latitude), lng: String(location.longitude), date })
    const response = await fetch(`/api/islamic-data?${params}`, { signal }).catch(() => { throw new Error('Koneksi ke sumber jadwal belum tersedia. Silakan coba kembali atau pilih lokasi manual lain.') })
    if (!response.ok) throw new Error('Jadwal belum dapat dimuat. Periksa koneksi atau pilih lokasi lain; waktu salat tidak ditampilkan tanpa data sumber.')
    const value = await response.json().catch(() => null)
    const parsed = scheduleSchema.safeParse(value)
    if (!parsed.success) throw new Error('Respons sumber jadwal belum dapat diverifikasi. Waktu salat tidak ditampilkan; silakan coba kembali.')
    const schedule = parsed.data
    if (schedule.today.data.date.gregorian.date !== date) throw new Error('Tanggal dari sumber tidak cocok. Jadwal tidak ditampilkan; silakan coba kembali.')
    const [day, month, year] = date.split('-').map(Number)
    const tomorrow = new Date(Date.UTC(year, month - 1, day + 1))
    const nextDate = `${String(tomorrow.getUTCDate()).padStart(2, '0')}-${String(tomorrow.getUTCMonth() + 1).padStart(2, '0')}-${tomorrow.getUTCFullYear()}`
    if (schedule.tomorrow.data.date.gregorian.date !== nextDate) throw new Error('Jadwal hari berikutnya belum dapat diverifikasi. Silakan coba kembali.')
    return schedule
  },
}
