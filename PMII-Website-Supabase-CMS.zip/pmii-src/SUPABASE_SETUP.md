# Supabase website setup

Website ini menggunakan Supabase publik yang sudah disiapkan.

Environment variables:
- VITE_SUPABASE_URL=https://etxcdjyysjugpxupcyrk.supabase.co
- VITE_SUPABASE_ANON_KEY=Supabase Project Settings > API > anon public key

Admin login memakai akun Supabase Auth yang sudah dibuat. Jangan masukkan service_role key ke browser.

Buka `/admin` setelah deploy untuk masuk dan mengelola berita, materi, kegiatan, karya, agenda, dan angkatan.

Konten berstatus `published` tampil di website publik. Status lain tidak tampil di halaman publik.
